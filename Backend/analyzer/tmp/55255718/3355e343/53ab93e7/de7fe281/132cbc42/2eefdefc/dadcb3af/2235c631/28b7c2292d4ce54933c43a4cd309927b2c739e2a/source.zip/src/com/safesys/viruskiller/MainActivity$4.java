	final synthetic com.safesys.viruskiller.MainActivity this$0
	
	    MainActivity$4(com.safesys.viruskiller.MainActivity p1)
	    {
	        this.this$0 = p1;
	        return;
	    }
	
	
	    static synthetic com.safesys.viruskiller.MainActivity access$0(com.safesys.viruskiller.MainActivity$4 p1)
	    {
	        return p1.this$0;
	    }
	
	
	    public void run()
	    {
	        while (!this.this$0.bThread) {
	            try {
	                if (!this.this$0.bPause) {
	                    if (!this.this$0.bStop) {
	                        this.this$0.handler.post(new com.safesys.viruskiller.MainActivity$4$2(this));
	                        Thread.currentThread();
	                        Thread.sleep(1000);
	                        com.safesys.viruskiller.MainActivity v1_9 = this.this$0;
	                        v1_9.iSeconds = (v1_9.iSeconds + 1);
	                    } else {
	                        Thread.currentThread();
	                        Thread.sleep(100);
	                        this.this$0.handler.post(new com.safesys.viruskiller.MainActivity$4$1(this));
	                        this.this$0.iSeconds = 0;
	                    }
	                } else {
	                    Thread.currentThread();
	                    Thread.sleep(100);
	                }
	            } catch (com.safesys.viruskiller.MainActivity v1_14) {
	                v1_14.printStackTrace();
	            }
	        }
	        return;
	    }
	
