	
	    static ScanController()
	    {
	        System.loadLibrary("ScanController");
	        return;
	    }
	
	
	    public ScanController()
	    {
	        return;
	    }
	
