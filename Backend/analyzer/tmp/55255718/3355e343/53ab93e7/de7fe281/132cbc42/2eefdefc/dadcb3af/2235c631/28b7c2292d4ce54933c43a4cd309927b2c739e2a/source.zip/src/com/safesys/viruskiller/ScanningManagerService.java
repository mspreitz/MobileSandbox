	private static  blPFlag
	private static android.content.Context context
	private static  iScannState
	public static  initFlag
	private static android.os.PowerManager$WakeLock mStartingService
	private static final java.lang.Object mStartingServiceSync
	public static  rootFlag
	private static com.safesys.viruskiller.ScanningManagerService service
	private com.safesys.viruskiller.ScanningManagerService$ServiceHandler mServiceHandler
	private android.os.Looper mServiceLooper
	public android.os.Handler mainHandle
	private com.safesys.viruskiller.util.Utility utils
	
	    static ScanningManagerService()
	    {
	        com.safesys.viruskiller.ScanningManagerService.mStartingServiceSync = new Object();
	        com.safesys.viruskiller.ScanningManagerService.context = 0;
	        com.safesys.viruskiller.ScanningManagerService.service = 0;
	        com.safesys.viruskiller.ScanningManagerService.iScannState = 0;
	        com.safesys.viruskiller.ScanningManagerService.blPFlag = 0;
	        com.safesys.viruskiller.ScanningManagerService.initFlag = 0;
	        com.safesys.viruskiller.ScanningManagerService.rootFlag = 0;
	        return;
	    }
	
	
	    public ScanningManagerService()
	    {
	        this.utils = new com.safesys.viruskiller.util.Utility();
	        return;
	    }
	
	
	    static synthetic com.safesys.viruskiller.util.Utility access$0(com.safesys.viruskiller.ScanningManagerService p1)
	    {
	        return p1.utils;
	    }
	
	
	    static synthetic android.content.Context access$1()
	    {
	        return com.safesys.viruskiller.ScanningManagerService.context;
	    }
	
	
	    public static void beginStartingService(android.content.Context p0, android.content.Intent p1)
	    {
	        com.safesys.viruskiller.ScanningManagerService.context = p0;
	        p0.startService(p1);
	        return;
	    }
	
	
	    public static void finishStartingService()
	    {
	        if (com.safesys.viruskiller.ScanningManagerService.service != null) {
	            com.safesys.viruskiller.ScanningManagerService.service.stopSelf();
	        }
	        return;
	    }
	
	
	    public static int getiScannState()
	    {
	        return com.safesys.viruskiller.ScanningManagerService.iScannState;
	    }
	
	
	    public static boolean isBlPFlag()
	    {
	        return com.safesys.viruskiller.ScanningManagerService.blPFlag;
	    }
	
	
	    public static void setBlPFlag(boolean p0)
	    {
	        com.safesys.viruskiller.ScanningManagerService.blPFlag = p0;
	        return;
	    }
	
	
	    public static void setiScannState(int p0)
	    {
	        com.safesys.viruskiller.ScanningManagerService.iScannState = p0;
	        return;
	    }
	
	
	    public android.os.IBinder onBind(android.content.Intent p2)
	    {
	        return 0;
	    }
	
	
	    public void onCreate()
	    {
	        super.onCreate();
	        com.safesys.viruskiller.ScanningManagerService.service = this;
	        android.os.HandlerThread v2_1 = new android.os.HandlerThread("ScanVirusManagerService", 10);
	        v2_1.start();
	        this.mServiceLooper = v2_1.getLooper();
	        this.mServiceHandler = new com.safesys.viruskiller.ScanningManagerService$ServiceHandler(this, this.mServiceLooper);
	        if (!com.safesys.viruskiller.ScanningManagerService.initFlag) {
	            if (com.safesys.viruskiller.util.Utility.initROOT(this)) {
	                com.safesys.viruskiller.ScanningManagerService.rootFlag = 1;
	                int v0 = this.utils.isLinuxProcessExist();
	                String v1 = 0;
	                if ((v0 == 1) || (v0 == 0)) {
	                    v1 = new StringBuilder("kill -9 ").append(com.safesys.viruskiller.util.Utility.sProcID).toString();
	                }
	                this.utils.startListening(v1);
	            }
	            com.opensystem.terminator.ScanVirus.Init();
	            com.safesys.viruskiller.ScanningManagerService.initFlag = 1;
	        }
	        return;
	    }
	
	
	    public void onDestroy()
	    {
	        com.opensystem.terminator.ScanVirus.Release();
	        super.onDestroy();
	        this.mServiceLooper.quit();
	        return;
	    }
	
	
	    public void onStart(android.content.Intent p10, int p11)
	    {
	        super.onStart(p10, p11);
	        if (com.safesys.viruskiller.util.Utility.checkROOT(this)) {
	            int v2 = this.utils.isLinuxProcessExist();
	            String v6 = 0;
	            if ((v2 == 1) || (v2 == 0)) {
	                v6 = new StringBuilder("kill -9 ").append(com.safesys.viruskiller.util.Utility.sProcID).toString();
	            }
	            this.utils.startListening(v6);
	        }
	        android.os.Bundle v0 = p10.getExtras();
	        int v3 = v0.getInt("state");
	        Boolean v1 = Boolean.valueOf(v0.getBoolean("notification_record"));
	        if ((v3 != -1) && (v1 != null)) {
	            if (!v1.booleanValue()) {
	                android.os.Message v5 = this.mServiceHandler.obtainMessage();
	                v5.arg1 = v3;
	                this.mServiceHandler.sendMessage(v5);
	            } else {
	                android.content.Intent v4_1 = new android.content.Intent(this, com.safesys.viruskiller.MainActivity);
	                v4_1.setFlags(809500672);
	                this.startActivity(v4_1);
	            }
	        }
	        return;
	    }
	
