	final synthetic com.safesys.viruskiller.util.Utility this$0
	
	    Utility$1(com.safesys.viruskiller.util.Utility p1)
	    {
	        this.this$0 = p1;
	        return;
	    }
	
	
	    public void handleMessage(android.os.Message p1)
	    {
	        return;
	    }
	
