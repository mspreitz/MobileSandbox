	
	    static ScanVirus()
	    {
	        System.loadLibrary("ScanVirus");
	        return;
	    }
	
	
	    public ScanVirus()
	    {
	        return;
	    }
	
