	final synthetic com.safesys.viruskiller.MainActivity$UpdateReceiver this$1
	
	    MainActivity$UpdateReceiver$2(com.safesys.viruskiller.MainActivity$UpdateReceiver p1)
	    {
	        this.this$1 = p1;
	        return;
	    }
	
	
	    public void run()
	    {
	        java.util.Calendar v0 = java.util.Calendar.getInstance();
	        String v3 = new StringBuilder(String.valueOf(v0.get(1))).append("-").append((v0.get(2) + 1)).append("-").append(v0.get(5)).toString();
	        com.safesys.viruskiller.MainActivity$UpdateReceiver.access$0(this.this$1).copyright_info.setText(new StringBuilder(String.valueOf(com.safesys.viruskiller.MainActivity$UpdateReceiver.access$0(this.this$1).getString(2131099650))).append(" ").append(v3).toString());
	        android.content.SharedPreferences$Editor v1 = com.safesys.viruskiller.MainActivity.preferences.edit();
	        v1.putString("virus_update_date", v3);
	        v1.commit();
	        com.safesys.viruskiller.MainActivity$UpdateReceiver.access$0(this.this$1).strUpdate = v3;
	        if (com.safesys.viruskiller.MainActivity$UpdateReceiver.access$0(this.this$1).flag_autoupdate) {
	            com.safesys.viruskiller.MainActivity.access$1(com.safesys.viruskiller.MainActivity$UpdateReceiver.access$0(this.this$1)).setBackgroundResource(2130837537);
	            com.safesys.viruskiller.MainActivity.access$1(com.safesys.viruskiller.MainActivity$UpdateReceiver.access$0(this.this$1)).setGravity(49);
	            com.safesys.viruskiller.MainActivity.access$1(com.safesys.viruskiller.MainActivity$UpdateReceiver.access$0(this.this$1)).setPadding(0, 5, 7, 0);
	            com.safesys.viruskiller.MainActivity$UpdateReceiver.access$0(this.this$1).flag_autoupdate = 0;
	            android.content.SharedPreferences$Editor v2 = com.safesys.viruskiller.MainActivity.preferences.edit();
	            v2.putBoolean("virus_autoupdate_flag", 0);
	            v2.commit();
	        }
	        android.widget.Toast.makeText(com.safesys.viruskiller.MainActivity.access$2(), new StringBuilder(String.valueOf(com.safesys.viruskiller.MainActivity$UpdateReceiver.access$0(this.this$1).getString(2131099678))).append(" ").append(v3).toString(), 1).show();
	        return;
	    }
	
