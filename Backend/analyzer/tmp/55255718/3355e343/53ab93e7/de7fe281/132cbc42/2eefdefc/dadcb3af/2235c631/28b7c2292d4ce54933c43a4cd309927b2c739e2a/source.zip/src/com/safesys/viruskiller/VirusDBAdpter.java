	private static final java.lang.String DATABASE_CREATE
	private static final java.lang.String DATABASE_NAME
	private static final java.lang.String DATABASE_TABLE
	private static final  DATABASE_VERSION
	public static final java.lang.String KEY_DELFLAG
	public static final java.lang.String KEY_ID
	public static final java.lang.String KEY_QDATETIME
	public static final java.lang.String KEY_QFLAG
	public static final java.lang.String KEY_QVIRUSPATH
	public static final java.lang.String KEY_VIRUSBAK
	public static final java.lang.String KEY_VIRUSDESC
	public static final java.lang.String KEY_VIRUSGRADE
	public static final java.lang.String KEY_VIRUSNAME
	public static final java.lang.String KEY_VIRUSPATH
	public static final Ljava.lang.String result_columns
	private android.content.Context ctx
	private android.database.sqlite.SQLiteDatabase db
	private com.safesys.viruskiller.VirusDBAdpter$MyDbHelper dbHelper
	
	    static VirusDBAdpter()
	    {
	        String[] v0_1 = new String[10];
	        v0_1[0] = "_id";
	        v0_1[1] = "virus_name";
	        v0_1[2] = "virus_desc";
	        v0_1[3] = "virus_path";
	        v0_1[4] = "virus_grade";
	        v0_1[5] = "del_flag";
	        v0_1[6] = "quarantine_flag";
	        v0_1[7] = "quarantine_datetime";
	        v0_1[8] = "quarantine_path";
	        v0_1[9] = "virus_bak";
	        com.safesys.viruskiller.VirusDBAdpter.result_columns = v0_1;
	        return;
	    }
	
	
	    public VirusDBAdpter(android.content.Context p5)
	    {
	        this.ctx = 0;
	        this.ctx = p5;
	        this.dbHelper = new com.safesys.viruskiller.VirusDBAdpter$MyDbHelper(p5, "VirusRecord.db", 0, 1);
	        return;
	    }
	
	
	    public void close()
	    {
	        this.db.close();
	        return;
	    }
	
	
	    public java.util.ArrayList findAll()
	    {
	        String v3_2;
	        android.database.Cursor v22 = this.db.query("VirusInfo", com.safesys.viruskiller.VirusDBAdpter.result_columns, 0, 0, 0, 0, "_id");
	        if (v22 != null) {
	            if (v22.getCount() <= 0) {
	                v3_2 = 0;
	            } else {
	                java.util.ArrayList v21_1 = new java.util.ArrayList();
	                int v14 = v22.getColumnIndexOrThrow("_id");
	                int v19 = v22.getColumnIndexOrThrow("virus_name");
	                int v17 = v22.getColumnIndexOrThrow("virus_desc");
	                int v18 = v22.getColumnIndexOrThrow("virus_path");
	                int v12 = v22.getColumnIndexOrThrow("virus_grade");
	                int v13 = v22.getColumnIndexOrThrow("del_flag");
	                int v20 = v22.getColumnIndexOrThrow("quarantine_flag");
	                int v11 = v22.getColumnIndexOrThrow("quarantine_datetime");
	                int v15 = v22.getColumnIndexOrThrow("quarantine_path");
	                int v16 = v22.getColumnIndexOrThrow("virus_bak");
	                while (v22.moveToNext()) {
	                    android.content.ContentValues v23_1 = new android.content.ContentValues();
	                    v23_1.put("_id", Integer.valueOf(v22.getInt(v14)));
	                    v23_1.put("virus_name", v22.getString(v19));
	                    v23_1.put("virus_desc", v22.getString(v17));
	                    v23_1.put("virus_path", v22.getString(v18));
	                    v23_1.put("virus_grade", v22.getString(v12));
	                    v23_1.put("del_flag", v22.getString(v13));
	                    v23_1.put("quarantine_flag", v22.getString(v20));
	                    v23_1.put("quarantine_datetime", v22.getString(v11));
	                    v23_1.put("quarantine_path", v22.getString(v15));
	                    v23_1.put("virus_bak", v22.getString(v16));
	                    v21_1.add(v23_1);
	                }
	                v3_2 = v21_1;
	            }
	        } else {
	            v3_2 = 0;
	        }
	        return v3_2;
	    }
	
	
	    public java.util.ArrayList findAllByID(String p25)
	    {
	        String v3_5;
	        android.database.Cursor v22 = this.db.query("VirusInfo", com.safesys.viruskiller.VirusDBAdpter.result_columns, new StringBuilder("_id=").append(p25).toString(), 0, 0, 0, "_id");
	        if (v22 != null) {
	            if (v22.getCount() <= 0) {
	                v3_5 = 0;
	            } else {
	                java.util.ArrayList v21_1 = new java.util.ArrayList();
	                int v14 = v22.getColumnIndexOrThrow("_id");
	                int v19 = v22.getColumnIndexOrThrow("virus_name");
	                int v17 = v22.getColumnIndexOrThrow("virus_desc");
	                int v18 = v22.getColumnIndexOrThrow("virus_path");
	                int v12 = v22.getColumnIndexOrThrow("virus_grade");
	                int v13 = v22.getColumnIndexOrThrow("del_flag");
	                int v20 = v22.getColumnIndexOrThrow("quarantine_flag");
	                int v11 = v22.getColumnIndexOrThrow("quarantine_datetime");
	                int v15 = v22.getColumnIndexOrThrow("quarantine_path");
	                int v16 = v22.getColumnIndexOrThrow("virus_bak");
	                while (v22.moveToNext()) {
	                    android.content.ContentValues v23_1 = new android.content.ContentValues();
	                    v23_1.put("_id", Integer.valueOf(v22.getInt(v14)));
	                    v23_1.put("virus_name", v22.getString(v19));
	                    v23_1.put("virus_desc", v22.getString(v17));
	                    v23_1.put("virus_path", v22.getString(v18));
	                    v23_1.put("virus_grade", v22.getString(v12));
	                    v23_1.put("del_flag", v22.getString(v13));
	                    v23_1.put("quarantine_flag", v22.getString(v20));
	                    v23_1.put("quarantine_datetime", v22.getString(v11));
	                    v23_1.put("quarantine_path", v22.getString(v15));
	                    v23_1.put("virus_bak", v22.getString(v16));
	                    v21_1.add(v23_1);
	                }
	                v3_5 = v21_1;
	            }
	        } else {
	            v3_5 = 0;
	        }
	        return v3_5;
	    }
	
	
	    public java.util.ArrayList findAllByName(String p25)
	    {
	        String v3_6;
	        android.database.Cursor v22 = this.db.query("VirusInfo", com.safesys.viruskiller.VirusDBAdpter.result_columns, new StringBuilder("virus_path=\'").append(p25).append("\'").toString(), 0, 0, 0, "_id");
	        if (v22 != null) {
	            if (v22.getCount() <= 0) {
	                v3_6 = 0;
	            } else {
	                java.util.ArrayList v21_1 = new java.util.ArrayList();
	                int v14 = v22.getColumnIndexOrThrow("_id");
	                int v19 = v22.getColumnIndexOrThrow("virus_name");
	                int v17 = v22.getColumnIndexOrThrow("virus_desc");
	                int v18 = v22.getColumnIndexOrThrow("virus_path");
	                int v12 = v22.getColumnIndexOrThrow("virus_grade");
	                int v13 = v22.getColumnIndexOrThrow("del_flag");
	                int v20 = v22.getColumnIndexOrThrow("quarantine_flag");
	                int v11 = v22.getColumnIndexOrThrow("quarantine_datetime");
	                int v15 = v22.getColumnIndexOrThrow("quarantine_path");
	                int v16 = v22.getColumnIndexOrThrow("virus_bak");
	                while (v22.moveToNext()) {
	                    android.content.ContentValues v23_1 = new android.content.ContentValues();
	                    v23_1.put("_id", Integer.valueOf(v22.getInt(v14)));
	                    v23_1.put("virus_name", v22.getString(v19));
	                    v23_1.put("virus_desc", v22.getString(v17));
	                    v23_1.put("virus_path", v22.getString(v18));
	                    v23_1.put("virus_grade", v22.getString(v12));
	                    v23_1.put("del_flag", v22.getString(v13));
	                    v23_1.put("quarantine_flag", v22.getString(v20));
	                    v23_1.put("quarantine_datetime", v22.getString(v11));
	                    v23_1.put("quarantine_path", v22.getString(v15));
	                    v23_1.put("virus_bak", v22.getString(v16));
	                    v21_1.add(v23_1);
	                }
	                v3_6 = v21_1;
	            }
	        } else {
	            v3_6 = 0;
	        }
	        return v3_6;
	    }
	
	
	    public java.util.ArrayList findValidAll()
	    {
	        String v3_2;
	        android.database.Cursor v22 = this.db.query("VirusInfo", com.safesys.viruskiller.VirusDBAdpter.result_columns, "quarantine_flag= 1", 0, 0, 0, "_id");
	        if (v22 != null) {
	            if (v22.getCount() <= 0) {
	                v3_2 = 0;
	            } else {
	                java.util.ArrayList v21_1 = new java.util.ArrayList();
	                int v14 = v22.getColumnIndexOrThrow("_id");
	                int v19 = v22.getColumnIndexOrThrow("virus_name");
	                int v17 = v22.getColumnIndexOrThrow("virus_desc");
	                int v18 = v22.getColumnIndexOrThrow("virus_path");
	                int v12 = v22.getColumnIndexOrThrow("virus_grade");
	                int v13 = v22.getColumnIndexOrThrow("del_flag");
	                int v20 = v22.getColumnIndexOrThrow("quarantine_flag");
	                int v11 = v22.getColumnIndexOrThrow("quarantine_datetime");
	                int v15 = v22.getColumnIndexOrThrow("quarantine_path");
	                int v16 = v22.getColumnIndexOrThrow("virus_bak");
	                while (v22.moveToNext()) {
	                    android.content.ContentValues v23_1 = new android.content.ContentValues();
	                    v23_1.put("_id", Integer.valueOf(v22.getInt(v14)));
	                    v23_1.put("virus_name", v22.getString(v19));
	                    v23_1.put("virus_desc", v22.getString(v17));
	                    v23_1.put("virus_path", v22.getString(v18));
	                    v23_1.put("virus_grade", v22.getString(v12));
	                    v23_1.put("del_flag", v22.getString(v13));
	                    v23_1.put("quarantine_flag", v22.getString(v20));
	                    v23_1.put("quarantine_datetime", v22.getString(v11));
	                    v23_1.put("quarantine_path", v22.getString(v15));
	                    v23_1.put("virus_bak", v22.getString(v16));
	                    v21_1.add(v23_1);
	                }
	                v3_2 = v21_1;
	            }
	        } else {
	            v3_2 = 0;
	        }
	        return v3_2;
	    }
	
	
	    public long insertVirusEntry(String p5, String p6, String p7, String p8, String p9, String p10, String p11, String p12)
	    {
	        android.content.ContentValues v0_1 = new android.content.ContentValues();
	        v0_1.put("virus_name", p5);
	        v0_1.put("virus_desc", p6);
	        v0_1.put("virus_path", p7);
	        v0_1.put("virus_grade", p8);
	        v0_1.put("del_flag", "0");
	        v0_1.put("quarantine_flag", p9);
	        v0_1.put("quarantine_datetime", p10);
	        v0_1.put("quarantine_path", p11);
	        v0_1.put("virus_bak", p12);
	        return this.db.insert("VirusInfo", 0, v0_1);
	    }
	
	
	    public com.safesys.viruskiller.VirusDBAdpter open()
	    {
	        this.db = this.dbHelper.getWritableDatabase();
	        return this;
	    }
	
	
	    public boolean removeEntry(long p5)
	    {
	        int v0_2;
	        if (this.db.delete("VirusInfo", new StringBuilder("_id=").append(p5).toString(), 0) <= 0) {
	            v0_2 = 0;
	        } else {
	            v0_2 = 1;
	        }
	        return v0_2;
	    }
	
	
	    public int updateQflagEntry(long p6, String p8)
	    {
	        android.content.ContentValues v0_1 = new android.content.ContentValues();
	        v0_1.put("quarantine_flag", p8);
	        return this.db.update("VirusInfo", v0_1, new StringBuilder("_id=").append(p6).toString(), 0);
	    }
	
