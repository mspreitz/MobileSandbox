	final synthetic com.safesys.viruskiller.ScanningManagerService this$0
	
	    public ScanningManagerService$ServiceHandler(com.safesys.viruskiller.ScanningManagerService p1, android.os.Looper p2)
	    {
	        this.this$0 = p1;
	        this(p2);
	        return;
	    }
	
	
	    public void handleMessage(android.os.Message p8)
	    {
	        super.handleMessage(p8);
	        if (p8.arg1 != 0) {
	            if (p8.arg1 != 1) {
	                if (p8.arg1 == 2) {
	                    com.safesys.viruskiller.ScanningManagerService.setiScannState(1);
	                    com.safesys.viruskiller.ScanningManagerService.access$0(this.this$0).scanPakages(com.safesys.viruskiller.ScanningManagerService.access$1(), com.safesys.viruskiller.MainActivity.getInstance());
	                    com.safesys.viruskiller.ScanningManagerService.access$0(this.this$0).scanFile(new java.io.File("/"), com.safesys.viruskiller.MainActivity.getInstance(), 0);
	                    com.safesys.viruskiller.MainActivity.getInstance().bPause = 0;
	                    com.safesys.viruskiller.MainActivity.getInstance().bStop = 1;
	                    com.safesys.viruskiller.MainActivity.getInstance().unclick();
	                    com.safesys.viruskiller.ScanningManagerService.setiScannState(0);
	                }
	            } else {
	                com.safesys.viruskiller.ScanningManagerService.setiScannState(1);
	                com.safesys.viruskiller.ScanningManagerService.access$0(this.this$0).scanPakages(com.safesys.viruskiller.ScanningManagerService.access$1(), com.safesys.viruskiller.MainActivity.getInstance());
	                com.safesys.viruskiller.ScanningManagerService.access$0(this.this$0).scanFile(new java.io.File("/"), com.safesys.viruskiller.MainActivity.getInstance(), 0);
	                com.safesys.viruskiller.MainActivity.getInstance().bPause = 0;
	                com.safesys.viruskiller.MainActivity.getInstance().bStop = 1;
	                com.safesys.viruskiller.MainActivity.getInstance().unclick();
	                com.safesys.viruskiller.ScanningManagerService.setiScannState(0);
	            }
	        } else {
	            com.safesys.viruskiller.ScanningManagerService.setiScannState(1);
	            com.safesys.viruskiller.ScanningManagerService.access$0(this.this$0).scanPakages(com.safesys.viruskiller.ScanningManagerService.access$1(), com.safesys.viruskiller.MainActivity.getInstance());
	            com.safesys.viruskiller.MainActivity.getInstance().bPause = 0;
	            com.safesys.viruskiller.MainActivity.getInstance().bStop = 1;
	            com.safesys.viruskiller.MainActivity.getInstance().unclick();
	            com.safesys.viruskiller.ScanningManagerService.setiScannState(0);
	        }
	        return;
	    }
	
