	final synthetic com.safesys.viruskiller.MainActivity$3 this$1
	private final synthetic java.lang.String val$sId
	
	    MainActivity$3$2(com.safesys.viruskiller.MainActivity$3 p1, String p2)
	    {
	        this.this$1 = p1;
	        this.val$sId = p2;
	        return;
	    }
	
	
	    public void run()
	    {
	        com.safesys.viruskiller.TrustedDBAdpter v0_1 = new com.safesys.viruskiller.TrustedDBAdpter(com.safesys.viruskiller.MainActivity.access$2());
	        v0_1.open();
	        v0_1.removeEntry(Long.valueOf(this.val$sId).longValue());
	        v0_1.close();
	        com.safesys.viruskiller.MainActivity$3.access$0(this.this$1).getTrustedNum();
	        com.safesys.viruskiller.MainActivity.access$5(com.safesys.viruskiller.MainActivity$3.access$0(this.this$1));
	        if (com.safesys.viruskiller.MainActivity$3.access$0(this.this$1).mum_threat_files == 0) {
	            com.safesys.viruskiller.MainActivity.access$7(com.safesys.viruskiller.MainActivity$3.access$0(this.this$1));
	        }
	        return;
	    }
	
