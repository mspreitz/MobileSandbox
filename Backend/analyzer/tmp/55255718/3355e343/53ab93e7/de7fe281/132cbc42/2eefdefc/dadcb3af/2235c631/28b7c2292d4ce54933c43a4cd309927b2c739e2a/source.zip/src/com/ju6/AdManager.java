	private static  a
	private static  b
	private static java.lang.String c
	private static java.lang.String d
	private static  e
	private static com.ju6.AdManager$Gender f
	private static java.util.GregorianCalendar g
	
	    static AdManager()
	    {
	        com.ju6.AdManager.a = 0;
	        com.ju6.AdManager.c = "";
	        com.ju6.AdManager.d = "";
	        com.ju6.AdManager.e = 0;
	        return;
	    }
	
	
	    public AdManager()
	    {
	        return;
	    }
	
	
	    public static long getAdTimestamp()
	    {
	        return com.ju6.AdManager.b;
	    }
	
	
	    public static String getAppid()
	    {
	        return com.ju6.AdManager.c;
	    }
	
	
	    public static java.util.GregorianCalendar getBirthday()
	    {
	        return com.ju6.AdManager.g;
	    }
	
	
	    public static String getBirthdayAsString()
	    {
	        String v0_0 = 0;
	        Integer v1_0 = com.ju6.AdManager.getBirthday();
	        if (v1_0 != null) {
	            Object[] v2_1 = new Object[3];
	            v2_1[0] = Integer.valueOf(v1_0.get(1));
	            v2_1[1] = Integer.valueOf((v1_0.get(2) + 1));
	            v2_1[2] = Integer.valueOf(v1_0.get(5));
	            v0_0 = String.format("%04d%02d%02d", v2_1);
	        }
	        return v0_0;
	    }
	
	
	    public static com.ju6.AdManager$Gender getGender()
	    {
	        return com.ju6.AdManager.f;
	    }
	
	
	    public static String getGenderAsString()
	    {
	        int v0_2;
	        if (com.ju6.AdManager.f != com.ju6.AdManager$Gender.MALE) {
	            if (com.ju6.AdManager.f != com.ju6.AdManager$Gender.FEMALE) {
	                v0_2 = 0;
	            } else {
	                v0_2 = "f";
	            }
	        } else {
	            v0_2 = "m";
	        }
	        return v0_2;
	    }
	
	
	    public static String getPwd()
	    {
	        return com.ju6.AdManager.d;
	    }
	
	
	    public static void init(String p0, String p1, boolean p2)
	    {
	        com.ju6.AdManager.c = p0;
	        com.ju6.AdManager.d = p1;
	        com.ju6.AdManager.e = p2;
	        return;
	    }
	
	
	    public static boolean isAdFinish()
	    {
	        return com.ju6.AdManager.a;
	    }
	
	
	    public static boolean isTestmode()
	    {
	        return com.ju6.AdManager.e;
	    }
	
	
	    public static void setAdFinish()
	    {
	        com.ju6.AdManager.a = 1;
	        return;
	    }
	
	
	    public static void setAdTimestamp()
	    {
	        com.ju6.AdManager.b = System.currentTimeMillis();
	        return;
	    }
	
	
	    public static void setBirthday(int p2, int p3, int p4)
	    {
	        java.util.GregorianCalendar v0_1 = new java.util.GregorianCalendar();
	        v0_1.set(p2, (p3 - 1), p4);
	        com.ju6.AdManager.setBirthday(v0_1);
	        return;
	    }
	
	
	    public static void setBirthday(java.util.GregorianCalendar p0)
	    {
	        com.ju6.AdManager.g = p0;
	        return;
	    }
	
	
	    public static void setGender(com.ju6.AdManager$Gender p0)
	    {
	        com.ju6.AdManager.f = p0;
	        return;
	    }
	
