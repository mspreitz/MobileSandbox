	public static final  CMD_DOWNLOAD
	public static final  CMD_PAUSE
	public static final  CMD_STOP
	public static final java.lang.String DOWNLOAD_CONTROL
	public static final  STATUS_DOWNLOADING
	public static final  STATUS_NEW_UPDATE
	public static final  STATUS_PAUSED
	public static final  STATUS_STOPPED
	public static java.lang.String SdkVersion
	public static final java.lang.String UPDATE_STATUS
	public static  blUpdate
	static android.os.Handler handler
	public static com.safesys.viruskiller.DownloadManageService instance
	static android.content.SharedPreferences preferences
	public static  update_flag
	 com.safesys.viruskiller.DownloadManageService$CommandReceiver doCommand
	 android.os.Looper localLooper
	  status
	 java.util.TimerTask task
	 java.util.Timer timer
	
	    static DownloadManageService()
	    {
	        com.safesys.viruskiller.DownloadManageService.update_flag = 0;
	        com.safesys.viruskiller.DownloadManageService.SdkVersion = "0.0.0";
	        com.safesys.viruskiller.DownloadManageService.blUpdate = 0;
	        return;
	    }
	
	
	    public DownloadManageService()
	    {
	        this.timer = new java.util.Timer(1);
	        this.task = new com.safesys.viruskiller.DownloadManageService$1(this);
	        return;
	    }
	
	
	    static synthetic void access$0(com.safesys.viruskiller.DownloadManageService p0)
	    {
	        p0.updateUi();
	        return;
	    }
	
	
	    public static void download()
	    {
	        new Thread(new com.safesys.viruskiller.DownloadManageService$2()).start();
	        return;
	    }
	
	
	    public static void saveUpdate()
	    {
	        com.safesys.viruskiller.DownloadManageService.blUpdate = 0;
	        android.content.SharedPreferences$Editor v0 = com.safesys.viruskiller.DownloadManageService.preferences.edit();
	        v0.putBoolean("download_autoupdate_flag", com.safesys.viruskiller.DownloadManageService.blUpdate);
	        v0.commit();
	        return;
	    }
	
	
	    private void updateUi()
	    {
	        android.content.Intent v0_1 = new android.content.Intent("DownloadManageServicer.ACTION_UPDATE");
	        v0_1.putExtra("status", this.status);
	        this.sendBroadcast(v0_1);
	        return;
	    }
	
	
	    public android.os.IBinder onBind(android.content.Intent p2)
	    {
	        return 0;
	    }
	
	
	    public void onCreate()
	    {
	        super.onCreate();
	        com.safesys.viruskiller.DownloadManageService.instance = this;
	        this.localLooper = this.getMainLooper();
	        com.safesys.viruskiller.DownloadManageService.handler = new android.os.Handler(this.localLooper);
	        com.safesys.viruskiller.DownloadManageService.preferences = this.getSharedPreferences("DownloadTerminatorPreferences", 0);
	        com.safesys.viruskiller.DownloadManageService.blUpdate = com.safesys.viruskiller.DownloadManageService.preferences.getBoolean("download_autoupdate_flag", 0);
	        this.status = 2;
	        this.doCommand = new com.safesys.viruskiller.DownloadManageService$CommandReceiver(this);
	        android.content.IntentFilter v0_1 = new android.content.IntentFilter();
	        v0_1.addAction("DownloadManageServicer.ACTION_CONTROL");
	        this.registerReceiver(this.doCommand, v0_1);
	        com.opensystem.terminator.VirusBackRunner.Init(0);
	        this.timer.schedule(this.task, new java.util.Date(), 86400000);
	        return;
	    }
	
	
	    public void onDestroy()
	    {
	        super.onDestroy();
	        this.timer.cancel();
	        this.unregisterReceiver(this.doCommand);
	        return;
	    }
	
	
	    public void onStart(android.content.Intent p1, int p2)
	    {
	        super.onStart(p1, p2);
	        return;
	    }
	
