	final synthetic com.safesys.viruskiller.MainActivity this$0
	
	    MainActivity$UpdateUIRunTask(com.safesys.viruskiller.MainActivity p1)
	    {
	        this.this$0 = p1;
	        return;
	    }
	
	
	    protected varargs Boolean doInBackground(Object[] p2)
	    {
	        this.publishProgress(p2);
	        return 0;
	    }
	
	
	    protected varargs bridge synthetic Object doInBackground(Object[] p2)
	    {
	        return this.doInBackground(((Object[]) p2));
	    }
	
	
	    protected void onPostExecute(Boolean p2)
	    {
	        try {
	            this.finalize();
	        } catch (Throwable v0) {
	            v0.printStackTrace();
	        }
	        return;
	    }
	
	
	    protected bridge synthetic void onPostExecute(Object p1)
	    {
	        this.onPostExecute(((Boolean) p1));
	        return;
	    }
	
	
	    protected varargs void onProgressUpdate(Object[] p5)
	    {
	        String v0 = p5[0].toString();
	        if (!v0.equals("updateScanPad")) {
	            if (v0.equals("updateMainPad")) {
	                this.this$0.ly_main.setVisibility(0);
	                com.safesys.viruskiller.MainActivity.access$7(this.this$0);
	                this.this$0.ly_scan.setVisibility(8);
	                this.this$0.ly_scaned.setVisibility(0);
	                this.this$0.ly_scanning.setVisibility(8);
	            }
	        } else {
	            this.this$0.ly_main.setVisibility(8);
	            this.this$0.getQuarantineNum();
	            this.this$0.ly_scan.setVisibility(0);
	            this.this$0.ly_scaned.setVisibility(8);
	            this.this$0.ly_scanning.setVisibility(0);
	        }
	        return;
	    }
	
