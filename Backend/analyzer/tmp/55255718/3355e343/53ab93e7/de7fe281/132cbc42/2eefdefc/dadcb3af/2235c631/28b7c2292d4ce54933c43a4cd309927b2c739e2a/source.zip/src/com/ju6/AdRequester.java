	private android.content.Context a
	private com.ju6.AdListener b
	
	    public AdRequester(android.content.Context p1)
	    {
	        this.a = p1;
	        return;
	    }
	
	
	    public void getAd()
	    {
	        new com.ju6.a(this.a, this.b).start();
	        return;
	    }
	
	
	    public void setAdListener(com.ju6.AdListener p2)
	    {
	        try {
	            this.b = p2;
	        } catch (Exception v0) {
	        }
	        return;
	    }
	
