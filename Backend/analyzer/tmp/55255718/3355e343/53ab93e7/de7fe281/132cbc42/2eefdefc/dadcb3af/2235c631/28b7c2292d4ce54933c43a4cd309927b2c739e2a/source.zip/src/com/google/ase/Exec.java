	
	    static Exec()
	    {
	        System.loadLibrary("openterm");
	        return;
	    }
	
	
	    public Exec()
	    {
	        return;
	    }
	
