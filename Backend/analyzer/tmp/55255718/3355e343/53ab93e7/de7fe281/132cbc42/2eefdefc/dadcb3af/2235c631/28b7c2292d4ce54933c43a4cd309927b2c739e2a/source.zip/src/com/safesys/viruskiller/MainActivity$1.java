	final synthetic com.safesys.viruskiller.MainActivity this$0
	private final synthetic java.lang.String val$strPath
	
	    MainActivity$1(com.safesys.viruskiller.MainActivity p1, String p2)
	    {
	        this.this$0 = p1;
	        this.val$strPath = p2;
	        return;
	    }
	
	
	    public void run()
	    {
	        this.this$0.main_scanning_filename.setText(this.val$strPath);
	        this.this$0.main_scanning_danger.setText(new StringBuilder().append(this.this$0.mum_threat_files).toString());
	        this.this$0.main_scanning_filecount.setText(new StringBuilder().append(this.this$0.mum_scanned_files).toString());
	        if (this.this$0.mum_threat_files > 0) {
	            com.safesys.viruskiller.MainActivity.access$8(this.this$0);
	        }
	        this.this$0.fillData();
	        return;
	    }
	
