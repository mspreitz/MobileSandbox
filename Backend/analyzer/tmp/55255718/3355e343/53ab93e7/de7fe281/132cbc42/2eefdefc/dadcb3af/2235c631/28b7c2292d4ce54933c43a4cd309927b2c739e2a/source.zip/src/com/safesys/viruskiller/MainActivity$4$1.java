	final synthetic com.safesys.viruskiller.MainActivity$4 this$1
	
	    MainActivity$4$1(com.safesys.viruskiller.MainActivity$4 p1)
	    {
	        this.this$1 = p1;
	        return;
	    }
	
	
	    public void run()
	    {
	        com.safesys.viruskiller.MainActivity$4.access$0(this.this$1).main_scanning_progress.AlterValue(296);
	        return;
	    }
	
