	final synthetic com.safesys.viruskiller.MainActivity this$0
	
	    MainActivity$9(com.safesys.viruskiller.MainActivity p1)
	    {
	        this.this$0 = p1;
	        return;
	    }
	
	
	    public void run()
	    {
	        this.this$0.main_button_rapid.setBackgroundResource(2130837560);
	        this.this$0.main_button_global.setBackgroundResource(2130837556);
	        this.this$0.main_button_super.setBackgroundResource(2130837568);
	        this.this$0.main_scan_quit.setText(this.this$0.getString(2131099666));
	        this.this$0.main_scanning_filename.setText(this.this$0.getString(2131099689));
	        return;
	    }
	
