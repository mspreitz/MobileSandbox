	final synthetic com.safesys.viruskiller.DownloadManageService$CommandReceiver this$1
	
	    DownloadManageService$CommandReceiver$1(com.safesys.viruskiller.DownloadManageService$CommandReceiver p1)
	    {
	        this.this$1 = p1;
	        return;
	    }
	
	
	    public void run()
	    {
	        try {
	            Thread.currentThread();
	            Thread.sleep(300);
	        } catch (com.safesys.viruskiller.DownloadManageService v3_1) {
	            v3_1.printStackTrace();
	        }
	        if (com.opensystem.terminator.VirusBackRunner.queryOBackground("", 0) == null) {
	            com.safesys.viruskiller.DownloadManageService$CommandReceiver.access$0(this.this$1).status = 2;
	        } else {
	            com.opensystem.terminator.ScanVirus.Init();
	            com.safesys.viruskiller.DownloadManageService$CommandReceiver.access$0(this.this$1).status = 1;
	        }
	        android.content.Intent v1_1 = new android.content.Intent("DownloadManageServicer.ACTION_UPDATE");
	        v1_1.putExtra("status", com.safesys.viruskiller.DownloadManageService$CommandReceiver.access$0(this.this$1).status);
	        com.safesys.viruskiller.DownloadManageService$CommandReceiver.access$0(this.this$1).sendBroadcast(v1_1);
	        return;
	    }
	
