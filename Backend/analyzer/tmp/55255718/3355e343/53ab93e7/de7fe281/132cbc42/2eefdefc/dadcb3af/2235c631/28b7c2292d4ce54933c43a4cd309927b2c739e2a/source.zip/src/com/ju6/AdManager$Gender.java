	public static final enum com.ju6.AdManager$Gender FEMALE
	public static final enum com.ju6.AdManager$Gender MALE
	private static final synthetic Lcom.ju6.AdManager$Gender a
	
	    static AdManager$Gender()
	    {
	        com.ju6.AdManager$Gender.MALE = new com.ju6.AdManager$Gender("MALE", 0);
	        com.ju6.AdManager$Gender.FEMALE = new com.ju6.AdManager$Gender("FEMALE", 1);
	        com.ju6.AdManager$Gender[] v0_5 = new com.ju6.AdManager$Gender[2];
	        v0_5[0] = com.ju6.AdManager$Gender.MALE;
	        v0_5[1] = com.ju6.AdManager$Gender.FEMALE;
	        com.ju6.AdManager$Gender.a = v0_5;
	        return;
	    }
	
	
	    private AdManager$Gender(String p1, int p2)
	    {
	        this(p1, p2);
	        return;
	    }
	
	
	    public static com.ju6.AdManager$Gender valueOf(String p1)
	    {
	        return ((com.ju6.AdManager$Gender) Enum.valueOf(com.ju6.AdManager$Gender, p1));
	    }
	
	
	    public static com.ju6.AdManager$Gender[] values()
	    {
	        com.ju6.AdManager$Gender[] v0 = com.ju6.AdManager$Gender.a;
	        int v1 = v0.length;
	        com.ju6.AdManager$Gender[] v2 = new com.ju6.AdManager$Gender[v1];
	        System.arraycopy(v0, 0, v2, 0, v1);
	        return v2;
	    }
	
