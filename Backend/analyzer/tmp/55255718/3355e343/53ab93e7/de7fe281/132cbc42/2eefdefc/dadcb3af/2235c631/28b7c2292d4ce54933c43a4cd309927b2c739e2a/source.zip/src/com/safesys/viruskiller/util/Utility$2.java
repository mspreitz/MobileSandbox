	final synthetic com.safesys.viruskiller.util.Utility this$0
	private final synthetic android.os.Handler val$handler
	private final synthetic  val$procId
	
	    Utility$2(com.safesys.viruskiller.util.Utility p1, int p2, android.os.Handler p3)
	    {
	        this.this$0 = p1;
	        this.val$procId = p2;
	        this.val$handler = p3;
	        return;
	    }
	
	
	    public void run()
	    {
	        android.util.Log.i("Terminator", new StringBuilder("waiting for: ").append(this.val$procId).toString());
	        int v0 = com.google.ase.Exec.waitFor(this.val$procId);
	        android.util.Log.i("Terminator", new StringBuilder("Subprocess exited: ").append(v0).toString());
	        this.val$handler.sendEmptyMessage(v0);
	        return;
	    }
	
