	public static final  main
	public static final  payment
	public static final  quarantine_row
	public static final  scan_result_row
	
	    public R$layout()
	    {
	        return;
	    }
	
