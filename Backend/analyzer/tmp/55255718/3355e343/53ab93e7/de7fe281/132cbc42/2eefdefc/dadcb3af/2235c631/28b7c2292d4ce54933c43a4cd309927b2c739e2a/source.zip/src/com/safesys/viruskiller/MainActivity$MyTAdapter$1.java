	final synthetic com.safesys.viruskiller.MainActivity$MyTAdapter this$1
	private final synthetic java.lang.String val$strVirusId
	
	    MainActivity$MyTAdapter$1(com.safesys.viruskiller.MainActivity$MyTAdapter p1, String p2)
	    {
	        this.this$1 = p1;
	        this.val$strVirusId = p2;
	        return;
	    }
	
	
	    static synthetic com.safesys.viruskiller.MainActivity$MyTAdapter access$0(com.safesys.viruskiller.MainActivity$MyTAdapter$1 p1)
	    {
	        return p1.this$1;
	    }
	
	
	    public void onClick(android.view.View p4)
	    {
	        com.safesys.viruskiller.MainActivity$MyTAdapter.access$0(this.this$1).handler.post(new com.safesys.viruskiller.MainActivity$MyTAdapter$1$1(this, this.val$strVirusId));
	        return;
	    }
	
