	
	    public VirusDBAdpter$MyDbHelper(android.content.Context p1, String p2, android.database.sqlite.SQLiteDatabase$CursorFactory p3, int p4)
	    {
	        this(p1, p2, p3, p4);
	        return;
	    }
	
	
	    public void onCreate(android.database.sqlite.SQLiteDatabase p2)
	    {
	        p2.execSQL("create table VirusInfo (_id integer primary key autoincrement, virus_name text not null, virus_desc text, virus_path text not null, virus_grade text not null, del_flag text not null, quarantine_flag text not null, quarantine_datetime text not null,quarantine_path text not null,virus_bak text not null);");
	        return;
	    }
	
	
	    public void onUpgrade(android.database.sqlite.SQLiteDatabase p2, int p3, int p4)
	    {
	        p2.execSQL("DROP TABLE IF EXISTS VirusInfo");
	        this.onCreate(p2);
	        return;
	    }
	
