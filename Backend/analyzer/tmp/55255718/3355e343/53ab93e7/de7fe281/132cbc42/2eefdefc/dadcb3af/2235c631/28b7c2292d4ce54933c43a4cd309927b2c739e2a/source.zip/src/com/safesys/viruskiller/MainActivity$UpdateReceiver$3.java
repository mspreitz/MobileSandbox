	final synthetic com.safesys.viruskiller.MainActivity$UpdateReceiver this$1
	
	    MainActivity$UpdateReceiver$3(com.safesys.viruskiller.MainActivity$UpdateReceiver p1)
	    {
	        this.this$1 = p1;
	        return;
	    }
	
	
	    public void run()
	    {
	        if (com.safesys.viruskiller.MainActivity$UpdateReceiver.access$0(this.this$1).strUpdate == null) {
	            com.safesys.viruskiller.MainActivity$UpdateReceiver.access$0(this.this$1).copyright_info.setText(new StringBuilder(String.valueOf(com.safesys.viruskiller.MainActivity$UpdateReceiver.access$0(this.this$1).getString(2131099650))).append(" ").toString());
	        } else {
	            com.safesys.viruskiller.MainActivity$UpdateReceiver.access$0(this.this$1).copyright_info.setText(new StringBuilder(String.valueOf(com.safesys.viruskiller.MainActivity$UpdateReceiver.access$0(this.this$1).getString(2131099650))).append(" ").append(com.safesys.viruskiller.MainActivity$UpdateReceiver.access$0(this.this$1).strUpdate).toString());
	        }
	        if (com.safesys.viruskiller.MainActivity$UpdateReceiver.access$0(this.this$1).flag_autoupdate) {
	            com.safesys.viruskiller.MainActivity.access$1(com.safesys.viruskiller.MainActivity$UpdateReceiver.access$0(this.this$1)).setBackgroundResource(2130837537);
	            com.safesys.viruskiller.MainActivity.access$1(com.safesys.viruskiller.MainActivity$UpdateReceiver.access$0(this.this$1)).setGravity(49);
	            com.safesys.viruskiller.MainActivity.access$1(com.safesys.viruskiller.MainActivity$UpdateReceiver.access$0(this.this$1)).setPadding(0, 5, 7, 0);
	            com.safesys.viruskiller.MainActivity$UpdateReceiver.access$0(this.this$1).flag_autoupdate = 0;
	            android.content.SharedPreferences$Editor v0 = com.safesys.viruskiller.MainActivity.preferences.edit();
	            v0.putBoolean("virus_autoupdate_flag", 0);
	            v0.commit();
	        }
	        android.widget.Toast.makeText(com.safesys.viruskiller.MainActivity.access$2(), com.safesys.viruskiller.MainActivity$UpdateReceiver.access$0(this.this$1).getString(2131099679), 1).show();
	        return;
	    }
	
