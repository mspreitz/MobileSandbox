	public static final  app_name
	public static final  continue_scan_text
	public static final  copyright_info
	public static final  deal_scan_text
	public static final  donate_content
	public static final  donate_text
	public static final  exit_dialog_text
	public static final  exit_dialog_tip
	public static final  exit_text
	public static final  global_scan_memo
	public static final  global_scan_text
	public static final  main_scan_back_txt
	public static final  main_scan_background_txt
	public static final  main_scan_defense_txt
	public static final  main_scan_start_txt
	public static final  main_scan_update_txt
	public static final  main_scanning_end
	public static final  notification_info
	public static final  pause_scan_text
	public static final  product_memo
	public static final  quarantine_empty
	public static final  quarantine_scan_memo
	public static final  quarantine_scan_text
	public static final  rapid_scan_memo
	public static final  rapid_scan_text
	public static final  stop_scan_text
	public static final  super_scan_memo
	public static final  super_scan_text
	public static final  threat_scan_text
	public static final  time_scan_text
	public static final  totle_scan_text
	public static final  trusted_Btn_text
	public static final  trusted_scan_text
	public static final  virus_cancel_memo
	public static final  virus_clear_memo
	public static final  virus_installinfo_tip
	public static final  virus_remove_memo
	public static final  virus_updateinfo_fail
	public static final  virus_updateinfo_memo
	public static final  virus_updateversion_content
	public static final  virus_updateversion_tip
	public static final  virus_updating_tip
	
	    public R$string()
	    {
	        return;
	    }
	
