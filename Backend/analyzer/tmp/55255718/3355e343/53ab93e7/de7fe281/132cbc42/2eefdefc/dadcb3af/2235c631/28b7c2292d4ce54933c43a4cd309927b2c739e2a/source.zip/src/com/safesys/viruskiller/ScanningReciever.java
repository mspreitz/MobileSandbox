	private static final java.lang.String BOOT_COMPLETED_ACTION
	private static final java.lang.String INCOMING_CALL_ACTION
	private static final java.lang.String OUTGOING_CALL_ACTION
	
	    public ScanningReciever()
	    {
	        return;
	    }
	
	
	    public void onReceive(android.content.Context p6, android.content.Intent p7)
	    {
	        String v0 = p7.getAction();
	        p7.getExtras();
	        if ((v0.equals("android.intent.action.BOOT_COMPLETED")) && (com.safesys.viruskiller.MainActivity.getInstance() == null)) {
	            android.content.Intent v2_1 = new android.content.Intent(p6, com.safesys.viruskiller.ScanningManagerService);
	            v2_1.putExtra("state", -1);
	            com.safesys.viruskiller.ScanningManagerService.beginStartingService(p6, v2_1);
	            com.safesys.viruskiller.util.Utility.getInitNotification(com.safesys.viruskiller.MainActivity.nm, com.safesys.viruskiller.MainActivity.notification_id, p6);
	        }
	        return;
	    }
	
