	final synthetic com.safesys.viruskiller.MyWebChromeClient this$0
	private final synthetic android.webkit.JsPromptResult val$result
	
	    MyWebChromeClient$7(com.safesys.viruskiller.MyWebChromeClient p1, android.webkit.JsPromptResult p2)
	    {
	        this.this$0 = p1;
	        this.val$result = p2;
	        return;
	    }
	
	
	    public void onClick(android.content.DialogInterface p2, int p3)
	    {
	        this.val$result.cancel();
	        return;
	    }
	
