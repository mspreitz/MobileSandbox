	
	    public ScanPackageBroadcast()
	    {
	        return;
	    }
	
	
	    public void onReceive(android.content.Context p6, android.content.Intent p7)
	    {
	        if (!"android.intent.action.PACKAGE_ADDED".equals(p7.getAction())) {
	            if (!"android.intent.action.PACKAGE_REMOVED".equals(p7.getAction())) {
	                if ("android.intent.action.PACKAGE_REPLACED".equals(p7.getAction())) {
	                    android.widget.Toast.makeText(p6, p6.getString(2131099680), 1).show();
	                    com.safesys.viruskiller.MainActivity v0_0 = com.safesys.viruskiller.MainActivity.getInstance();
	                    if ((v0_0 != null) && (v0_0.flag_defense)) {
	                        v0_0.main_button_rapid.performClick();
	                    }
	                }
	            } else {
	                com.safesys.viruskiller.MainActivity v0_1 = com.safesys.viruskiller.MainActivity.getInstance();
	                if (v0_1 != null) {
	                    v0_1.dealUninstall();
	                }
	            }
	        } else {
	            android.widget.Toast.makeText(p6, p6.getString(2131099680), 1).show();
	            com.safesys.viruskiller.MainActivity v0_2 = com.safesys.viruskiller.MainActivity.getInstance();
	            if ((v0_2 != null) && (v0_2.flag_defense)) {
	                v0_2.main_button_rapid.performClick();
	            }
	        }
	        return;
	    }
	
