	final synthetic com.safesys.viruskiller.MainActivity this$0
	
	    MainActivity$2(com.safesys.viruskiller.MainActivity p1)
	    {
	        this.this$0 = p1;
	        return;
	    }
	
	
	    public void onClick(android.view.View p8)
	    {
	        if (!this.this$0.isRecommend) {
	            String v1 = this.this$0.getResources().getConfiguration().locale.getCountry();
	            if ((v1 == null) || (!v1.equals("CN"))) {
	                android.content.Intent v0_1 = new android.content.Intent("android.intent.action.VIEW");
	                v0_1.setData(com.safesys.viruskiller.MainActivity.DONATE_PAYPAL_URI);
	                v0_1.setFlags(272629760);
	                this.this$0.startActivity(v0_1);
	            } else {
	                this.this$0.webview.loadUrl("http://www.cqimti.com/market/eoe/mk_recommend.html");
	                if (this.this$0.isFirst) {
	                    this.this$0.isFirst = 0;
	                }
	                this.this$0.handle_menu.setVisibility(8);
	                this.this$0.line.setVisibility(8);
	                this.this$0.ly_main.setVisibility(8);
	                this.this$0.donate.setText("");
	                this.this$0.donate.setBackgroundResource(2130837550);
	                this.this$0.title_explain.setText("\u5b89\u5168\u8ba4\u8bc1\u3000\u4f7f\u7528\u653e\u5fc3");
	                this.this$0.ly_recommend.setVisibility(0);
	                this.this$0.isRecommend = 1;
	                com.safesys.viruskiller.MainActivity.access$9(this.this$0, 0);
	            }
	        } else {
	            this.this$0.handle_menu.setVisibility(0);
	            this.this$0.line.setVisibility(0);
	            this.this$0.ly_main.setVisibility(0);
	            this.this$0.donate.setText("\u63a8\u8350");
	            this.this$0.donate.setBackgroundResource(2130837553);
	            this.this$0.title_explain.setText("\u4e13\u4e1a\u6740\u6bd2\u3000\u6c38\u4e45\u514d\u8d39");
	            this.this$0.ly_recommend.setVisibility(8);
	            this.this$0.isRecommend = 0;
	            com.safesys.viruskiller.MainActivity.access$9(this.this$0, 1);
	        }
	        return;
	    }
	
