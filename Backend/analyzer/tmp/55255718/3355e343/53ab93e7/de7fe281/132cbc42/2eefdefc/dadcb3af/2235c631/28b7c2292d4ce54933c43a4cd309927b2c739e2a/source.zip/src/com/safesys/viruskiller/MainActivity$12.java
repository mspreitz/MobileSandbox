	final synthetic com.safesys.viruskiller.MainActivity this$0
	
	    MainActivity$12(com.safesys.viruskiller.MainActivity p1)
	    {
	        this.this$0 = p1;
	        return;
	    }
	
	
	    public void run()
	    {
	        this.this$0.copyright_info.setText(new StringBuilder(String.valueOf(this.this$0.getString(2131099650))).append(" ").append(this.this$0.getString(2131099681)).toString());
	        return;
	    }
	
