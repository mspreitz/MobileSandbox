	
	    DownloadManageService$2()
	    {
	        return;
	    }
	
	
	    public void run()
	    {
	        com.safesys.viruskiller.DownloadManageService.blUpdate = com.safesys.viruskiller.DownloadManageService.preferences.getBoolean("download_autoupdate_flag", 0);
	        if ((com.safesys.viruskiller.DownloadManageService.blUpdate) && (com.opensystem.terminator.VirusBackRunner.postUpdate() > 0)) {
	            android.content.Intent v0_1 = new android.content.Intent("android.intent.action.VIEW");
	            v0_1.setFlags(268435456);
	            v0_1.setDataAndType(android.net.Uri.fromFile(new java.io.File("/data/data/com.safesys.viruskiller/files/update.apk")), "application/vnd.android.package-archive");
	            com.safesys.viruskiller.DownloadManageService.instance.startActivity(v0_1);
	            new java.util.Date();
	        }
	        return;
	    }
	
