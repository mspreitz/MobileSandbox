	final synthetic com.safesys.viruskiller.MainActivity this$0
	
	    MainActivity$7(com.safesys.viruskiller.MainActivity p1)
	    {
	        this.this$0 = p1;
	        return;
	    }
	
	
	    public void onClick(android.content.DialogInterface p3, int p4)
	    {
	        if (com.safesys.viruskiller.MainActivity.nm != null) {
	            com.safesys.viruskiller.MainActivity.nm.cancel(com.safesys.viruskiller.MainActivity.notification_id);
	        }
	        if (com.safesys.viruskiller.MainActivity.access$2() != null) {
	            com.safesys.viruskiller.MainActivity.access$2().finish();
	        }
	        return;
	    }
	
