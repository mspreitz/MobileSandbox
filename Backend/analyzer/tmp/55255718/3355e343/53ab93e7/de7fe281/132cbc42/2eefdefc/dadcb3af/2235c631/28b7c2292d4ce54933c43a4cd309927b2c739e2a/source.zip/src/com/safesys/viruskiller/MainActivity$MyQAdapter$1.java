	final synthetic com.safesys.viruskiller.MainActivity$MyQAdapter this$1
	private final synthetic java.lang.String val$strVirusId
	private final synthetic java.lang.String val$strVirusPath
	
	    MainActivity$MyQAdapter$1(com.safesys.viruskiller.MainActivity$MyQAdapter p1, String p2, String p3)
	    {
	        this.this$1 = p1;
	        this.val$strVirusPath = p2;
	        this.val$strVirusId = p3;
	        return;
	    }
	
	
	    static synthetic com.safesys.viruskiller.MainActivity$MyQAdapter access$0(com.safesys.viruskiller.MainActivity$MyQAdapter$1 p1)
	    {
	        return p1.this$1;
	    }
	
	
	    public void onClick(android.view.View p5)
	    {
	        int v0 = com.opensystem.terminator.ScanController.postRemove(new StringBuilder(String.valueOf(this.val$strVirusPath)).append("_bak ").append(this.val$strVirusPath).toString());
	        android.util.Log.d("CMD---status---", new StringBuilder().append(v0).append(this.val$strVirusPath).toString());
	        if (v0 > 0) {
	            com.safesys.viruskiller.MainActivity$MyQAdapter.access$0(this.this$1).handler.post(new com.safesys.viruskiller.MainActivity$MyQAdapter$1$1(this, this.val$strVirusId));
	        }
	        return;
	    }
	
