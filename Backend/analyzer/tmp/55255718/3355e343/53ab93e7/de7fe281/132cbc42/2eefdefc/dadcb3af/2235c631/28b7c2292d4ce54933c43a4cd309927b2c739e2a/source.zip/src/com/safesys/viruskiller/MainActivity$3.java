	final synthetic com.safesys.viruskiller.MainActivity this$0
	
	    MainActivity$3(com.safesys.viruskiller.MainActivity p1)
	    {
	        this.this$0 = p1;
	        return;
	    }
	
	
	    static synthetic com.safesys.viruskiller.MainActivity access$0(com.safesys.viruskiller.MainActivity$3 p1)
	    {
	        return p1.this$0;
	    }
	
	
	    public void onClick(android.view.View p12)
	    {
	        android.util.Log.d("##############", new StringBuilder("----------------").append(com.safesys.viruskiller.MainActivity.bTrusted).toString());
	        if (com.safesys.viruskiller.MainActivity.bTrusted) {
	            if (com.safesys.viruskiller.MainActivity.listTrusted != null) {
	                int v1_0 = 0;
	                while (v1_0 < com.safesys.viruskiller.MainActivity.listTrusted.size()) {
	                    this.this$0.handler.post(new com.safesys.viruskiller.MainActivity$3$2(this, ((android.content.ContentValues) com.safesys.viruskiller.MainActivity.listTrusted.get(v1_0)).getAsString("_id")));
	                    v1_0++;
	                }
	            }
	        } else {
	            if (com.safesys.viruskiller.MainActivity.listValue != null) {
	                int v1_1 = 0;
	                while (v1_1 < com.safesys.viruskiller.MainActivity.listValue.size()) {
	                    android.content.ContentValues v6_3 = ((android.content.ContentValues) com.safesys.viruskiller.MainActivity.listValue.get(v1_1));
	                    new java.util.HashMap();
	                    String v5 = v6_3.getAsString("virus_path");
	                    String v3_1 = v6_3.getAsString("_id");
	                    String v2 = v6_3.getAsString("virus_bak");
	                    if (com.opensystem.terminator.ScanController.onceRemove(new StringBuilder(String.valueOf(v5)).append("_bak").toString()) > 0) {
	                        this.this$0.handler.post(new com.safesys.viruskiller.MainActivity$3$1(this, v3_1, v2));
	                    }
	                    v1_1++;
	                }
	            }
	        }
	        com.safesys.viruskiller.MainActivity.access$10(this.this$0);
	        com.safesys.viruskiller.MainActivity.access$9(this.this$0, 1);
	        return;
	    }
	
