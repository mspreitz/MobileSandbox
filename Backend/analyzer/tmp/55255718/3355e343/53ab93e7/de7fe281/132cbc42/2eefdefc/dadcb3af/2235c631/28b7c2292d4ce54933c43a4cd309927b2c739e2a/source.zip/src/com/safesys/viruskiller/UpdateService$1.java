	final synthetic com.safesys.viruskiller.UpdateService this$0
	
	    UpdateService$1(com.safesys.viruskiller.UpdateService p1)
	    {
	        this.this$0 = p1;
	        return;
	    }
	
	
	    public void run()
	    {
	        com.safesys.viruskiller.UpdateService.access$1(this.this$0);
	        return;
	    }
	
