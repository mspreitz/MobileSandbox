	final synthetic com.safesys.viruskiller.MainActivity this$0
	
	    MainActivity$5(com.safesys.viruskiller.MainActivity p1)
	    {
	        this.this$0 = p1;
	        return;
	    }
	
	
	    public void onClick(android.content.DialogInterface p2, int p3)
	    {
	        com.safesys.viruskiller.DownloadManageService.update_flag = 1;
	        com.safesys.viruskiller.DownloadManageService.download();
	        return;
	    }
	
