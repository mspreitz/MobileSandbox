	public java.lang.String a
	public java.lang.String b
	
	    b()
	    {
	        return;
	    }
	
