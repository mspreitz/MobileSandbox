	final synthetic com.safesys.viruskiller.ShowTips this$0
	
	    ShowTips$1(com.safesys.viruskiller.ShowTips p1)
	    {
	        this.this$0 = p1;
	        return;
	    }
	
	
	    public void onClick(android.content.DialogInterface p4, int p5)
	    {
	        android.content.Intent v0 = this.this$0.getPackageManager().getLaunchIntentForPackage("com.noshufou.android.su");
	        v0.setFlags(268435456);
	        this.this$0.startActivity(v0);
	        this.this$0.finish();
	        return;
	    }
	
