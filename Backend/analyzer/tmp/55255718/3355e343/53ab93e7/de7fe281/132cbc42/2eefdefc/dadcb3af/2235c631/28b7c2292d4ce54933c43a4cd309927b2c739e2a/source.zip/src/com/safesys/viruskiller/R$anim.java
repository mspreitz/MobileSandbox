	public static final  popup_enter
	public static final  popup_exit
	
	    public R$anim()
	    {
	        return;
	    }
	
