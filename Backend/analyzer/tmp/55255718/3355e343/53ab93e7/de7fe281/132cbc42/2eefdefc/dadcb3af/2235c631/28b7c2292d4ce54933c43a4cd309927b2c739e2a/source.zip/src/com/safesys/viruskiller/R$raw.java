	public static final  mycfg
	public static final  myvr
	public static final  vrcore
	
	    public R$raw()
	    {
	        return;
	    }
	
