	final synthetic com.safesys.viruskiller.MainActivity this$0
	private final synthetic com.safesys.viruskiller.Virus val$v
	
	    MainActivity$11(com.safesys.viruskiller.MainActivity p1, com.safesys.viruskiller.Virus p2)
	    {
	        this.this$0 = p1;
	        this.val$v = p2;
	        return;
	    }
	
	
	    public void run()
	    {
	        com.safesys.viruskiller.TrustedDBAdpter v0_1 = new com.safesys.viruskiller.TrustedDBAdpter(com.safesys.viruskiller.MainActivity.access$2());
	        v0_1.open();
	        v0_1.insertVirusEntry(this.val$v.getVirusName(), this.val$v.getVirusDesc(), this.val$v.getVirusPath(), "0", "0", new StringBuilder(String.valueOf(java.util.Calendar.getInstance().getTimeInMillis())).toString(), new StringBuilder(String.valueOf(this.val$v.getVirusPath())).append("_bak").toString(), this.val$v.getVirusPackageName());
	        v0_1.close();
	        this.this$0.dealTrustedUpdate(this.val$v);
	        return;
	    }
	
