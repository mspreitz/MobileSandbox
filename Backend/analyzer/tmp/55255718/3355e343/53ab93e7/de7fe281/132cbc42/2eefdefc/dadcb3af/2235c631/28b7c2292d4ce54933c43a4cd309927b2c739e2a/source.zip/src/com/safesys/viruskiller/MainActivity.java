	public static final android.net.Uri DONATE_PAYPAL_URI
	private static final  ISEXIT_DIALOG
	private static final  MENU_EXIT
	private static final  UPDATETIP_DIALOG
	public static  bTrusted
	private static com.safesys.viruskiller.MainActivity instance
	public static java.util.ArrayList listTrusted
	public static java.util.ArrayList listValue
	public static android.app.NotificationManager nm
	public static  notification_id
	public static android.content.SharedPreferences preferences
	public static java.util.List virusList
	  bPause
	  bStop
	  bThread
	public android.widget.Button clear
	 java.lang.String cmd
	public android.widget.TextView copyright_info
	 com.safesys.viruskiller.MainActivity$UpdateReceiver doUpdate
	public android.widget.Button donate
	  flag_autoupdate
	  flag_defense
	  flag_killing
	  flag_poweredup
	public android.widget.RelativeLayout frame_introduce
	private android.widget.Button fun_autoupdate
	private android.widget.Button fun_defense
	private android.widget.Button fun_killing
	private android.widget.Button fun_poweredup
	public android.widget.RelativeLayout handle_menu
	 android.os.Handler handler
	private  iMainUI
	  iSeconds
	  isFirst
	  isRecommend
	 android.view.View line
	private android.widget.ProgressBar loadingtip
	public android.widget.TextView loadtip
	 android.os.Looper localLooper
	public android.widget.RelativeLayout ly_main
	public android.widget.RelativeLayout ly_recommend
	public android.widget.RelativeLayout ly_scan
	public android.widget.RelativeLayout ly_scaned
	public android.widget.RelativeLayout ly_scanning
	public android.widget.RelativeLayout ly_segregate
	public android.widget.Button main_button_global
	public android.widget.Button main_button_rapid
	public android.widget.Button main_button_segregate
	public android.widget.Button main_button_super
	public android.widget.Button main_scan_believe
	public android.widget.Button main_scan_deal
	public android.widget.Button main_scan_pause
	public android.widget.Button main_scan_quit
	public android.widget.TextView main_scanning_danger
	public android.widget.TextView main_scanning_filecount
	public android.widget.TextView main_scanning_filename
	 android.widget.ListView main_scanning_list
	 com.safesys.viruskiller.view.MyProcessBar main_scanning_progress
	public android.widget.TextView main_scanning_time
	public android.widget.Button main_trust_area
	 java.util.Map mapArray
	public android.widget.ImageView mk_recommend
	public  mum_scanned_files
	public  mum_threat_files
	private com.safesys.viruskiller.MainActivity$MyAdapter myadapter
	 com.safesys.viruskiller.MainActivity$UIReceiver receiver
	public android.widget.TextView seg_empty
	 android.widget.RelativeLayout seg_handle
	private android.widget.Button seg_recovery
	 java.lang.String strUpdate
	private java.lang.Thread thTime
	public android.widget.TextView title_explain
	private com.safesys.viruskiller.util.Utility utils
	public android.widget.Button virus_back
	 android.webkit.WebView webview
	
	    static MainActivity()
	    {
	        com.safesys.viruskiller.MainActivity.instance = 0;
	        com.safesys.viruskiller.MainActivity.bTrusted = 0;
	        com.safesys.viruskiller.MainActivity.virusList = new java.util.ArrayList();
	        com.safesys.viruskiller.MainActivity.notification_id = 79034139;
	        com.safesys.viruskiller.MainActivity.DONATE_PAYPAL_URI = android.net.Uri.parse("https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=xiaokemengling%40163%2ecom&lc=C2&item_name=Virus%20Terminator&button_subtype=services&currency_code=USD&bn=PP%2dBuyNowBF%3abtn_buynowCC_LG%2egif%3aNonHosted");
	        return;
	    }
	
	
	    public MainActivity()
	    {
	        this.utils = new com.safesys.viruskiller.util.Utility();
	        this.iMainUI = 1;
	        this.thTime = 0;
	        this.bThread = 0;
	        this.bStop = 0;
	        this.bPause = 0;
	        this.iSeconds = 0;
	        this.mapArray = new java.util.HashMap();
	        this.mum_scanned_files = 0;
	        this.mum_threat_files = 0;
	        this.cmd = 0;
	        this.myadapter = 0;
	        this.isFirst = 1;
	        return;
	    }
	
	
	    static synthetic android.widget.ProgressBar access$0(com.safesys.viruskiller.MainActivity p1)
	    {
	        return p1.loadingtip;
	    }
	
	
	    static synthetic android.widget.Button access$1(com.safesys.viruskiller.MainActivity p1)
	    {
	        return p1.fun_autoupdate;
	    }
	
	
	    static synthetic void access$10(com.safesys.viruskiller.MainActivity p0)
	    {
	        p0.outsegregate();
	        return;
	    }
	
	
	    static synthetic com.safesys.viruskiller.MainActivity access$2()
	    {
	        return com.safesys.viruskiller.MainActivity.instance;
	    }
	
	
	    static synthetic com.safesys.viruskiller.util.Utility access$3(com.safesys.viruskiller.MainActivity p1)
	    {
	        return p1.utils;
	    }
	
	
	    static synthetic void access$4(com.safesys.viruskiller.MainActivity p0)
	    {
	        p0.fillQuarantine();
	        return;
	    }
	
	
	    static synthetic void access$5(com.safesys.viruskiller.MainActivity p0)
	    {
	        p0.fillTrusted();
	        return;
	    }
	
	
	    static synthetic com.safesys.viruskiller.Virus access$6(com.safesys.viruskiller.MainActivity p1, String p2)
	    {
	        return p1.findVirus(p2);
	    }
	
	
	    static synthetic void access$7(com.safesys.viruskiller.MainActivity p0)
	    {
	        p0.hideHandle();
	        return;
	    }
	
	
	    static synthetic void access$8(com.safesys.viruskiller.MainActivity p0)
	    {
	        p0.showHandle();
	        return;
	    }
	
	
	    static synthetic void access$9(com.safesys.viruskiller.MainActivity p0, int p1)
	    {
	        p0.iMainUI = p1;
	        return;
	    }
	
	
	    private void controlScanUI(String p4)
	    {
	        com.safesys.viruskiller.MainActivity$UpdateUIRunTask v1_1 = new com.safesys.viruskiller.MainActivity$UpdateUIRunTask(this);
	        Object[] v0 = new Object[1];
	        v0[0] = p4;
	        v1_1.execute(v0);
	        return;
	    }
	
	
	    private void fillQuarantine()
	    {
	        android.widget.ListView v9_1 = ((android.widget.ListView) com.safesys.viruskiller.MainActivity.instance.findViewById(2131230739));
	        String[] v5 = new String[4];
	        v5[0] = "virus_name";
	        v5[1] = "virus_desc";
	        v5[2] = "virus_path";
	        v5[3] = "_id";
	        int[] v6 = new int[4];
	        v6 = {2131230777, 2131230778, 2131230780, 2131230781};
	        java.util.ArrayList v3_1 = new java.util.ArrayList();
	        if (com.safesys.viruskiller.MainActivity.listValue == null) {
	            this.seg_empty.setVisibility(0);
	        } else {
	            int v8 = 0;
	            while (v8 < com.safesys.viruskiller.MainActivity.listValue.size()) {
	                android.content.ContentValues v10_1 = ((android.content.ContentValues) com.safesys.viruskiller.MainActivity.listValue.get(v8));
	                java.util.HashMap v7_1 = new java.util.HashMap();
	                v7_1.put(v5[0], v10_1.getAsString("virus_name"));
	                v7_1.put(v5[1], v10_1.getAsString("virus_desc"));
	                v7_1.put(v5[2], v10_1.getAsString("virus_path"));
	                v7_1.put(v5[3], v10_1.getAsString("_id"));
	                v3_1.add(v7_1);
	                v8++;
	            }
	            if (com.safesys.viruskiller.MainActivity.listValue.size() <= 0) {
	                this.seg_empty.setVisibility(0);
	            } else {
	                this.seg_empty.setVisibility(8);
	            }
	        }
	        v9_1.setAdapter(new com.safesys.viruskiller.MainActivity$MyQAdapter(this, this, v3_1, 2130903042, v5, v6));
	        v9_1.requestFocus();
	        return;
	    }
	
	
	    private void fillTrusted()
	    {
	        android.widget.ListView v9_1 = ((android.widget.ListView) com.safesys.viruskiller.MainActivity.instance.findViewById(2131230739));
	        String[] v5 = new String[4];
	        v5[0] = "virus_name";
	        v5[1] = "virus_desc";
	        v5[2] = "virus_path";
	        v5[3] = "_id";
	        int[] v6 = new int[4];
	        v6 = {2131230777, 2131230778, 2131230780, 2131230781};
	        java.util.ArrayList v3_1 = new java.util.ArrayList();
	        if (com.safesys.viruskiller.MainActivity.listTrusted == null) {
	            this.seg_empty.setVisibility(0);
	        } else {
	            int v8 = 0;
	            while (v8 < com.safesys.viruskiller.MainActivity.listTrusted.size()) {
	                android.content.ContentValues v10_1 = ((android.content.ContentValues) com.safesys.viruskiller.MainActivity.listTrusted.get(v8));
	                java.util.HashMap v7_1 = new java.util.HashMap();
	                v7_1.put(v5[0], v10_1.getAsString("virus_name"));
	                v7_1.put(v5[1], v10_1.getAsString("virus_desc"));
	                v7_1.put(v5[2], v10_1.getAsString("virus_path"));
	                v7_1.put(v5[3], v10_1.getAsString("_id"));
	                v3_1.add(v7_1);
	                v8++;
	            }
	            if (com.safesys.viruskiller.MainActivity.listTrusted.size() <= 0) {
	                this.seg_empty.setVisibility(0);
	            } else {
	                this.seg_empty.setVisibility(8);
	            }
	        }
	        v9_1.setAdapter(new com.safesys.viruskiller.MainActivity$MyTAdapter(this, this, v3_1, 2130903042, v5, v6));
	        v9_1.requestFocus();
	        return;
	    }
	
	
	    private com.safesys.viruskiller.Virus findVirus(String p4)
	    {
	        int v0 = 0;
	        while (v0 < com.safesys.viruskiller.MainActivity.virusList.size()) {
	            com.safesys.viruskiller.Virus v1_1 = ((com.safesys.viruskiller.Virus) com.safesys.viruskiller.MainActivity.virusList.get(v0));
	            if (!v1_1.getVirusPath().equals(p4)) {
	                v0++;
	            } else {
	                com.safesys.viruskiller.Virus v2_5 = v1_1;
	            }
	            return v2_5;
	        }
	        v2_5 = 0;
	        return v2_5;
	    }
	
	
	    public static com.safesys.viruskiller.MainActivity getInstance()
	    {
	        return com.safesys.viruskiller.MainActivity.instance;
	    }
	
	
	    private void hideHandle()
	    {
	        this.main_scan_deal.setBackgroundResource(2130837584);
	        this.main_scan_deal.setEnabled(0);
	        this.main_scan_believe.setBackgroundResource(2130837584);
	        this.main_scan_believe.setEnabled(0);
	        return;
	    }
	
	
	    private void initUIReceive()
	    {
	        this.receiver = new com.safesys.viruskiller.MainActivity$UIReceiver(this);
	        android.content.IntentFilter v0_1 = new android.content.IntentFilter();
	        v0_1.addAction("uiupdate");
	        this.registerReceiver(this.receiver, v0_1);
	        return;
	    }
	
	
	    private void initWebView()
	    {
	        android.webkit.WebSettings v0 = this.webview.getSettings();
	        v0.setJavaScriptEnabled(1);
	        v0.setCacheMode(2);
	        this.webview.setWebChromeClient(new com.safesys.viruskiller.MyWebChromeClient(this));
	        return;
	    }
	
	
	    private void insegregate()
	    {
	        this.main_button_segregate.setVisibility(8);
	        this.main_trust_area.setVisibility(8);
	        this.handle_menu.setVisibility(8);
	        this.line.setVisibility(8);
	        this.mk_recommend.setVisibility(8);
	        this.frame_introduce.setVisibility(8);
	        this.ly_segregate.setVisibility(0);
	        this.seg_handle.setVisibility(0);
	        return;
	    }
	
	
	    private void outsegregate()
	    {
	        this.main_button_segregate.setVisibility(0);
	        this.main_trust_area.setVisibility(0);
	        this.handle_menu.setVisibility(0);
	        this.line.setVisibility(0);
	        this.mk_recommend.setVisibility(0);
	        this.frame_introduce.setVisibility(0);
	        this.ly_segregate.setVisibility(8);
	        this.seg_handle.setVisibility(8);
	        return;
	    }
	
	
	    private void showHandle()
	    {
	        this.main_scan_deal.setBackgroundResource(2130837581);
	        this.main_scan_deal.setEnabled(1);
	        this.main_scan_believe.setBackgroundResource(2130837577);
	        this.main_scan_believe.setEnabled(1);
	        return;
	    }
	
	
	    public void dealTrustedUpdate(com.safesys.viruskiller.Virus p4)
	    {
	        if (p4 != null) {
	            com.safesys.viruskiller.MainActivity.virusList.remove(p4);
	            this.mum_threat_files = (this.mum_threat_files - 1);
	            this.main_scanning_danger.setText(new StringBuilder().append(this.mum_threat_files).toString());
	            this.main_scanning_filecount.setText(new StringBuilder().append(this.mum_scanned_files).toString());
	            this.fillData();
	            this.getTrustedNum();
	            if (this.mum_threat_files == 0) {
	                this.hideHandle();
	            }
	        }
	        return;
	    }
	
	
	    public void dealUninstall()
	    {
	        if (com.safesys.viruskiller.MainActivity.virusList != null) {
	            int v0 = 0;
	            while (v0 < com.safesys.viruskiller.MainActivity.virusList.size()) {
	                com.safesys.viruskiller.Virus v1_1 = ((com.safesys.viruskiller.Virus) com.safesys.viruskiller.MainActivity.virusList.get(v0));
	                if (v1_1.isBlKill()) {
	                    this.dealUpdate(v1_1);
	                }
	                v0++;
	            }
	        }
	        return;
	    }
	
	
	    public void dealUpdate(com.safesys.viruskiller.Virus p4)
	    {
	        if (p4 != null) {
	            com.safesys.viruskiller.MainActivity.virusList.remove(p4);
	            this.mum_threat_files = (this.mum_threat_files - 1);
	            this.main_scanning_danger.setText(new StringBuilder().append(this.mum_threat_files).toString());
	            this.main_scanning_filecount.setText(new StringBuilder().append(this.mum_scanned_files).toString());
	            this.fillData();
	            this.getQuarantineNum();
	            if (this.mum_threat_files == 0) {
	                this.hideHandle();
	            }
	        }
	        return;
	    }
	
	
	    public void fillData()
	    {
	        if (com.safesys.viruskiller.MainActivity.virusList.size() <= 0) {
	            this.main_scanning_list.setAdapter(0);
	        } else {
	            String[] v5 = new String[3];
	            v5[0] = "virus_name";
	            v5[1] = "virus_desc";
	            v5[2] = "virus_path";
	            int[] v6 = new int[3];
	            v6 = {2131230783, 2131230784, 2131230785};
	            java.util.ArrayList v3_1 = new java.util.ArrayList();
	            int v8 = 0;
	            while (v8 < com.safesys.viruskiller.MainActivity.virusList.size()) {
	                com.safesys.viruskiller.Virus v9_1 = ((com.safesys.viruskiller.Virus) com.safesys.viruskiller.MainActivity.virusList.get(v8));
	                java.util.HashMap v7_1 = new java.util.HashMap();
	                v7_1.put(v5[0], v9_1.getVirusName());
	                v7_1.put(v5[1], v9_1.getVirusDesc());
	                v7_1.put(v5[2], v9_1.getVirusPath());
	                v3_1.add(v7_1);
	                v8++;
	            }
	            this.main_scanning_list.setAdapter(new com.safesys.viruskiller.MainActivity$MyAdapter(this, this, v3_1, 2130903043, v5, v6));
	        }
	        this.main_scanning_list.invalidate();
	        return;
	    }
	
	
	    public int getQuarantineNum()
	    {
	        return this.getQuarantineNum(0);
	    }
	
	
	    public int getQuarantineNum(int p8)
	    {
	        int v0 = 0;
	        com.safesys.viruskiller.VirusDBAdpter v1_1 = new com.safesys.viruskiller.VirusDBAdpter(com.safesys.viruskiller.MainActivity.instance);
	        v1_1.open();
	        com.safesys.viruskiller.MainActivity.listValue = v1_1.findValidAll();
	        if (p8 == 1) {
	            android.widget.Toast.makeText(com.safesys.viruskiller.MainActivity.instance, this.getString(2131099664), 1).show();
	        }
	        if (com.safesys.viruskiller.MainActivity.listValue != null) {
	            v0 = com.safesys.viruskiller.MainActivity.listValue.size();
	            if (v0 <= 0) {
	                this.seg_empty.setVisibility(0);
	            } else {
	                this.seg_empty.setVisibility(8);
	            }
	        }
	        v1_1.close();
	        android.widget.TextView v2_8 = this.main_button_segregate;
	        Object[] v4_1 = new Object[1];
	        v4_1[0] = Integer.valueOf(v0);
	        v2_8.setText(this.getString(2131099661, v4_1));
	        return v0;
	    }
	
	
	    public int getTrustedNum()
	    {
	        return this.getTrustedNum(0);
	    }
	
	
	    public int getTrustedNum(int p8)
	    {
	        int v0 = 0;
	        com.safesys.viruskiller.TrustedDBAdpter v1_1 = new com.safesys.viruskiller.TrustedDBAdpter(com.safesys.viruskiller.MainActivity.instance);
	        v1_1.open();
	        if (com.safesys.viruskiller.MainActivity.listTrusted != null) {
	            com.safesys.viruskiller.MainActivity.listTrusted.clear();
	        }
	        if (p8 == 1) {
	            android.widget.Toast.makeText(com.safesys.viruskiller.MainActivity.instance, this.getString(2131099664), 1).show();
	        }
	        com.safesys.viruskiller.MainActivity.listTrusted = v1_1.findValidAll();
	        if (com.safesys.viruskiller.MainActivity.listTrusted != null) {
	            v0 = com.safesys.viruskiller.MainActivity.listTrusted.size();
	            if (v0 <= 0) {
	                this.seg_empty.setVisibility(0);
	            } else {
	                this.seg_empty.setVisibility(8);
	            }
	        }
	        v1_1.close();
	        android.widget.TextView v2_10 = this.main_trust_area;
	        Object[] v4_1 = new Object[1];
	        v4_1[0] = Integer.valueOf(v0);
	        v2_10.setText(this.getString(2131099662, v4_1));
	        return v0;
	    }
	
	
	    public void onClick(android.view.View p15)
	    {
	        if (p15.getId() != 2131230724) {
	            if (p15.getId() != 2131230723) {
	                if (p15.getId() != 2131230725) {
	                    if (p15.getId() != 2131230767) {
	                        if (p15.getId() != 2131230766) {
	                            if (p15.getId() != 2131230764) {
	                                if (p15.getId() != 2131230728) {
	                                    if (p15.getId() != 2131230765) {
	                                        if (p15.getId() == 2131230729) {
	                                            com.safesys.viruskiller.MainActivity.bTrusted = 1;
	                                            this.clear.setBackgroundResource(2130837532);
	                                            this.clear.setText(this.getString(2131099677));
	                                            this.fillTrusted();
	                                            this.insegregate();
	                                            this.iMainUI = 0;
	                                        }
	                                    } else {
	                                        int v3_0 = 0;
	                                        while (v3_0 < com.safesys.viruskiller.MainActivity.virusList.size()) {
	                                            com.safesys.viruskiller.Virus v8_1 = ((com.safesys.viruskiller.Virus) com.safesys.viruskiller.MainActivity.virusList.get(v3_0));
	                                            if (v8_1.getQuarantineFlag() == 1) {
	                                                this.handler.post(new com.safesys.viruskiller.MainActivity$11(this, v8_1));
	                                            }
	                                            v3_0++;
	                                        }
	                                    }
	                                } else {
	                                    this.clear.setBackgroundResource(2130837529);
	                                    this.clear.setText(this.getString(2131099676));
	                                    com.safesys.viruskiller.MainActivity.bTrusted = 0;
	                                    this.fillQuarantine();
	                                    this.insegregate();
	                                    this.iMainUI = 0;
	                                }
	                            } else {
	                                int v3_1 = 0;
	                                while (v3_1 < com.safesys.viruskiller.MainActivity.virusList.size()) {
	                                    com.safesys.viruskiller.Virus v8_3 = ((com.safesys.viruskiller.Virus) com.safesys.viruskiller.MainActivity.virusList.get(v3_1));
	                                    if (v8_3.getQuarantineFlag() == 1) {
	                                        if (com.opensystem.terminator.ScanController.postRun(v8_3.getVirusPath()) != 1) {
	                                            try {
	                                                v8_3.setBlKill(1);
	                                                android.content.Intent v5_1 = new android.content.Intent("android.intent.action.DELETE", android.net.Uri.fromParts("package", v8_3.getVirusPackageName(), 0));
	                                                v5_1.setFlags(268435456);
	                                                this.startActivity(v5_1);
	                                            } catch (com.safesys.viruskiller.MainActivity v9_32) {
	                                                android.widget.Toast.makeText(com.safesys.viruskiller.MainActivity.instance, "Remove Error,Try it again.", 1);
	                                            }
	                                        } else {
	                                            this.handler.post(new com.safesys.viruskiller.MainActivity$10(this, v8_3));
	                                        }
	                                    }
	                                    v3_1++;
	                                }
	                            }
	                        } else {
	                            if (com.safesys.viruskiller.ScanningManagerService.isBlPFlag()) {
	                                com.safesys.viruskiller.ScanningManagerService.setBlPFlag(0);
	                            }
	                            if (!this.main_scan_quit.getText().equals(this.getString(2131099657))) {
	                                this.main_scan_quit.setText(this.getString(2131099657));
	                                this.controlScanUI("updateMainPad");
	                                this.iMainUI = 1;
	                            } else {
	                                this.bStop = 1;
	                                this.main_scan_quit.setText(this.getString(2131099666));
	                                this.main_scan_pause.setText(this.getString(2131099659));
	                                this.main_scanning_filename.setText(this.getString(2131099689));
	                                com.safesys.viruskiller.ScanningManagerService.setiScannState(0);
	                            }
	                        }
	                    } else {
	                        if (com.safesys.viruskiller.ScanningManagerService.getiScannState() == 1) {
	                            if (com.safesys.viruskiller.ScanningManagerService.isBlPFlag()) {
	                                this.bPause = 0;
	                                this.main_scan_pause.setText(this.getString(2131099659));
	                                com.safesys.viruskiller.ScanningManagerService.setBlPFlag(0);
	                            } else {
	                                this.bPause = 1;
	                                this.main_scan_pause.setText(this.getString(2131099660));
	                                com.safesys.viruskiller.ScanningManagerService.setBlPFlag(1);
	                            }
	                        }
	                    }
	                } else {
	                    if (com.safesys.viruskiller.ScanningManagerService.getiScannState() == 0) {
	                        if (com.safesys.viruskiller.ScanningManagerService.isBlPFlag()) {
	                            com.safesys.viruskiller.ScanningManagerService.setBlPFlag(0);
	                        }
	                        this.mum_scanned_files = 0;
	                        this.mum_threat_files = 0;
	                        com.safesys.viruskiller.MainActivity.virusList.clear();
	                        this.controlScanUI("updateScanPad");
	                        this.bStop = 0;
	                        this.main_scan_quit.setText(this.getString(2131099657));
	                        android.content.Intent v6_1 = new android.content.Intent(this, com.safesys.viruskiller.ScanningManagerService);
	                        v6_1.putExtra("state", 2);
	                        com.safesys.viruskiller.ScanningManagerService.beginStartingService(this, v6_1);
	                        this.main_button_super.setBackgroundResource(2130837571);
	                        this.iMainUI = 0;
	                    }
	                }
	            } else {
	                if (com.safesys.viruskiller.ScanningManagerService.getiScannState() == 0) {
	                    if (com.safesys.viruskiller.ScanningManagerService.isBlPFlag()) {
	                        com.safesys.viruskiller.ScanningManagerService.setBlPFlag(0);
	                    }
	                    this.mum_scanned_files = 0;
	                    this.mum_threat_files = 0;
	                    com.safesys.viruskiller.MainActivity.virusList.clear();
	                    this.controlScanUI("updateScanPad");
	                    this.bStop = 0;
	                    this.main_scan_quit.setText(this.getString(2131099657));
	                    android.content.Intent v6_3 = new android.content.Intent(this, com.safesys.viruskiller.ScanningManagerService);
	                    v6_3.putExtra("state", 1);
	                    com.safesys.viruskiller.ScanningManagerService.beginStartingService(this, v6_3);
	                    this.main_button_global.setBackgroundResource(2130837559);
	                    this.iMainUI = 0;
	                }
	            }
	        } else {
	            if (com.safesys.viruskiller.ScanningManagerService.getiScannState() == 0) {
	                if (com.safesys.viruskiller.ScanningManagerService.isBlPFlag()) {
	                    com.safesys.viruskiller.ScanningManagerService.setBlPFlag(0);
	                }
	                this.mum_scanned_files = 0;
	                this.mum_threat_files = 0;
	                com.safesys.viruskiller.MainActivity.virusList.clear();
	                this.controlScanUI("updateScanPad");
	                this.bStop = 0;
	                this.main_scan_quit.setText(this.getString(2131099657));
	                android.content.Intent v6_5 = new android.content.Intent(this, com.safesys.viruskiller.ScanningManagerService);
	                v6_5.putExtra("state", 0);
	                com.safesys.viruskiller.ScanningManagerService.beginStartingService(this, v6_5);
	                this.main_button_rapid.setBackgroundResource(2130837562);
	                this.iMainUI = 0;
	            }
	        }
	        switch (p15.getId()) {
	            case 2131230743:
	                this.outsegregate();
	                this.iMainUI = 1;
	            case 2131230744:
	            default:
	                break;
	            case 2131230745:
	                if (!this.flag_defense) {
	                    this.fun_defense.setBackgroundResource(2130837540);
	                    this.fun_defense.setGravity(81);
	                    this.fun_defense.setPadding(0, 0, 7, 12);
	                    this.flag_defense = 1;
	                    android.content.SharedPreferences$Editor v2_6 = com.safesys.viruskiller.MainActivity.preferences.edit();
	                    v2_6.putBoolean("virus_defense_flag", 1);
	                    v2_6.commit();
	                } else {
	                    this.fun_defense.setBackgroundResource(2130837539);
	                    this.fun_defense.setGravity(49);
	                    this.fun_defense.setPadding(0, 5, 7, 0);
	                    this.flag_defense = 0;
	                    android.content.SharedPreferences$Editor v2_7 = com.safesys.viruskiller.MainActivity.preferences.edit();
	                    v2_7.putBoolean("virus_defense_flag", 0);
	                    v2_7.commit();
	                }
	                break;
	            case 2131230746:
	                if (!this.flag_killing) {
	                    this.fun_killing.setBackgroundResource(2130837542);
	                    this.fun_killing.setGravity(81);
	                    this.fun_killing.setPadding(0, 0, 7, 12);
	                    this.flag_killing = 1;
	                    android.content.SharedPreferences$Editor v2_4 = com.safesys.viruskiller.MainActivity.preferences.edit();
	                    v2_4.putBoolean("virus_killing_flag", 1);
	                    v2_4.commit();
	                } else {
	                    this.fun_killing.setBackgroundResource(2130837541);
	                    this.fun_killing.setGravity(49);
	                    this.fun_killing.setPadding(0, 5, 7, 0);
	                    this.flag_killing = 0;
	                    android.content.SharedPreferences$Editor v2_5 = com.safesys.viruskiller.MainActivity.preferences.edit();
	                    v2_5.putBoolean("virus_killing_flag", 0);
	                    v2_5.commit();
	                }
	                break;
	            case 2131230747:
	                if (!this.flag_autoupdate) {
	                    this.fun_autoupdate.setBackgroundResource(2130837538);
	                    this.fun_autoupdate.setGravity(81);
	                    this.fun_autoupdate.setPadding(0, 0, 7, 12);
	                    this.flag_autoupdate = 1;
	                    android.content.SharedPreferences$Editor v2_2 = com.safesys.viruskiller.MainActivity.preferences.edit();
	                    v2_2.putBoolean("virus_autoupdate_flag", 1);
	                    v2_2.commit();
	                    android.content.Intent v5_3 = new android.content.Intent("DownloadManageServicer.ACTION_CONTROL");
	                    v5_3.putExtra("cmd", 0);
	                    this.handler.post(new com.safesys.viruskiller.MainActivity$12(this));
	                    com.safesys.viruskiller.MainActivity.instance.sendBroadcast(v5_3);
	                } else {
	                    this.fun_autoupdate.setBackgroundResource(2130837537);
	                    this.fun_autoupdate.setGravity(49);
	                    this.fun_autoupdate.setPadding(0, 5, 7, 0);
	                    this.flag_autoupdate = 0;
	                    android.content.SharedPreferences$Editor v2_3 = com.safesys.viruskiller.MainActivity.preferences.edit();
	                    v2_3.putBoolean("virus_autoupdate_flag", 0);
	                    v2_3.commit();
	                }
	                break;
	            case 2131230748:
	                if (!this.flag_poweredup) {
	                    this.fun_poweredup.setBackgroundResource(2130837544);
	                    this.fun_poweredup.setGravity(81);
	                    this.fun_poweredup.setPadding(0, 0, 7, 12);
	                    this.flag_poweredup = 1;
	                    android.content.SharedPreferences$Editor v2_0 = com.safesys.viruskiller.MainActivity.preferences.edit();
	                    v2_0.putBoolean("virus_poweredup_flag", 0);
	                    v2_0.commit();
	                } else {
	                    this.fun_poweredup.setBackgroundResource(2130837543);
	                    this.fun_poweredup.setGravity(49);
	                    this.fun_poweredup.setPadding(0, 5, 7, 0);
	                    this.flag_poweredup = 0;
	                    android.content.SharedPreferences$Editor v2_1 = com.safesys.viruskiller.MainActivity.preferences.edit();
	                    v2_1.putBoolean("virus_poweredup_flag", 0);
	                    v2_1.commit();
	                }
	                break;
	        }
	        return;
	    }
	
	
	    public void onCreate(android.os.Bundle p14)
	    {
	        super.onCreate(p14);
	        this.requestWindowFeature(1);
	        this.getWindow().setFlags(1024, 1024);
	        this.setContentView(2130903040);
	        com.safesys.viruskiller.MainActivity.instance = this;
	        com.safesys.viruskiller.MainActivity.preferences = this.getSharedPreferences("VirusManagerPreferences", 0);
	        com.safesys.viruskiller.MainActivity.bTrusted = 0;
	        this.webview = ((android.webkit.WebView) this.findViewById(2131230769));
	        this.initWebView();
	        this.loadingtip = ((android.widget.ProgressBar) this.findViewById(2131230771));
	        this.loadtip = ((android.widget.TextView) this.findViewById(2131230770));
	        this.ly_recommend = ((android.widget.RelativeLayout) this.findViewById(2131230768));
	        this.seg_handle = ((android.widget.RelativeLayout) this.findViewById(2131230741));
	        this.handle_menu = ((android.widget.RelativeLayout) this.findViewById(2131230722));
	        this.frame_introduce = ((android.widget.RelativeLayout) this.findViewById(2131230730));
	        this.ly_segregate = ((android.widget.RelativeLayout) this.findViewById(2131230738));
	        this.line = this.findViewById(2131230726);
	        this.virus_back = ((android.widget.Button) this.findViewById(2131230743));
	        this.virus_back.setOnClickListener(this);
	        this.findViewById(2131230739);
	        this.ly_main = ((android.widget.RelativeLayout) this.findViewById(2131230727));
	        this.flag_defense = com.safesys.viruskiller.MainActivity.preferences.getBoolean("virus_defense_flag", 0);
	        this.flag_killing = com.safesys.viruskiller.MainActivity.preferences.getBoolean("virus_killing_flag", 0);
	        this.flag_autoupdate = com.safesys.viruskiller.MainActivity.preferences.getBoolean("virus_autoupdate_flag", 0);
	        this.flag_poweredup = com.safesys.viruskiller.MainActivity.preferences.getBoolean("virus_poweredup_flag", 0);
	        this.strUpdate = com.safesys.viruskiller.MainActivity.preferences.getString("virus_update_date", 0);
	        this.main_button_rapid = ((android.widget.Button) this.findViewById(2131230724));
	        this.main_button_global = ((android.widget.Button) this.findViewById(2131230723));
	        this.main_button_super = ((android.widget.Button) this.findViewById(2131230725));
	        this.main_scan_pause = ((android.widget.Button) this.findViewById(2131230767));
	        this.main_scan_quit = ((android.widget.Button) this.findViewById(2131230766));
	        this.main_scan_deal = ((android.widget.Button) this.findViewById(2131230764));
	        this.main_scan_believe = ((android.widget.Button) this.findViewById(2131230765));
	        this.main_scan_believe.setOnClickListener(this);
	        this.main_button_segregate = ((android.widget.Button) this.findViewById(2131230728));
	        this.main_trust_area = ((android.widget.Button) this.findViewById(2131230729));
	        this.main_scanning_list = ((android.widget.ListView) this.findViewById(2131230763));
	        this.ly_scan = ((android.widget.RelativeLayout) this.findViewById(2131230750));
	        this.ly_scanning = ((android.widget.RelativeLayout) this.findViewById(2131230751));
	        this.ly_scaned = ((android.widget.RelativeLayout) this.findViewById(2131230754));
	        this.main_scanning_filename = ((android.widget.TextView) this.findViewById(2131230752));
	        this.main_scanning_filecount = ((android.widget.TextView) this.findViewById(2131230758));
	        this.main_scanning_time = ((android.widget.TextView) this.findViewById(2131230762));
	        this.main_scanning_danger = ((android.widget.TextView) this.findViewById(2131230760));
	        this.copyright_info = ((android.widget.TextView) this.findViewById(2131230749));
	        this.seg_empty = ((android.widget.TextView) this.findViewById(2131230740));
	        this.title_explain = ((android.widget.TextView) this.findViewById(2131230720));
	        this.getQuarantineNum();
	        this.getTrustedNum();
	        this.mk_recommend = ((android.widget.ImageView) this.findViewById(2131230737));
	        this.donate = ((android.widget.Button) this.findViewById(2131230721));
	        String v3 = this.getResources().getConfiguration().locale.getCountry();
	        if ((v3 != null) && (v3.equals("CN"))) {
	            this.donate.setText("\u63a8\u8350");
	        }
	        this.donate.setOnClickListener(new com.safesys.viruskiller.MainActivity$2(this));
	        this.clear = ((android.widget.Button) this.findViewById(2131230742));
	        this.clear.setOnClickListener(new com.safesys.viruskiller.MainActivity$3(this));
	        this.fun_defense = ((android.widget.Button) this.findViewById(2131230745));
	        this.fun_defense.setOnClickListener(this);
	        this.fun_killing = ((android.widget.Button) this.findViewById(2131230746));
	        this.fun_killing.setOnClickListener(this);
	        this.fun_autoupdate = ((android.widget.Button) this.findViewById(2131230747));
	        this.fun_autoupdate.setOnClickListener(this);
	        this.fun_poweredup = ((android.widget.Button) this.findViewById(2131230748));
	        this.fun_poweredup.setOnClickListener(this);
	        if (this.strUpdate != null) {
	            this.copyright_info.setText(new StringBuilder(String.valueOf(this.getString(2131099650))).append(" ").append(this.strUpdate).toString());
	        } else {
	            this.copyright_info.setText(this.getString(2131099650));
	        }
	        if (this.flag_defense) {
	            this.fun_defense.setBackgroundResource(2130837540);
	            this.fun_defense.setGravity(81);
	            this.fun_defense.setPadding(0, 0, 7, 12);
	        } else {
	            this.fun_defense.setBackgroundResource(2130837539);
	            this.fun_defense.setGravity(49);
	            this.fun_defense.setPadding(0, 5, 7, 0);
	        }
	        if (this.flag_killing) {
	            this.fun_killing.setBackgroundResource(2130837542);
	            this.fun_killing.setGravity(81);
	            this.fun_killing.setPadding(0, 0, 7, 12);
	        } else {
	            this.fun_killing.setBackgroundResource(2130837541);
	            this.fun_killing.setGravity(49);
	            this.fun_killing.setPadding(0, 5, 7, 0);
	        }
	        if (this.flag_autoupdate) {
	            this.fun_autoupdate.setBackgroundResource(2130837538);
	            this.fun_autoupdate.setGravity(81);
	            this.fun_autoupdate.setPadding(0, 0, 7, 12);
	        } else {
	            this.fun_autoupdate.setBackgroundResource(2130837537);
	            this.fun_autoupdate.setGravity(49);
	            this.fun_autoupdate.setPadding(0, 5, 7, 0);
	        }
	        if (this.flag_poweredup) {
	            this.fun_poweredup.setBackgroundResource(2130837544);
	            this.fun_poweredup.setGravity(81);
	            this.fun_poweredup.setPadding(0, 0, 7, 12);
	        } else {
	            this.fun_poweredup.setBackgroundResource(2130837543);
	            this.fun_poweredup.setGravity(49);
	            this.fun_poweredup.setPadding(0, 5, 7, 0);
	        }
	        this.main_scanning_progress = ((com.safesys.viruskiller.view.MyProcessBar) this.findViewById(2131230753));
	        this.main_button_rapid.setOnClickListener(this);
	        this.main_button_global.setOnClickListener(this);
	        this.main_button_super.setOnClickListener(this);
	        this.main_scan_quit.setOnClickListener(this);
	        this.main_scan_pause.setOnClickListener(this);
	        this.main_scan_deal.setOnClickListener(this);
	        this.main_button_segregate.setOnClickListener(this);
	        this.main_trust_area.setOnClickListener(this);
	        this.localLooper = this.getMainLooper();
	        this.handler = new android.os.Handler(this.localLooper);
	        if (!com.safesys.viruskiller.ScanningManagerService.initFlag) {
	            if (com.safesys.viruskiller.util.Utility.initROOT(this)) {
	                com.safesys.viruskiller.ScanningManagerService.rootFlag = 1;
	                int v1 = this.utils.isLinuxProcessExist();
	                String v4 = 0;
	                if ((v1 == 1) || (v1 == 0)) {
	                    v4 = new StringBuilder("kill -9 ").append(com.safesys.viruskiller.util.Utility.sProcID).toString();
	                }
	                this.utils.startListening(v4);
	            }
	            com.opensystem.terminator.ScanVirus.Init();
	            com.safesys.viruskiller.ScanningManagerService.initFlag = 1;
	        }
	        this.startService(new android.content.Intent(this, com.safesys.viruskiller.DownloadManageService));
	        this.doUpdate = new com.safesys.viruskiller.MainActivity$UpdateReceiver(this);
	        this.initUIReceive();
	        android.content.IntentFilter v0_1 = new android.content.IntentFilter();
	        v0_1.addAction("DownloadManageServicer.ACTION_UPDATE");
	        this.registerReceiver(this.doUpdate, v0_1);
	        if (this.thTime == null) {
	            this.bStop = 1;
	            this.thTime = new Thread(new com.safesys.viruskiller.MainActivity$4(this));
	            this.thTime.setDaemon(1);
	            this.thTime.start();
	        }
	        return;
	    }
	
	
	    protected android.app.Dialog onCreateDialog(int p6)
	    {
	        android.app.AlertDialog v1_6;
	        android.app.AlertDialog$Builder v0_1 = new android.app.AlertDialog$Builder(this);
	        switch (p6) {
	            case 0:
	                v1_6 = v0_1.setIcon(2130837546).setTitle(this.getString(2131099682)).setMessage(this.getString(2131099683)).setPositiveButton(17039370, new com.safesys.viruskiller.MainActivity$5(this)).setNegativeButton(17039360, new com.safesys.viruskiller.MainActivity$6(this)).create();
	                break;
	            case 1:
	                v1_6 = v0_1.setIcon(2130837546).setTitle(this.getString(2131099687)).setMessage(this.getString(2131099688)).setPositiveButton(17039370, new com.safesys.viruskiller.MainActivity$7(this)).setNegativeButton(17039360, new com.safesys.viruskiller.MainActivity$8(this)).create();
	                break;
	            default:
	                v1_6 = super.onCreateDialog(p6);
	        }
	        return v1_6;
	    }
	
	
	    public boolean onCreateOptionsMenu(android.view.Menu p3)
	    {
	        super.onCreateOptionsMenu(p3);
	        p3.add(0, 0, 0, this.getString(2131099686));
	        return 1;
	    }
	
	
	    protected void onDestroy()
	    {
	        super.onDestroy();
	        if (com.safesys.viruskiller.ScanningManagerService.isBlPFlag()) {
	            com.safesys.viruskiller.ScanningManagerService.setBlPFlag(0);
	        }
	        if (this.receiver != null) {
	            this.unregisterReceiver(this.receiver);
	        }
	        if (this.main_scan_quit.getText().equals(this.getString(2131099657))) {
	            this.bStop = 1;
	            this.main_scan_quit.setText(this.getString(2131099666));
	            this.main_scan_pause.setText(this.getString(2131099659));
	            com.safesys.viruskiller.ScanningManagerService.setiScannState(0);
	        }
	        this.stopService(new android.content.Intent(this, com.safesys.viruskiller.DownloadManageService));
	        this.unregisterReceiver(this.doUpdate);
	        this.bThread = 1;
	        com.safesys.viruskiller.ScanningManagerService.initFlag = 0;
	        com.safesys.viruskiller.ScanningManagerService.finishStartingService();
	        if (com.safesys.viruskiller.MainActivity.instance != null) {
	            com.safesys.viruskiller.MainActivity.instance = 0;
	        }
	        return;
	    }
	
	
	    public boolean onKeyDown(int p5, android.view.KeyEvent p6)
	    {
	        int v0_1;
	        if (p5 != 4) {
	            v0_1 = super.onKeyDown(p5, p6);
	        } else {
	            if (this.iMainUI != 1) {
	                if (com.safesys.viruskiller.ScanningManagerService.getiScannState() != 0) {
	                    this.moveTaskToBack(1);
	                    com.safesys.viruskiller.MainActivity.nm = com.safesys.viruskiller.util.Utility.getNotification(com.safesys.viruskiller.MainActivity.nm, com.safesys.viruskiller.MainActivity.notification_id, this);
	                    v0_1 = 1;
	                } else {
	                    this.controlScanUI("updateMainPad");
	                    this.outsegregate();
	                    this.iMainUI = 1;
	                    this.handle_menu.setVisibility(0);
	                    this.line.setVisibility(0);
	                    this.ly_main.setVisibility(0);
	                    this.donate.setText("\u63a8\u8350");
	                    this.donate.setBackgroundResource(2130837553);
	                    this.title_explain.setText("\u4e13\u4e1a\u6740\u6bd2\u3000\u6c38\u4e45\u514d\u8d39");
	                    this.ly_recommend.setVisibility(8);
	                    this.isRecommend = 0;
	                    v0_1 = 1;
	                }
	            } else {
	                this.moveTaskToBack(1);
	                com.safesys.viruskiller.MainActivity.nm = com.safesys.viruskiller.util.Utility.getNotification(com.safesys.viruskiller.MainActivity.nm, com.safesys.viruskiller.MainActivity.notification_id, this);
	                v0_1 = 1;
	            }
	        }
	        return v0_1;
	    }
	
	
	    public boolean onMenuItemSelected(int p2, android.view.MenuItem p3)
	    {
	        switch (p3.getItemId()) {
	            case 0:
	                this.showDialog(1);
	                break;
	        }
	        return super.onMenuItemSelected(p2, p3);
	    }
	
	
	    protected void onStart()
	    {
	        super.onStart();
	        if (com.safesys.viruskiller.util.Utility.checkROOT(this)) {
	            int v1 = this.utils.isLinuxProcessExist();
	            String v2 = 0;
	            if ((v1 == 1) || (v1 == 0)) {
	                v2 = new StringBuilder("kill -9 ").append(com.safesys.viruskiller.util.Utility.sProcID).toString();
	            }
	            this.utils.startListening(v2);
	        }
	        if (com.safesys.viruskiller.DownloadManageService.blUpdate) {
	            String v3 = com.opensystem.terminator.VirusBackRunner.getVersionCode();
	            String v0 = com.opensystem.terminator.VirusBackRunner.getCurrVersion();
	            if (v3 != null) {
	                if (v3.equals(v0)) {
	                    com.safesys.viruskiller.DownloadManageService.saveUpdate();
	                } else {
	                    this.showDialog(0);
	                }
	            }
	        }
	        return;
	    }
	
	
	    public void unclick()
	    {
	        this.handler.post(new com.safesys.viruskiller.MainActivity$9(this));
	        return;
	    }
	
	
	    public void updateScanPath(String p3)
	    {
	        this.handler.post(new com.safesys.viruskiller.MainActivity$1(this, p3));
	        return;
	    }
	
