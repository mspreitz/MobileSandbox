	final synthetic com.safesys.viruskiller.MainActivity this$0
	
	    public MainActivity$UpdateReceiver(com.safesys.viruskiller.MainActivity p1)
	    {
	        this.this$0 = p1;
	        return;
	    }
	
	
	    static synthetic com.safesys.viruskiller.MainActivity access$0(com.safesys.viruskiller.MainActivity$UpdateReceiver p1)
	    {
	        return p1.this$0;
	    }
	
	
	    public void onReceive(android.content.Context p4, android.content.Intent p5)
	    {
	        switch (p5.getIntExtra("status", -1)) {
	            case 0:
	                this.this$0.handler.post(new com.safesys.viruskiller.MainActivity$UpdateReceiver$1(this));
	                break;
	            case 1:
	                this.this$0.handler.post(new com.safesys.viruskiller.MainActivity$UpdateReceiver$2(this));
	                break;
	            case 2:
	                this.this$0.handler.post(new com.safesys.viruskiller.MainActivity$UpdateReceiver$3(this));
	                break;
	            case 3:
	                this.this$0.showDialog(0);
	                break;
	        }
	        return;
	    }
	
