	final synthetic com.safesys.viruskiller.MainActivity$MyQAdapter$1 this$2
	private final synthetic java.lang.String val$strVirusId
	
	    MainActivity$MyQAdapter$1$1(com.safesys.viruskiller.MainActivity$MyQAdapter$1 p1, String p2)
	    {
	        this.this$2 = p1;
	        this.val$strVirusId = p2;
	        return;
	    }
	
	
	    public void run()
	    {
	        com.safesys.viruskiller.VirusDBAdpter v0_1 = new com.safesys.viruskiller.VirusDBAdpter(com.safesys.viruskiller.MainActivity.access$2());
	        v0_1.open();
	        long v1 = Long.valueOf(this.val$strVirusId).longValue();
	        android.util.Log.d("CMD---id---", new StringBuilder().append(v1).toString());
	        v0_1.removeEntry(v1);
	        v0_1.close();
	        com.safesys.viruskiller.MainActivity$MyQAdapter.access$0(com.safesys.viruskiller.MainActivity$MyQAdapter$1.access$0(this.this$2)).getQuarantineNum(1);
	        com.safesys.viruskiller.MainActivity.access$4(com.safesys.viruskiller.MainActivity$MyQAdapter.access$0(com.safesys.viruskiller.MainActivity$MyQAdapter$1.access$0(this.this$2)));
	        return;
	    }
	
