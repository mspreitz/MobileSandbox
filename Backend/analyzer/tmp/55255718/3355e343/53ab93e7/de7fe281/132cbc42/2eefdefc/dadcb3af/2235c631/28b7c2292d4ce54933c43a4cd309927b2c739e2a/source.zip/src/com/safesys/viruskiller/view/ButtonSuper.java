	
	    public ButtonSuper(android.content.Context p7, android.util.AttributeSet p8)
	    {
	        this(p7, p8);
	        android.content.res.Resources v3 = this.getResources();
	        android.graphics.drawable.StateListDrawable v0_1 = new android.graphics.drawable.StateListDrawable();
	        android.graphics.drawable.Drawable v1 = this.getBackground();
	        android.graphics.drawable.Drawable v4 = v3.getDrawable(2130837504);
	        v0_1.addState(android.view.View.PRESSED_ENABLED_STATE_SET, v3.getDrawable(2130837506));
	        v0_1.addState(android.view.View.ENABLED_FOCUSED_STATE_SET, v4);
	        v0_1.addState(android.view.View.ENABLED_STATE_SET, v1);
	        v0_1.addState(android.view.View.FOCUSED_STATE_SET, v4);
	        v0_1.addState(android.view.View.EMPTY_STATE_SET, v1);
	        this.setBackgroundDrawable(v0_1);
	        return;
	    }
	
