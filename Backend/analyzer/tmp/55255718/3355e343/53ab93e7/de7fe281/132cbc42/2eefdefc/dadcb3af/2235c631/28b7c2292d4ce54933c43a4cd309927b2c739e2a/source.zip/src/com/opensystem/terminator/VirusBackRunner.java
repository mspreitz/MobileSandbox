	
	    static VirusBackRunner()
	    {
	        System.loadLibrary("VirusBackRunner");
	        return;
	    }
	
	
	    public VirusBackRunner()
	    {
	        return;
	    }
	
