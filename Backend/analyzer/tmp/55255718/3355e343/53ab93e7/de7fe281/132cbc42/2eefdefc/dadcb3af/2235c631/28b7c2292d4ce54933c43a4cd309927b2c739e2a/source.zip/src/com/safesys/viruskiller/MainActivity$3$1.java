	final synthetic com.safesys.viruskiller.MainActivity$3 this$1
	private final synthetic java.lang.String val$sBak
	private final synthetic java.lang.String val$sId
	
	    MainActivity$3$1(com.safesys.viruskiller.MainActivity$3 p1, String p2, String p3)
	    {
	        this.this$1 = p1;
	        this.val$sId = p2;
	        this.val$sBak = p3;
	        return;
	    }
	
	
	    public void run()
	    {
	        com.safesys.viruskiller.VirusDBAdpter v0_1 = new com.safesys.viruskiller.VirusDBAdpter(com.safesys.viruskiller.MainActivity.access$2());
	        v0_1.open();
	        v0_1.removeEntry(Long.valueOf(this.val$sId).longValue());
	        v0_1.close();
	        com.safesys.viruskiller.MainActivity$3.access$0(this.this$1).getQuarantineNum();
	        if ((this.val$sBak != null) && (!this.val$sBak.equals(""))) {
	            android.content.Intent v3_1 = new android.content.Intent("android.intent.action.DELETE", android.net.Uri.fromParts("package", this.val$sBak, 0));
	            v3_1.setFlags(268435456);
	            com.safesys.viruskiller.MainActivity$3.access$0(this.this$1).startActivity(v3_1);
	        }
	        if (com.safesys.viruskiller.MainActivity$3.access$0(this.this$1).mum_threat_files == 0) {
	            com.safesys.viruskiller.MainActivity.access$7(com.safesys.viruskiller.MainActivity$3.access$0(this.this$1));
	        }
	        return;
	    }
	
