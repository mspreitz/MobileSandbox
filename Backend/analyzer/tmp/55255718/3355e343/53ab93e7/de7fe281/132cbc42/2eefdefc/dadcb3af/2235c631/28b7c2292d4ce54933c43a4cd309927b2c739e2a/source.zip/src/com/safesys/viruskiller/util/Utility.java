	private static final java.lang.String DEFAULT_INITIAL_COMMAND
	private static final java.lang.String DEFAULT_INITIAL_PROC
	private static final java.lang.String DEFAULT_SHELL
	private static final java.lang.String TAG
	public static java.lang.String sProcID
	private java.lang.String mInitialCommand
	private java.lang.String mShell
	private java.io.FileDescriptor mTermFd
	private java.io.FileOutputStream mTermOut
	
	    static Utility()
	    {
	        com.safesys.viruskiller.util.Utility.sProcID = "-1";
	        return;
	    }
	
	
	    public Utility()
	    {
	        return;
	    }
	
	
	    public static boolean checkROOT(android.content.Context p10)
	    {
	        java.io.File v1_1 = new java.io.File("/system/bin/su");
	        java.io.File v2_1 = new java.io.File("/system/xbin/su");
	        int v3 = -1;
	        if (!v1_1.exists()) {
	            if (v2_1.exists()) {
	                v3 = 2;
	            }
	        } else {
	            v3 = 1;
	        }
	        int v6_6;
	        if (v3 <= 0) {
	            v6_6 = 0;
	        } else {
	            try {
	                Process v5;
	                if (v3 != 1) {
	                    v5 = Runtime.getRuntime().exec("/system/xbin/su");
	                } else {
	                    v5 = Runtime.getRuntime().exec("/system/bin/su");
	                }
	            } catch (int v6_4) {
	                v6_4.printStackTrace();
	            }
	            if ((v5 == null) || (v5.getErrorStream().available() != 0)) {
	            } else {
	                v6_6 = 1;
	            }
	        }
	        return v6_6;
	    }
	
	
	    private void createSubprocess(int[] p9)
	    {
	        String v4 = this.mShell;
	        if ((v4 == null) || (v4.equals(""))) {
	            v4 = "/system/bin/su";
	        }
	        if (new java.io.File("/system/xbin/su").exists()) {
	            v4 = "/system/xbin/su";
	        }
	        java.util.ArrayList v3 = this.parse(v4);
	        String v1_0 = 0;
	        String v2_0 = 0;
	        if (v3.size() >= 2) {
	            v1_0 = ((String) v3.get(1));
	        }
	        if (v3.size() >= 3) {
	            v2_0 = ((String) v3.get(2));
	        }
	        this.mTermFd = com.google.ase.Exec.createSubprocess(((String) v3.get(0)), v1_0, v2_0, p9);
	        return;
	    }
	
	
	    public static void getInitNotification(android.app.NotificationManager p8, int p9, android.content.Context p10)
	    {
	        if (p8 == null) {
	            p8 = ((android.app.NotificationManager) p10.getSystemService("notification"));
	        }
	        android.app.Notification v2_1 = new android.app.Notification(2130837545, "", System.currentTimeMillis());
	        v2_1.flags = 16;
	        android.content.Intent v3_1 = new android.content.Intent(p10, com.safesys.viruskiller.ScanningManagerService);
	        v3_1.putExtra("notification_record", 1);
	        v2_1.setLatestEventInfo(p10, p10.getString(2131099648), p10.getString(2131099665), android.app.PendingIntent.getService(p10, 0, v3_1, 134217728));
	        p8.notify(p9, v2_1);
	        return;
	    }
	
	
	    public static android.app.NotificationManager getNotification(android.app.NotificationManager p8, int p9, android.content.Context p10)
	    {
	        if (p8 == null) {
	            p8 = ((android.app.NotificationManager) p10.getSystemService("notification"));
	        }
	        android.app.Notification v2_1 = new android.app.Notification(2130837545, "", System.currentTimeMillis());
	        v2_1.flags = 2;
	        android.content.Intent v3_1 = new android.content.Intent(p10, com.safesys.viruskiller.ScanningManagerService);
	        v3_1.putExtra("notification_record", 1);
	        v2_1.setLatestEventInfo(p10, p10.getString(2131099648), p10.getString(2131099665), android.app.PendingIntent.getService(p10, 0, v3_1, 402653184));
	        p8.notify(p9, v2_1);
	        return p8;
	    }
	
	
	    public static boolean getRawResource(android.content.Context p6, String p7, int p8)
	    {
	        try {
	            int v4_4;
	            if (p8 == 0) {
	                v4_4 = 0;
	            } else {
	                java.io.FileOutputStream v1 = p6.openFileOutput(p7, 2);
	                java.io.InputStream v2 = p6.getResources().openRawResource(p8);
	                byte[] v0 = new byte[1024];
	                while(true) {
	                    int v3 = v2.read(v0);
	                    if (v3 <= 0) {
	                        break;
	                    }
	                    v1.write(v0, 0, v3);
	                }
	                v2.close();
	                v1.close();
	                v4_4 = 1;
	            }
	        } catch (int v4) {
	        }
	        return v4_4;
	    }
	
	
	    public static boolean initROOT(android.content.Context p15)
	    {
	        java.io.File v1_1 = new java.io.File("/system/bin/su");
	        java.io.File v2_1 = new java.io.File("/system/xbin/su");
	        int v3 = -1;
	        if (!v1_1.exists()) {
	            if (v2_1.exists()) {
	                v3 = 2;
	            }
	        } else {
	            v3 = 1;
	        }
	        com.safesys.viruskiller.util.Utility.getRawResource(p15, "ScanRunner", 2131034114);
	        java.io.File v8_1 = new java.io.File("/data/data/com.safesys.viruskiller/files", "myvr.db");
	        new java.io.File("/data/data/com.safesys.viruskiller/files", "Mycfg");
	        if (!v8_1.exists()) {
	            com.safesys.viruskiller.util.Utility.getRawResource(p15, "myvr.db", 2131034113);
	        }
	        int v9_13;
	        com.safesys.viruskiller.util.Utility.getRawResource(p15, "Mycfg", 2131034112);
	        java.io.File v5_1 = new java.io.File("/data/data/com.safesys.viruskiller/files", "ScanRunner");
	        if (v3 <= 0) {
	            v9_13 = 0;
	        } else {
	            try {
	                Process v6;
	                Runtime.getRuntime().exec(new StringBuilder("chmod 777 ").append(v5_1.getAbsolutePath()).toString());
	            } catch (int v9_11) {
	                v9_11.printStackTrace();
	            }
	            if (v3 != 1) {
	                v6 = Runtime.getRuntime().exec("/system/xbin/su");
	            } else {
	                v6 = Runtime.getRuntime().exec("/system/bin/su");
	            }
	            if ((v6 == null) || (v6.getErrorStream().available() != 0)) {
	            } else {
	                v9_13 = 1;
	            }
	        }
	        return v9_13;
	    }
	
	
	    private boolean isSystemApp(android.content.pm.ApplicationInfo p4)
	    {
	        int v0 = 0;
	        if ((p4.flags & 1) != 0) {
	            v0 = 1;
	        }
	        return v0;
	    }
	
	
	    private java.util.ArrayList parse(String p13)
	    {
	        int v8 = 1;
	        java.util.ArrayList v7_1 = new java.util.ArrayList();
	        int v5 = p13.length();
	        StringBuilder v3_1 = new StringBuilder();
	        int v6 = 0;
	        while (v6 < v5) {
	            char v4 = p13.charAt(v6);
	            if (v8 != 0) {
	                if (v8 != 1) {
	                    if (v8 == 2) {
	                        if (v4 != 92) {
	                            if (v4 != 34) {
	                                v3_1.append(v4);
	                            } else {
	                                v8 = 0;
	                            }
	                        } else {
	                            if ((v6 + 1) < v5) {
	                                v6++;
	                                v3_1.append(p13.charAt(v6));
	                            }
	                        }
	                    }
	                } else {
	                    if (!Character.isWhitespace(v4)) {
	                        if (v4 != 34) {
	                            v8 = 0;
	                            v3_1.append(v4);
	                        } else {
	                            v8 = 2;
	                        }
	                    }
	                }
	            } else {
	                if (!Character.isWhitespace(v4)) {
	                    if (v4 != 34) {
	                        v3_1.append(v4);
	                    } else {
	                        v8 = 2;
	                    }
	                } else {
	                    v7_1.add(v3_1.toString());
	                    v3_1.delete(0, v3_1.length());
	                    v8 = 1;
	                }
	            }
	            v6++;
	        }
	        if (v3_1.length() > 0) {
	            v7_1.add(v3_1.toString());
	        }
	        return v7_1;
	    }
	
	
	    private void scanDir(java.io.File p6, com.safesys.viruskiller.MainActivity p7)
	    {
	        java.io.File[] v0 = p6.listFiles();
	        if (v0 == null) {
	            android.util.Log.d("CMD", "opendir failed, Permission denied!");
	        } else {
	            int v1 = 0;
	            while (v1 < v0.length) {
	                this.scanFile(v0[v1], p7, 0);
	                v1++;
	            }
	        }
	        return;
	    }
	
	
	    private void sendInitialCommand()
	    {
	        String v0 = this.mInitialCommand;
	        if ((v0 == null) || (v0.equals(""))) {
	            v0 = "/data/data/com.safesys.viruskiller/files/ScanRunner &";
	        }
	        if (v0.length() > 0) {
	            this.write(new StringBuilder(String.valueOf(v0)).append(13).toString());
	        }
	        return;
	    }
	
	
	    private void write(String p3)
	    {
	        try {
	            this.mTermOut.write(p3.getBytes());
	            this.mTermOut.flush();
	        } catch (java.io.IOException v0) {
	        }
	        return;
	    }
	
	
	    public android.graphics.drawable.Drawable iconPakages(android.content.Context p6, com.safesys.viruskiller.MainActivity p7, String p8)
	    {
	        java.util.Iterator v1 = p6.getPackageManager().getInstalledApplications(128).iterator();
	        android.content.pm.PackageManager v2 = p7.getPackageManager();
	        while (v1.hasNext()) {
	            android.content.pm.ApplicationInfo v0_1 = ((android.content.pm.ApplicationInfo) v1.next());
	            if (v0_1.packageName.equals(p8)) {
	                android.graphics.drawable.Drawable v3_5 = v0_1.loadIcon(v2);
	            }
	            return v3_5;
	        }
	        v3_5 = 0;
	        return v3_5;
	    }
	
	
	    public int isLinuxProcessExist()
	    {
	        int v4 = -1;
	        java.io.BufferedReader v0 = 0;
	        try {
	            Process v7 = Runtime.getRuntime().exec("ps");
	            v7.getOutputStream().close();
	            java.io.BufferedReader v1_1 = new java.io.BufferedReader(new java.io.InputStreamReader(v7.getInputStream()));
	        } catch (String v10_4) {
	            java.io.IOException v3_0 = v10_4;
	            v3_0.printStackTrace();
	            if (v0 == null) {
	                return v4;
	            } else {
	                try {
	                    v0.close();
	                } catch (java.io.IOException v3_1) {
	                    v3_1.printStackTrace();
	                }
	                return v4;
	            }
	            if (v1_1 == null) {
	                return v4;
	            } else {
	                try {
	                    v1_1.close();
	                } catch (java.io.IOException v3_3) {
	                    v3_3.printStackTrace();
	                }
	                return v4;
	            }
	        } catch (String v10_18) {
	            if (v0 != null) {
	                try {
	                    v0.close();
	                } catch (java.io.IOException v3_2) {
	                    v3_2.printStackTrace();
	                }
	            }
	            throw v10_18;
	        }
	        try {
	            do {
	                String v6 = v1_1.readLine();
	            } while(v6.indexOf("/data/data/com.safesys.viruskiller/files/ScanRunner") <= 0);
	            String[] v9 = v6.split("\\s+ ");
	            if (!v9[0].trim().equals("root")) {
	                com.safesys.viruskiller.util.Utility.sProcID = v9[1].trim();
	                v4 = 0;
	            } else {
	                com.safesys.viruskiller.util.Utility.sProcID = v9[1].trim();
	                v4 = 1;
	            }
	        } catch (String v10_18) {
	            v0 = v1_1;
	        } catch (String v10_17) {
	            v3_0 = v10_17;
	            v0 = v1_1;
	        }
	        if (v6 != null) {
	            if (v6.indexOf("/data/data/com.safesys.viruskiller/files/ScanRunner") > 0) {
	            }
	        }
	    }
	
	
	    public void scanFile(java.io.File p27, com.safesys.viruskiller.MainActivity p28, String p29)
	    {
	        while (!com.safesys.viruskiller.ScanningManagerService.isBlPFlag()) {
	            if (com.safesys.viruskiller.ScanningManagerService.getiScannState() != 0) {
	                String v6 = p27.getAbsolutePath();
	                if (!p27.isDirectory()) {
	                    if (p27.length() > 0) {
	                        if (com.safesys.viruskiller.MainActivity.listTrusted != null) {
	                            int v15 = 0;
	                            while (v15 < com.safesys.viruskiller.MainActivity.listTrusted.size()) {
	                                if (!((android.content.ContentValues) com.safesys.viruskiller.MainActivity.listTrusted.get(v15)).getAsString("virus_path").equals(v6)) {
	                                    v15++;
	                                }
	                                return;
	                            }
	                        }
	                        int v23 = 0;
	                        int v16 = (v6.length() - 4);
	                        if ((v16 > 0) && (!v6.contains("com.safesys.viruskiller"))) {
	                            String v22 = v6.substring(v16).toLowerCase();
	                            if ((v22.equals(".apk")) || ((v22.equals(".jar")) || ((v22.equals(".cab")) || ((v22.equals("odex")) || (v22.equals(".zip")))))) {
	                                v23 = 3;
	                            }
	                        }
	                        if (com.opensystem.terminator.ScanVirus.scanFile(v6, v23) == 0) {
	                            com.safesys.viruskiller.Virus v25_1 = new com.safesys.viruskiller.Virus();
	                            v25_1.setVirusName(com.opensystem.terminator.ScanVirus.getVirusName());
	                            v25_1.setVirusDesc(com.opensystem.terminator.ScanVirus.getVirusDesc());
	                            v25_1.setVirusPath(v6);
	                            v25_1.setVirusPackageName(p29);
	                            com.safesys.viruskiller.VirusDBAdpter v3 = new com.safesys.viruskiller.VirusDBAdpter;
	                            v3(p28);
	                            v3.open();
	                            java.util.ArrayList v12 = v3.findAllByName(v6);
	                            if (v12 != null) {
	                                v25_1.setlID(((android.content.ContentValues) v12.get(0)).getAsLong("_id").longValue());
	                            } else {
	                                java.util.Calendar v13 = java.util.Calendar.getInstance();
	                                // Both branches of the condition point to the same code.
	                                // if (p29 == null) {
	                                    v25_1.setlID(v3.insertVirusEntry(v25_1.getVirusName(), v25_1.getVirusDesc(), v6, "0", "0", new StringBuilder(String.valueOf(v13.getTimeInMillis())).toString(), new StringBuilder(String.valueOf(v6)).append("_bak").toString(), p29));
	                                // }
	                            }
	                            com.safesys.viruskiller.MainActivity.virusList.add(v25_1);
	                            p28.mum_threat_files = (p28.mum_threat_files + 1);
	                            v3.close();
	                        }
	                    }
	                    p28.mum_scanned_files = (p28.mum_scanned_files + 1);
	                    p28.updateScanPath(v6);
	                } else {
	                    try {
	                        String v20 = p27.getCanonicalPath();
	                    } catch (java.io.IOException v14) {
	                        v20 = "";
	                    }
	                    if (v6.equals(v20)) {
	                        this.scanDir(p27, p28);
	                    }
	                }
	            }
	            return;
	        }
	        try {
	            Thread.currentThread();
	            Thread.sleep(100);
	        } catch (boolean v4_2) {
	            v4_2.printStackTrace();
	        }
	    }
	
	
	    public void scanPakages(android.content.Context p8, com.safesys.viruskiller.MainActivity p9)
	    {
	        java.util.Iterator v2 = p8.getPackageManager().getInstalledApplications(128).iterator();
	        while (v2.hasNext()) {
	            android.content.pm.ApplicationInfo v0_1 = ((android.content.pm.ApplicationInfo) v2.next());
	            this.scanFile(new java.io.File(v0_1.publicSourceDir), p9, v0_1.packageName);
	        }
	        return;
	    }
	
	
	    public void startListening(String p8)
	    {
	        int[] v2 = new int[1];
	        this.createSubprocess(v2);
	        new Thread(new com.safesys.viruskiller.util.Utility$2(this, v2[0], new com.safesys.viruskiller.util.Utility$1(this))).start();
	        this.mTermOut = new java.io.FileOutputStream(this.mTermFd);
	        if (p8 != null) {
	            this.write(new StringBuilder(String.valueOf(p8)).append(13).toString());
	        }
	        this.sendInitialCommand();
	        return;
	    }
	
