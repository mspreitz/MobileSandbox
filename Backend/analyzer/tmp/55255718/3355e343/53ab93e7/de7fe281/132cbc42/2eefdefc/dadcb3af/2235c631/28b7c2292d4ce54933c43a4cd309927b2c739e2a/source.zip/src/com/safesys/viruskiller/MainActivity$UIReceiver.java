	final synthetic com.safesys.viruskiller.MainActivity this$0
	
	    public MainActivity$UIReceiver(com.safesys.viruskiller.MainActivity p1)
	    {
	        this.this$0 = p1;
	        return;
	    }
	
	
	    public void onReceive(android.content.Context p6, android.content.Intent p7)
	    {
	        int v0 = p7.getIntExtra("count", -1);
	        this.this$0.loadtip.setVisibility(0);
	        com.safesys.viruskiller.MainActivity.access$0(this.this$0).setVisibility(0);
	        this.this$0.loadtip.setText(new StringBuilder("\u52a0\u8f7d\u4e86").append(v0).append("%").toString());
	        if (v0 == 100) {
	            com.safesys.viruskiller.MainActivity.access$0(this.this$0).setVisibility(8);
	            this.this$0.loadtip.setVisibility(8);
	        }
	        return;
	    }
	
