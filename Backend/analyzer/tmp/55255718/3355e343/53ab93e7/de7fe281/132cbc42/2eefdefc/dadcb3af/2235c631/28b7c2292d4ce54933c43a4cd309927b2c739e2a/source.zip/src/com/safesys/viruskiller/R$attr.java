	public static final  backgroundColor
	public static final  refreshInterval
	public static final  testing
	public static final  textColor
	
	    public R$attr()
	    {
	        return;
	    }
	
