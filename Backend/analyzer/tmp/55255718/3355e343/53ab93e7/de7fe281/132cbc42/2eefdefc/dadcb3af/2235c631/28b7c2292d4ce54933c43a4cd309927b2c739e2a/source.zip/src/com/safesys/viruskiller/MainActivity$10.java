	final synthetic com.safesys.viruskiller.MainActivity this$0
	private final synthetic com.safesys.viruskiller.Virus val$v
	
	    MainActivity$10(com.safesys.viruskiller.MainActivity p1, com.safesys.viruskiller.Virus p2)
	    {
	        this.this$0 = p1;
	        this.val$v = p2;
	        return;
	    }
	
	
	    public void run()
	    {
	        com.safesys.viruskiller.VirusDBAdpter v0_1 = new com.safesys.viruskiller.VirusDBAdpter(com.safesys.viruskiller.MainActivity.access$2());
	        v0_1.open();
	        v0_1.updateQflagEntry(this.val$v.getlID(), "1");
	        v0_1.close();
	        this.this$0.dealUpdate(this.val$v);
	        return;
	    }
	
