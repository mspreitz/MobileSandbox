	final synthetic com.safesys.viruskiller.MainActivity$UpdateReceiver this$1
	
	    MainActivity$UpdateReceiver$1(com.safesys.viruskiller.MainActivity$UpdateReceiver p1)
	    {
	        this.this$1 = p1;
	        return;
	    }
	
	
	    public void run()
	    {
	        com.safesys.viruskiller.MainActivity$UpdateReceiver.access$0(this.this$1).copyright_info.setText(new StringBuilder(String.valueOf(com.safesys.viruskiller.MainActivity$UpdateReceiver.access$0(this.this$1).getString(2131099650))).append(" ").append(com.safesys.viruskiller.MainActivity$UpdateReceiver.access$0(this.this$1).getString(2131099681)).toString());
	        return;
	    }
	
