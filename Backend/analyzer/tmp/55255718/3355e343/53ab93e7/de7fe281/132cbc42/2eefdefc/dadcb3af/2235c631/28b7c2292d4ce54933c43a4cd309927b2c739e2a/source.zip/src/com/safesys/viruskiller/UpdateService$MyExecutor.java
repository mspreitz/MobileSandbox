	 java.lang.Process process
	 java.io.DataInputStream stderr
	 java.io.DataInputStream stdin
	 java.io.DataOutputStream stdout
	final synthetic com.safesys.viruskiller.UpdateService this$0
	
	    UpdateService$MyExecutor(com.safesys.viruskiller.UpdateService p2)
	    {
	        this.this$0 = p2;
	        this.process = 0;
	        this.stdout = 0;
	        this.stdin = 0;
	        this.stderr = 0;
	        return;
	    }
	
	
	    public void close()
	    {
	        try {
	            if (this.stdout != null) {
	                this.stdout.writeBytes("exit\n");
	                this.stdout.flush();
	                this.waitFor();
	                try {
	                    this.stdin.close();
	                } catch (Process v1) {
	                    this.stdin = 0;
	                    this.stderr.close();
	                    this.stderr = 0;
	                    this.stdout.close();
	                    this.stdout = 0;
	                    this.process = 0;
	                    this.process.destroy();
	                } catch (Process v1_6) {
	                    this.stdin = 0;
	                    throw v1_6;
	                }
	                this.stdin = 0;
	            }
	        } catch (Process v1_17) {
	            v1_17.printStackTrace();
	        }
	        return;
	    }
	
	
	    public void execute(String p6, int p7)
	    {
	        try {
	            if (this.stdout != null) {
	                this.stdout.writeBytes(p6);
	                this.stdout.writeBytes("\n");
	                this.stdout.flush();
	                android.os.SystemClock.sleep(((long) p7));
	                byte[] v0 = new byte[this.stderr.available()];
	                this.stderr.read(v0, 0, this.stderr.available());
	            }
	        } catch (java.io.DataInputStream v2_8) {
	            v2_8.printStackTrace();
	        }
	        return;
	    }
	
	
	    public boolean init()
	    {
	        try {
	            int v3_16;
	            String v0 = com.safesys.viruskiller.UpdateService.access$0(this.this$0, 11);
	            String v1 = com.safesys.viruskiller.UpdateService.access$0(this.this$0, 12);
	            this.process = Runtime.getRuntime().exec(v0);
	            this.stdout = new java.io.DataOutputStream(this.process.getOutputStream());
	            this.stdin = new java.io.DataInputStream(this.process.getInputStream());
	            this.stderr = new java.io.DataInputStream(this.process.getErrorStream());
	            this.stdout.writeBytes(v1);
	            this.stdout.flush();
	            android.os.SystemClock.sleep(1000);
	        } catch (int v3_15) {
	            v3_15.printStackTrace();
	            v3_16 = 0;
	            return v3_16;
	        }
	        if (this.stderr.available() <= 0) {
	            v3_16 = 1;
	            return v3_16;
	        } else {
	            v3_16 = 0;
	            return v3_16;
	        }
	    }
	
	
	    public void waitFor()
	    {
	        try {
	            if (this.process != null) {
	                this.process.waitFor();
	            }
	        } catch (Process v1_2) {
	            v1_2.printStackTrace();
	        }
	        return;
	    }
	
