	private  bRun
	private Ljava.lang.String colName
	private android.content.Context context
	private  iResource
	private java.util.ArrayList list
	private android.view.LayoutInflater mInflater
	 android.widget.PopupWindow popupWindow
	final synthetic com.safesys.viruskiller.MainActivity this$0
	private I to
	
	    public MainActivity$MyTAdapter(com.safesys.viruskiller.MainActivity p2, android.content.Context p3, java.util.ArrayList p4, int p5, String[] p6, int[] p7)
	    {
	        this.this$0 = p2;
	        this.context = 0;
	        this.popupWindow = 0;
	        this.bRun = 0;
	        if (this.list != null) {
	            this.list.clear();
	        }
	        this.mInflater = android.view.LayoutInflater.from(p3);
	        this.context = p3;
	        this.list = p4;
	        this.iResource = p5;
	        this.colName = p6;
	        this.to = p7;
	        return;
	    }
	
	
	    static synthetic com.safesys.viruskiller.MainActivity access$0(com.safesys.viruskiller.MainActivity$MyTAdapter p1)
	    {
	        return p1.this$0;
	    }
	
	
	    public int getCount()
	    {
	        return this.list.size();
	    }
	
	
	    public Object getItem(int p2)
	    {
	        return this.list.get(p2);
	    }
	
	
	    public long getItemId(int p3)
	    {
	        return ((long) p3);
	    }
	
	
	    public java.util.ArrayList getList()
	    {
	        return this.list;
	    }
	
	
	    public android.view.View getView(int p22, android.view.View p23, android.view.ViewGroup p24)
	    {
	        if (p23 == null) {
	            p23 = this.mInflater.inflate(this.iResource, 0);
	        }
	        String v12_1 = ((String) ((java.util.Map) this.list.get(p22)).get(this.colName[0]));
	        String v10_1 = ((String) ((java.util.Map) this.list.get(p22)).get(this.colName[1]));
	        String v13_1 = ((String) ((java.util.Map) this.list.get(p22)).get(this.colName[2]));
	        String v11_1 = ((String) ((java.util.Map) this.list.get(p22)).get(this.colName[3]));
	        android.widget.TextView v15_1 = ((android.widget.TextView) p23.findViewById(this.to[0]));
	        android.widget.TextView v14_1 = ((android.widget.TextView) p23.findViewById(this.to[1]));
	        android.widget.TextView v16_1 = ((android.widget.TextView) p23.findViewById(this.to[2]));
	        android.widget.Button v4_1 = ((android.widget.Button) p23.findViewById(2131230779));
	        android.widget.ImageView v7_1 = ((android.widget.ImageView) p23.findViewById(2131230776));
	        int v6 = 0;
	        while (v6 < com.safesys.viruskiller.MainActivity.listTrusted.size()) {
	            android.content.ContentValues v17_1 = ((android.content.ContentValues) com.safesys.viruskiller.MainActivity.listTrusted.get(v6));
	            String v8 = v17_1.getAsString("virus_bak");
	            String v9 = v17_1.getAsString("virus_path");
	            if ((v9 != null) && ((v9.equals(v13_1)) && (v8 != null))) {
	                android.graphics.drawable.Drawable v5 = com.safesys.viruskiller.MainActivity.access$3(this.this$0).iconPakages(com.safesys.viruskiller.MainActivity.access$2(), com.safesys.viruskiller.MainActivity.access$2(), v8);
	                if (v5 != null) {
	                    v7_1.setImageDrawable(v5);
	                    break;
	                }
	            }
	            v6++;
	        }
	        v4_1.setText(this.this$0.getString(2131099675));
	        com.safesys.viruskiller.util.Utility v18_31 = new com.safesys.viruskiller.MainActivity$MyTAdapter$1;
	        v18_31(this, v11_1);
	        v4_1.setOnClickListener(v18_31);
	        v15_1.setText(v12_1);
	        v14_1.setText(v10_1);
	        v16_1.setText(v13_1);
	        return p23;
	    }
	
	
	    public void setList(java.util.ArrayList p1)
	    {
	        this.list = p1;
	        return;
	    }
	
