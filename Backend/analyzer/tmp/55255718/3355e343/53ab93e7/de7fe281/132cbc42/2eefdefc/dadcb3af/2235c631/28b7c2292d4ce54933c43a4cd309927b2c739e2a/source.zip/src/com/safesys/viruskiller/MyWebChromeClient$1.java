	final synthetic com.safesys.viruskiller.MyWebChromeClient this$0
	
	    MyWebChromeClient$1(com.safesys.viruskiller.MyWebChromeClient p1)
	    {
	        this.this$0 = p1;
	        return;
	    }
	
	
	    public boolean onKey(android.content.DialogInterface p4, int p5, android.view.KeyEvent p6)
	    {
	        android.util.Log.v("onJsAlert", new StringBuilder("keyCode==").append(p5).append("event=").append(p6).toString());
	        return 1;
	    }
	
