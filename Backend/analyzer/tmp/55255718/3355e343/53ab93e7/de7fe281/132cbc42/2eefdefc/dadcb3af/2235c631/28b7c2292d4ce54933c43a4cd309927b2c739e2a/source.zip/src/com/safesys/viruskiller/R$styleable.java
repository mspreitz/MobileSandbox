	public static final I com_wooboo_adlib_android_WoobooAdView
	public static final  com_wooboo_adlib_android_WoobooAdView_backgroundColor
	public static final  com_wooboo_adlib_android_WoobooAdView_refreshInterval
	public static final  com_wooboo_adlib_android_WoobooAdView_testing
	public static final  com_wooboo_adlib_android_WoobooAdView_textColor
	
	    static R$styleable()
	    {
	        int[] v0_1 = new int[4];
	        v0_1 = {2130771968, 2130771969, 2130771970, 2130771971};
	        com.safesys.viruskiller.R$styleable.com_wooboo_adlib_android_WoobooAdView = v0_1;
	        return;
	    }
	
	
	    public R$styleable()
	    {
	        return;
	    }
	
