	final synthetic com.safesys.viruskiller.MainActivity this$0
	
	    MainActivity$8(com.safesys.viruskiller.MainActivity p1)
	    {
	        this.this$0 = p1;
	        return;
	    }
	
	
	    public void onClick(android.content.DialogInterface p1, int p2)
	    {
	        return;
	    }
	
