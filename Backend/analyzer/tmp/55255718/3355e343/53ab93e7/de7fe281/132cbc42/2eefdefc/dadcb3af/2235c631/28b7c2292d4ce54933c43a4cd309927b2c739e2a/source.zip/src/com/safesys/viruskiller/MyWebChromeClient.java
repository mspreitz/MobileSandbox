	  b
	private android.content.Context context
	
	    public MyWebChromeClient(android.content.Context p2)
	    {
	        this.b = 1;
	        this.context = p2;
	        return;
	    }
	
	
	    public void onCloseWindow(android.webkit.WebView p1)
	    {
	        super.onCloseWindow(p1);
	        return;
	    }
	
	
	    public boolean onCreateWindow(android.webkit.WebView p2, boolean p3, boolean p4, android.os.Message p5)
	    {
	        return super.onCreateWindow(p2, p3, p4, p5);
	    }
	
	
	    public boolean onJsAlert(android.webkit.WebView p6, String p7, String p8, android.webkit.JsResult p9)
	    {
	        android.app.AlertDialog$Builder v0_1 = new android.app.AlertDialog$Builder(p6.getContext());
	        v0_1.setTitle("\u63d0\u793a").setMessage("\u786e\u5b9a\u4e0b\u8f7d").setPositiveButton("\u786e\u5b9a", 0);
	        v0_1.setOnKeyListener(new com.safesys.viruskiller.MyWebChromeClient$1(this));
	        v0_1.setCancelable(0);
	        v0_1.create().show();
	        p9.confirm();
	        return 1;
	    }
	
	
	    public boolean onJsBeforeUnload(android.webkit.WebView p2, String p3, String p4, android.webkit.JsResult p5)
	    {
	        return super.onJsBeforeUnload(p2, p3, p4, p5);
	    }
	
	
	    public boolean onJsConfirm(android.webkit.WebView p6, String p7, String p8, android.webkit.JsResult p9)
	    {
	        android.app.AlertDialog$Builder v0_1 = new android.app.AlertDialog$Builder(p6.getContext());
	        v0_1.setTitle("\u63d0\u793a").setMessage("\u786e\u5b9a\u4e0b\u8f7d").setPositiveButton("\u786e\u5b9a", new com.safesys.viruskiller.MyWebChromeClient$2(this, p9)).setNeutralButton("\u53d6\u6d88", new com.safesys.viruskiller.MyWebChromeClient$3(this, p9));
	        v0_1.setOnCancelListener(new com.safesys.viruskiller.MyWebChromeClient$4(this, p9));
	        v0_1.setOnKeyListener(new com.safesys.viruskiller.MyWebChromeClient$5(this));
	        v0_1.create().show();
	        return 1;
	    }
	
	
	    public boolean onJsPrompt(android.webkit.WebView p7, String p8, String p9, String p10, android.webkit.JsPromptResult p11)
	    {
	        android.app.AlertDialog$Builder v0_1 = new android.app.AlertDialog$Builder(p7.getContext());
	        v0_1.setTitle("\u63d0\u793a").setMessage("\u786e\u5b9a\u4e0b\u8f7d");
	        android.widget.EditText v2_1 = new android.widget.EditText(p7.getContext());
	        v2_1.setSingleLine();
	        v2_1.setText(p10);
	        v0_1.setView(v2_1);
	        v0_1.setPositiveButton("\u786e\u5b9a", new com.safesys.viruskiller.MyWebChromeClient$6(this, p11, v2_1)).setNeutralButton("\u53d6\u6d88", new com.safesys.viruskiller.MyWebChromeClient$7(this, p11));
	        v0_1.setOnKeyListener(new com.safesys.viruskiller.MyWebChromeClient$8(this));
	        v0_1.create().show();
	        return 1;
	    }
	
	
	    public void onProgressChanged(android.webkit.WebView p6, int p7)
	    {
	        android.content.Intent v0_1 = new android.content.Intent("uiupdate");
	        if (!this.b) {
	            v0_1.putExtra("cmd", 1);
	        } else {
	            v0_1.putExtra("cmd", 0);
	        }
	        v0_1.putExtra("count", p7);
	        this.context.sendBroadcast(v0_1);
	        this.b = 0;
	        if (p7 == 100) {
	            this.b = 1;
	        }
	        super.onProgressChanged(p6, p7);
	        return;
	    }
	
	
	    public void onReceivedIcon(android.webkit.WebView p1, android.graphics.Bitmap p2)
	    {
	        super.onReceivedIcon(p1, p2);
	        return;
	    }
	
	
	    public void onReceivedTitle(android.webkit.WebView p1, String p2)
	    {
	        super.onReceivedTitle(p1, p2);
	        return;
	    }
	
	
	    public void onRequestFocus(android.webkit.WebView p1)
	    {
	        super.onRequestFocus(p1);
	        return;
	    }
	
