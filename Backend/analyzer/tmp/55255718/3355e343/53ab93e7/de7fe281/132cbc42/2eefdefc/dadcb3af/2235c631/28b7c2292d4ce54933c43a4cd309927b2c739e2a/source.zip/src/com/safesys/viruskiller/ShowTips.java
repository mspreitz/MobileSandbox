	private static final  DIALOG_GRANT_SU
	private java.lang.String msg
	
	    public ShowTips()
	    {
	        this.msg = 0;
	        return;
	    }
	
	
	    public void onCreate(android.os.Bundle p6)
	    {
	        super.onCreate(p6);
	        android.widget.LinearLayout v1_1 = new android.widget.LinearLayout(this);
	        v1_1.setOrientation(1);
	        v1_1.setLayoutParams(new android.widget.LinearLayout$LayoutParams(-1, -2));
	        v1_1.setGravity(17);
	        this.setContentView(v1_1);
	        android.os.Bundle v0 = this.getIntent().getExtras();
	        if (v0 == null) {
	            this.finish();
	        }
	        this.msg = v0.getString("MM");
	        this.showDialog(0);
	        return;
	    }
	
	
	    protected android.app.Dialog onCreateDialog(int p5)
	    {
	        android.app.AlertDialog v0;
	        switch (p5) {
	            case 0:
	                v0 = new android.app.AlertDialog$Builder(this).setIcon(17301659).setTitle("\u8bf7\u6388\u6743").setMessage(this.msg).setNeutralButton("\u786e\u8ba4", new com.safesys.viruskiller.ShowTips$1(this)).create();
	                break;
	            default:
	                this.finish();
	                v0 = 0;
	        }
	        return v0;
	    }
	
