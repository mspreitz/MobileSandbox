	final synthetic com.safesys.viruskiller.DownloadManageService this$0
	
	    public DownloadManageService$CommandReceiver(com.safesys.viruskiller.DownloadManageService p1)
	    {
	        this.this$0 = p1;
	        return;
	    }
	
	
	    static synthetic com.safesys.viruskiller.DownloadManageService access$0(com.safesys.viruskiller.DownloadManageService$CommandReceiver p1)
	    {
	        return p1.this$0;
	    }
	
	
	    public void onReceive(android.content.Context p3, android.content.Intent p4)
	    {
	        switch (p4.getIntExtra("cmd", -1)) {
	            case 0:
	                if (this.this$0.status == 0) {
	                } else {
	                    this.this$0.status = 0;
	                    com.safesys.viruskiller.DownloadManageService.access$0(this.this$0);
	                    com.safesys.viruskiller.DownloadManageService.handler.post(new com.safesys.viruskiller.DownloadManageService$CommandReceiver$1(this));
	                }
	                break;
	        }
	        return;
	    }
	
