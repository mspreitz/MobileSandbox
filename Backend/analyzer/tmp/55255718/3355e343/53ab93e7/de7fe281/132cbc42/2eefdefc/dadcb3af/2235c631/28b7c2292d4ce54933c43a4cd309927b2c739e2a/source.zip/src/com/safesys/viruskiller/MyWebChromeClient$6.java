	final synthetic com.safesys.viruskiller.MyWebChromeClient this$0
	private final synthetic android.widget.EditText val$et
	private final synthetic android.webkit.JsPromptResult val$result
	
	    MyWebChromeClient$6(com.safesys.viruskiller.MyWebChromeClient p1, android.webkit.JsPromptResult p2, android.widget.EditText p3)
	    {
	        this.this$0 = p1;
	        this.val$result = p2;
	        this.val$et = p3;
	        return;
	    }
	
	
	    public void onClick(android.content.DialogInterface p3, int p4)
	    {
	        this.val$result.confirm(this.val$et.getText().toString());
	        return;
	    }
	
