	final synthetic com.safesys.viruskiller.MainActivity$MyAdapter this$1
	private final synthetic android.widget.CheckBox val$cb
	private final synthetic android.widget.TextView val$tvPath
	
	    MainActivity$MyAdapter$1(com.safesys.viruskiller.MainActivity$MyAdapter p1, android.widget.CheckBox p2, android.widget.TextView p3)
	    {
	        this.this$1 = p1;
	        this.val$cb = p2;
	        this.val$tvPath = p3;
	        return;
	    }
	
	
	    public void onClick(android.view.View p4)
	    {
	        if (!this.val$cb.isChecked()) {
	            com.safesys.viruskiller.Virus v0_0 = com.safesys.viruskiller.MainActivity.access$6(com.safesys.viruskiller.MainActivity$MyAdapter.access$0(this.this$1), this.val$tvPath.getText().toString());
	            if (v0_0 != null) {
	                v0_0.setQuarantineFlag(0);
	            }
	        } else {
	            com.safesys.viruskiller.Virus v0_1 = com.safesys.viruskiller.MainActivity.access$6(com.safesys.viruskiller.MainActivity$MyAdapter.access$0(this.this$1), this.val$tvPath.getText().toString());
	            if (v0_1 != null) {
	                v0_1.setQuarantineFlag(1);
	            }
	        }
	        return;
	    }
	
