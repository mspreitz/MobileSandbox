	public static final  PopupAnimation
	public static final  mytheme
	
	    public R$style()
	    {
	        return;
	    }
	
