	final synthetic com.safesys.viruskiller.view.MyProcessBar this$0
	private final synthetic  val$length
	
	    MyProcessBar$1(com.safesys.viruskiller.view.MyProcessBar p1, int p2)
	    {
	        this.this$0 = p1;
	        this.val$length = p2;
	        return;
	    }
	
	
	    public void run()
	    {
	        com.safesys.viruskiller.view.MyProcessBar.access$0(this.this$0, this.val$length);
	        return;
	    }
	
