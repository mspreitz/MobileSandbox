	private android.content.Context ctx
	 android.os.Handler handler
	 android.widget.ImageView viewin
	 android.widget.ImageView viewout
	
	    public MyProcessBar(android.content.Context p3, android.util.AttributeSet p4)
	    {
	        this(p3, p4);
	        this.ctx = p3;
	        this.handler = new android.os.Handler(this.getContext().getMainLooper());
	        this.Alter(120);
	        return;
	    }
	
	
	    private void Alter(int p3)
	    {
	        this.removeAllViews();
	        this.addView(this.getViewIn(this.ctx, p3));
	        this.addView(this.getViewOut(this.ctx, (300 - p3)));
	        this.invalidate();
	        return;
	    }
	
	
	    static synthetic void access$0(com.safesys.viruskiller.view.MyProcessBar p0, int p1)
	    {
	        p0.Alter(p1);
	        return;
	    }
	
	
	    private android.widget.ImageView getViewIn(android.content.Context p4, int p5)
	    {
	        this.viewin = new android.widget.ImageView(p4);
	        this.viewin.setLayoutParams(new android.widget.LinearLayout$LayoutParams(p5, 8));
	        this.viewin.setBackgroundResource(2130837509);
	        this.viewin.invalidate();
	        return this.viewin;
	    }
	
	
	    private android.widget.ImageView getViewOut(android.content.Context p4, int p5)
	    {
	        this.viewout = new android.widget.ImageView(p4);
	        this.viewout.setLayoutParams(new android.widget.LinearLayout$LayoutParams(p5, 8));
	        this.viewout.setBackgroundResource(2130837510);
	        this.viewout.invalidate();
	        return this.viewout;
	    }
	
	
	    public void AlterValue(int p3)
	    {
	        this.handler.post(new com.safesys.viruskiller.view.MyProcessBar$1(this, p3));
	        return;
	    }
	
