	final synthetic com.safesys.viruskiller.DownloadManageService this$0
	
	    DownloadManageService$1(com.safesys.viruskiller.DownloadManageService p1)
	    {
	        this.this$0 = p1;
	        return;
	    }
	
	
	    public void run()
	    {
	        String v1 = com.opensystem.terminator.VirusBackRunner.getVersionCode();
	        com.safesys.viruskiller.DownloadManageService.SdkVersion = com.opensystem.terminator.VirusBackRunner.getCurrVersion();
	        if ((v1 != null) && ((!com.safesys.viruskiller.DownloadManageService.blUpdate) && (!v1.equals(com.safesys.viruskiller.DownloadManageService.SdkVersion)))) {
	            com.safesys.viruskiller.DownloadManageService.blUpdate = 1;
	            android.content.SharedPreferences$Editor v0 = com.safesys.viruskiller.DownloadManageService.preferences.edit();
	            v0.putBoolean("download_autoupdate_flag", com.safesys.viruskiller.DownloadManageService.blUpdate);
	            v0.commit();
	        }
	        return;
	    }
	
