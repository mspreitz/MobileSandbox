	private  blKill
	private  lID
	private  quarantineFlag
	private java.lang.String virusDesc
	private  virusGrade
	private java.lang.String virusName
	private java.lang.String virusPackageName
	private java.lang.String virusPath
	private java.lang.String virusQuarantinePath
	
	    public Virus()
	    {
	        this.lID = -1;
	        this.virusPackageName = 0;
	        this.blKill = 0;
	        this.virusName = 0;
	        this.virusDesc = 0;
	        this.virusGrade = 0;
	        this.quarantineFlag = 0;
	        this.virusPath = 0;
	        this.virusQuarantinePath = 0;
	        return;
	    }
	
	
	    public int getQuarantineFlag()
	    {
	        return this.quarantineFlag;
	    }
	
	
	    public String getVirusDesc()
	    {
	        return this.virusDesc;
	    }
	
	
	    public int getVirusGrade()
	    {
	        return this.virusGrade;
	    }
	
	
	    public String getVirusName()
	    {
	        return this.virusName;
	    }
	
	
	    public String getVirusPackageName()
	    {
	        return this.virusPackageName;
	    }
	
	
	    public String getVirusPath()
	    {
	        return this.virusPath;
	    }
	
	
	    public String getVirusQuarantinePath()
	    {
	        return this.virusQuarantinePath;
	    }
	
	
	    public long getlID()
	    {
	        return this.lID;
	    }
	
	
	    public boolean isBlKill()
	    {
	        return this.blKill;
	    }
	
	
	    public void setBlKill(boolean p1)
	    {
	        this.blKill = p1;
	        return;
	    }
	
	
	    public void setQuarantineFlag(int p1)
	    {
	        this.quarantineFlag = p1;
	        return;
	    }
	
	
	    public void setVirusDesc(String p1)
	    {
	        this.virusDesc = p1;
	        return;
	    }
	
	
	    public void setVirusGrade(int p1)
	    {
	        this.virusGrade = p1;
	        return;
	    }
	
	
	    public void setVirusName(String p1)
	    {
	        this.virusName = p1;
	        return;
	    }
	
	
	    public void setVirusPackageName(String p1)
	    {
	        this.virusPackageName = p1;
	        return;
	    }
	
	
	    public void setVirusPath(String p1)
	    {
	        this.virusPath = p1;
	        return;
	    }
	
	
	    public void setVirusQuarantinePath(String p1)
	    {
	        this.virusQuarantinePath = p1;
	        return;
	    }
	
	
	    public void setlID(long p1)
	    {
	        this.lID = p1;
	        return;
	    }
	
