	private  bRun
	private Ljava.lang.String colName
	private android.content.Context context
	private  iResource
	private java.util.ArrayList list
	private android.view.LayoutInflater mInflater
	final synthetic com.safesys.viruskiller.MainActivity this$0
	private I to
	
	    public MainActivity$MyAdapter(com.safesys.viruskiller.MainActivity p2, android.content.Context p3, java.util.ArrayList p4, int p5, String[] p6, int[] p7)
	    {
	        this.this$0 = p2;
	        this.context = 0;
	        this.bRun = 0;
	        if (this.list != null) {
	            this.list.clear();
	        }
	        this.mInflater = android.view.LayoutInflater.from(p3);
	        this.context = p3;
	        this.list = p4;
	        this.iResource = p5;
	        this.colName = p6;
	        this.to = p7;
	        return;
	    }
	
	
	    static synthetic com.safesys.viruskiller.MainActivity access$0(com.safesys.viruskiller.MainActivity$MyAdapter p1)
	    {
	        return p1.this$0;
	    }
	
	
	    public int getCount()
	    {
	        return this.list.size();
	    }
	
	
	    public Object getItem(int p2)
	    {
	        return this.list.get(p2);
	    }
	
	
	    public long getItemId(int p3)
	    {
	        return ((long) p3);
	    }
	
	
	    public java.util.ArrayList getList()
	    {
	        return this.list;
	    }
	
	
	    public android.view.View getView(int p19, android.view.View p20, android.view.ViewGroup p21)
	    {
	        if (p20 == null) {
	            p20 = this.mInflater.inflate(this.iResource, 0);
	        }
	        String v9_1 = ((String) ((java.util.Map) this.list.get(p19)).get(this.colName[0]));
	        String v8_1 = ((String) ((java.util.Map) this.list.get(p19)).get(this.colName[1]));
	        String v10_1 = ((String) ((java.util.Map) this.list.get(p19)).get(this.colName[2]));
	        android.widget.TextView v12_1 = ((android.widget.TextView) p20.findViewById(this.to[0]));
	        android.widget.TextView v11_1 = ((android.widget.TextView) p20.findViewById(this.to[1]));
	        android.widget.TextView v13_1 = ((android.widget.TextView) p20.findViewById(this.to[2]));
	        android.widget.CheckBox v4_1 = ((android.widget.CheckBox) p20.findViewById(2131230782));
	        android.widget.ImageView v6_1 = ((android.widget.ImageView) p20.findViewById(2131230776));
	        com.safesys.viruskiller.Virus v14 = com.safesys.viruskiller.MainActivity.access$6(this.this$0, v10_1);
	        if (v14 != null) {
	            String v7 = v14.getVirusPackageName();
	            if (v7 != null) {
	                android.graphics.drawable.Drawable v5 = com.safesys.viruskiller.MainActivity.access$3(this.this$0).iconPakages(com.safesys.viruskiller.MainActivity.access$2(), com.safesys.viruskiller.MainActivity.access$2(), v7);
	                if (v5 != null) {
	                    v6_1.setImageDrawable(v5);
	                }
	            }
	        }
	        com.safesys.viruskiller.util.Utility v15_21 = new com.safesys.viruskiller.MainActivity$MyAdapter$1;
	        v15_21(this, v4_1, v13_1);
	        v4_1.setOnClickListener(v15_21);
	        v12_1.setText(v9_1);
	        v11_1.setText(v8_1);
	        v13_1.setText(v10_1);
	        return p20;
	    }
	
	
	    public void setList(java.util.ArrayList p1)
	    {
	        this.list = p1;
	        return;
	    }
	
