	final synthetic com.safesys.viruskiller.MainActivity$4 this$1
	
	    MainActivity$4$2(com.safesys.viruskiller.MainActivity$4 p1)
	    {
	        this.this$1 = p1;
	        return;
	    }
	
	
	    public void run()
	    {
	        com.safesys.viruskiller.MainActivity$4.access$0(this.this$1).main_scanning_time.setText(new StringBuilder(String.valueOf(com.safesys.viruskiller.MainActivity$4.access$0(this.this$1).iSeconds)).append("s").toString());
	        if (com.safesys.viruskiller.MainActivity$4.access$0(this.this$1).iSeconds < 180) {
	            com.safesys.viruskiller.MainActivity$4.access$0(this.this$1).main_scanning_progress.AlterValue(com.safesys.viruskiller.MainActivity$4.access$0(this.this$1).iSeconds);
	        }
	        return;
	    }
	
