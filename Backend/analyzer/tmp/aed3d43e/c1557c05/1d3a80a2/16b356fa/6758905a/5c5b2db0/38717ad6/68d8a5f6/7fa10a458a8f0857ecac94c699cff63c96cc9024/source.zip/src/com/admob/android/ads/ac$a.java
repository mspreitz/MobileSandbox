	private java.lang.ref.WeakReference a
	
	    public ac$a(com.admob.android.ads.ac p2)
	    {
	        this.a = new ref.WeakReference(p2);
	        return;
	    }
	
	
	    public final void onCompletion(android.media.MediaPlayer p3)
	    {
	        com.admob.android.ads.ac v2_2 = ((com.admob.android.ads.ac) this.a.get());
	        if (v2_2 != null) {
	            v2_2.i = 1;
	            v2_2.f();
	            v2_2.a(1);
	        }
	        return;
	    }
	
	
	    public final boolean onError(android.media.MediaPlayer p4, int p5, int p6)
	    {
	        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	            android.util.Log.e("AdMobSDK", new StringBuilder().append("error playing video, what: ").append(p5).append(", extra: ").append(p6).toString());
	        }
	        int v0_10;
	        com.admob.android.ads.ac v3_2 = ((com.admob.android.ads.ac) this.a.get());
	        if (v3_2 != null) {
	            v3_2.c();
	            v0_10 = 1;
	        } else {
	            v0_10 = 0;
	        }
	        return v0_10;
	    }
	
	
	    public final void onPrepared(android.media.MediaPlayer p2)
	    {
	        com.admob.android.ads.ac v1_2 = ((com.admob.android.ads.ac) this.a.get());
	        if (v1_2 != null) {
	            v1_2.a();
	        }
	        return;
	    }
	
