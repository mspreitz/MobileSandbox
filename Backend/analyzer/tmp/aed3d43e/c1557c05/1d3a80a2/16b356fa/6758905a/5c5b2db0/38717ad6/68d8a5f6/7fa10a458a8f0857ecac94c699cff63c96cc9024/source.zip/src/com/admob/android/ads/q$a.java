	public static final enum com.admob.android.ads.q$a a
	public static final enum com.admob.android.ads.q$a b
	public static final enum com.admob.android.ads.q$a c
	private static final synthetic Lcom.admob.android.ads.q$a e
	private java.lang.String d
	
	    static q$a()
	    {
	        com.admob.android.ads.q$a.a = new com.admob.android.ads.q$a("PORTRAIT", 0, "p");
	        com.admob.android.ads.q$a.b = new com.admob.android.ads.q$a("LANDSCAPE", 1, "l");
	        com.admob.android.ads.q$a.c = new com.admob.android.ads.q$a("ANY", 2, "a");
	        com.admob.android.ads.q$a[] v0_7 = new com.admob.android.ads.q$a[3];
	        v0_7[0] = com.admob.android.ads.q$a.a;
	        v0_7[1] = com.admob.android.ads.q$a.b;
	        v0_7[2] = com.admob.android.ads.q$a.c;
	        com.admob.android.ads.q$a.e = v0_7;
	        return;
	    }
	
	
	    private q$a(String p1, int p2, String p3)
	    {
	        this(p1, p2);
	        this.d = p3;
	        return;
	    }
	
	
	    public static com.admob.android.ads.q$a a(int p7)
	    {
	        com.admob.android.ads.q$a[] v1 = com.admob.android.ads.q$a.values();
	        com.admob.android.ads.q$a v3_1 = com.admob.android.ads.q$a.c;
	        int v0_1 = 0;
	        while (v0_1 < v1.length) {
	            com.admob.android.ads.q$a v4 = v1[v0_1];
	            if (v4.ordinal() == p7) {
	                v3_1 = v4;
	            }
	            v0_1++;
	        }
	        return v3_1;
	    }
	
	
	    public static com.admob.android.ads.q$a valueOf(String p1)
	    {
	        return ((com.admob.android.ads.q$a) Enum.valueOf(com.admob.android.ads.q$a, p1));
	    }
	
	
	    public static com.admob.android.ads.q$a[] values()
	    {
	        return ((com.admob.android.ads.q$a[]) com.admob.android.ads.q$a.e.clone());
	    }
	
	
	    public final String toString()
	    {
	        return this.d;
	    }
	
