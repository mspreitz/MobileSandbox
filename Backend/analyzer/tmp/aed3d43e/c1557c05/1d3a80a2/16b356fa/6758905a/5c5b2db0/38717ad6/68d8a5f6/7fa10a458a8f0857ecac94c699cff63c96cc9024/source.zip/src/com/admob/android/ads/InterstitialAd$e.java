	private java.lang.ref.WeakReference a
	
	    public InterstitialAd$e(com.admob.android.ads.InterstitialAd p2)
	    {
	        this.a = new ref.WeakReference(p2);
	        return;
	    }
	
	
	    public final void run()
	    {
	        com.admob.android.ads.InterstitialAd v1_2 = ((com.admob.android.ads.InterstitialAd) this.a.get());
	        if (v1_2 != null) {
	            v1_2.b();
	        }
	        return;
	    }
	
