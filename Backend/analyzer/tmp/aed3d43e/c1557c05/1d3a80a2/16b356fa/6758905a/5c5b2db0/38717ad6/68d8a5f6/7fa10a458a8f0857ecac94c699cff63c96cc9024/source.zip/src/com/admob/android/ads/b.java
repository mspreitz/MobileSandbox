	private static java.lang.String a
	private static  b
	private static  c
	private static java.lang.String d
	private static  e
	private static  f
	
	    static b()
	    {
	        com.admob.android.ads.b.a = "http://r.admob.com/ad_source.php";
	        com.admob.android.ads.b.d = 0;
	        com.admob.android.ads.b.e = 0;
	        com.admob.android.ads.b.f = 0;
	        return;
	    }
	
	
	    b()
	    {
	        return;
	    }
	
	
	    static com.admob.android.ads.j a(com.admob.android.ads.m p14, android.content.Context p15, String p16, String p17, int p18, int p19, int p20, com.admob.android.ads.k p21, int p22, com.admob.android.ads.j$b p23, com.admob.android.ads.InterstitialAd$Event p24, com.admob.android.ads.AdView$f p25)
	    {
	        if (p15.checkCallingOrSelfPermission("android.permission.INTERNET") == -1) {
	            com.admob.android.ads.AdManager.clientError("Cannot request an ad without Internet permissions!  Open manifest.xml and just before the final </manifest> tag add:  <uses-permission android:name=\"android.permission.INTERNET\" />");
	        }
	        if (!com.admob.android.ads.b.f) {
	            com.admob.android.ads.b.f = 1;
	            org.json.JSONException v3_5 = 1;
	            boolean v4_2 = p15.getPackageManager().resolveActivity(new android.content.Intent(p15, com.admob.android.ads.AdMobActivity), 65536);
	            if ((v4_2) && ((v4_2.activityInfo != null) && ("com.admob.android.ads.AdMobActivity".equals(v4_2.activityInfo.name)))) {
	                if (v4_2.activityInfo.theme != 16973831) {
	                    if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                        android.util.Log.e("AdMobSDK", "The activity Theme for com.admob.android.ads.AdMobActivity is not @android:style/Theme.NoTitleBar.Fullscreen, please change in AndroidManifest.xml");
	                    }
	                    v3_5 = 0;
	                }
	                if ((v4_2.activityInfo.configChanges & 128) == 0) {
	                    if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                        android.util.Log.e("AdMobSDK", "The android:configChanges value of the com.admob.android.ads.AdMobActivity must include orientation");
	                    }
	                    v3_5 = 0;
	                }
	                if ((v4_2.activityInfo.configChanges & 16) == 0) {
	                    if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                        android.util.Log.e("AdMobSDK", "The android:configChanges value of the com.admob.android.ads.AdMobActivity must include keyboard");
	                    }
	                    v3_5 = 0;
	                }
	                if ((v4_2.activityInfo.configChanges & 32) == 0) {
	                    if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                        android.util.Log.e("AdMobSDK", "The android:configChanges value of the com.admob.android.ads.AdMobActivity must include keyboardHidden");
	                    }
	                    v3_5 = 0;
	                }
	            } else {
	                if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                    android.util.Log.e("AdMobSDK", "could not find com.admob.android.ads.AdMobActivity, please make sure it is registered in AndroidManifest.xml");
	                }
	                v3_5 = 0;
	            }
	            com.admob.android.ads.b.e = v3_5;
	        }
	        com.admob.android.ads.j v14_2;
	        if (com.admob.android.ads.b.e) {
	            com.admob.android.ads.t.a(p15);
	            long v12 = android.os.SystemClock.uptimeMillis();
	            com.admob.android.ads.k v9_1 = com.admob.android.ads.b.a(p15, p16, p17, p22, p23, p24, p25);
	            String v16_1 = com.admob.android.ads.g.a(com.admob.android.ads.b.a, 0, com.admob.android.ads.AdManager.getUserId(p15), 0, 3000, 0, v9_1);
	            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                android.util.Log.d("AdMobSDK", new StringBuilder().append("Requesting an ad with POST params:  ").append(v9_1).toString());
	            }
	            String v16_2;
	            String v22_7 = v16_1.d();
	            if (v22_7 == null) {
	                v16_2 = 0;
	            } else {
	                String v17_5 = new String;
	                v17_5(v16_1.a());
	                v16_2 = v17_5;
	            }
	            if (v22_7 == null) {
	                v14_2 = 0;
	            } else {
	                if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                    android.util.Log.d("AdMobSDK", "Ad response: ");
	                }
	                if (v16_2.equals("")) {
	                } else {
	                    String v17_11 = new org.json.JSONTokener;
	                    v17_11(v16_2);
	                    try {
	                        org.json.JSONObject v5_21 = new org.json.JSONObject;
	                        v5_21(v17_11);
	                    } catch (com.admob.android.ads.j v14_1) {
	                        if (!com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 5)) {
	                        } else {
	                            android.util.Log.w("AdMobSDK", new StringBuilder().append("Problem decoding ad response.  Cannot display ad: \"").append(v16_2).append("\"").toString(), v14_1);
	                        }
	                        v14_2 = com.admob.android.ads.j.a(p14, p15, v5_21, p18, p19, p20, p21, p23);
	                    }
	                    if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                        android.util.Log.d("AdMobSDK", v5_21.toString(4));
	                    }
	                }
	            }
	            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 4)) {
	                String v15_7 = (android.os.SystemClock.uptimeMillis() - v12);
	                if (v14_2 == null) {
	                    android.util.Log.i("AdMobSDK", new StringBuilder().append("No fill.  Server replied that no ads are available (").append(v15_7).append("ms)").toString());
	                }
	            }
	        } else {
	            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                android.util.Log.e("AdMobSDK", "com.admob.android.ads.AdMobActivity must be registered in your AndroidManifest.xml file.");
	            }
	            v14_2 = 0;
	        }
	        return v14_2;
	    }
	
	
	    static com.admob.android.ads.j a(com.admob.android.ads.m p12, android.content.Context p13, String p14, String p15, com.admob.android.ads.InterstitialAd$Event p16)
	    {
	        return com.admob.android.ads.b.a(p12, p13, p14, p15, -1, -1, -1, 0, -1, com.admob.android.ads.j$b.b, p16, 0);
	    }
	
	
	    static String a()
	    {
	        return com.admob.android.ads.b.a;
	    }
	
	
	    static String a(android.content.Context p7, String p8, String p9, int p10)
	    {
	        return com.admob.android.ads.b.a(p7, 0, 0, 0, 0, 0, 0);
	    }
	
	
	    private static String a(android.content.Context p6, String p7, String p8, int p9, com.admob.android.ads.j$b p10, com.admob.android.ads.InterstitialAd$Event p11, com.admob.android.ads.AdView$f p12)
	    {
	        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	            android.util.Log.d("AdMobSDK", "Ad request:");
	        }
	        int v1_4;
	        com.admob.android.ads.AdManager.a(p6);
	        StringBuilder v0_4 = new StringBuilder();
	        int v1_2 = System.currentTimeMillis();
	        v0_4.append("z").append("=").append((v1_2 / 1000)).append(".").append((v1_2 % 1000));
	        if (p10 != 0) {
	            v1_4 = p10;
	        } else {
	            v1_4 = com.admob.android.ads.j$b.c;
	        }
	        com.admob.android.ads.b.a(v0_4, "ad_type", v1_4.toString());
	        switch (com.admob.android.ads.b$1.a[v1_4.ordinal()]) {
	            case 1:
	                if (p11 == null) {
	                } else {
	                    com.admob.android.ads.b.a(v0_4, "event", String.valueOf(p11.ordinal()));
	                }
	                break;
	            case 2:
	                if (p12 == null) {
	                } else {
	                    com.admob.android.ads.b.a(v0_4, "dim", p12.toString());
	                }
	                break;
	        }
	        com.admob.android.ads.b.a(v0_4, "rt", "0");
	        android.net.Uri v11_5 = 0;
	        if (p10 == com.admob.android.ads.j$b.b) {
	            v11_5 = com.admob.android.ads.AdManager.getInterstitialPublisherId(p6);
	        }
	        if (v11_5 == null) {
	            v11_5 = com.admob.android.ads.AdManager.getPublisherId(p6);
	        }
	        if (v11_5 != null) {
	            com.admob.android.ads.b.a(v0_4, "s", v11_5);
	            com.admob.android.ads.b.a(v0_4, "l", com.admob.android.ads.t.a());
	            com.admob.android.ads.b.a(v0_4, "f", "jsonp");
	            com.admob.android.ads.b.a(v0_4, "client_sdk", "1");
	            com.admob.android.ads.b.a(v0_4, "ex", "1");
	            com.admob.android.ads.b.a(v0_4, "v", "20101109-ANDROID-3312276cc1406347");
	            com.admob.android.ads.b.a(v0_4, "isu", com.admob.android.ads.AdManager.getUserId(p6));
	            com.admob.android.ads.b.a(v0_4, "so", com.admob.android.ads.AdManager.getOrientation(p6));
	            if (p9 > null) {
	                com.admob.android.ads.b.a(v0_4, "screen_width", String.valueOf(p9));
	            }
	            com.admob.android.ads.b.a(v0_4, "d[coord]", com.admob.android.ads.AdManager.b(p6));
	            com.admob.android.ads.b.a(v0_4, "d[coord_timestamp]", com.admob.android.ads.AdManager.a());
	            com.admob.android.ads.b.a(v0_4, "d[pc]", com.admob.android.ads.AdManager.getPostalCode());
	            com.admob.android.ads.b.a(v0_4, "d[dob]", com.admob.android.ads.AdManager.b());
	            com.admob.android.ads.b.a(v0_4, "d[gender]", com.admob.android.ads.AdManager.c());
	            com.admob.android.ads.b.a(v0_4, "k", p7);
	            com.admob.android.ads.b.a(v0_4, "search", p8);
	            com.admob.android.ads.b.a(v0_4, "density", String.valueOf(com.admob.android.ads.k.d()));
	            if (com.admob.android.ads.AdManager.isTestDevice(p6)) {
	                if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 4)) {
	                    android.util.Log.i("AdMobSDK", "Making ad request in test mode");
	                }
	                com.admob.android.ads.b.a(v0_4, "m", "test");
	                String v7_8 = com.admob.android.ads.AdManager.getTestAction();
	                if ((p10 == com.admob.android.ads.j$b.b) && (com.admob.android.ads.j$a.a.toString().equals(v7_8))) {
	                    v7_8 = "video_int";
	                }
	                com.admob.android.ads.b.a(v0_4, "test_action", v7_8);
	            }
	            if (com.admob.android.ads.b.d == null) {
	                String v7_11 = new StringBuilder();
	                String v8_11 = p6.getPackageManager();
	                String v9_10 = v8_11.queryIntentActivities(new android.content.Intent("android.intent.action.VIEW", android.net.Uri.parse("geo:0,0?q=donuts")), 65536);
	                if ((v9_10 == null) || (v9_10.size() == 0)) {
	                    v7_11.append("m");
	                }
	                String v9_15 = v8_11.queryIntentActivities(new android.content.Intent("android.intent.action.VIEW", android.net.Uri.parse("market://search?q=pname:com.admob")), 65536);
	                if ((v9_15 == null) || (v9_15.size() == 0)) {
	                    if (v7_11.length() > 0) {
	                        v7_11.append(",");
	                    }
	                    v7_11.append("a");
	                }
	                String v8_12 = v8_11.queryIntentActivities(new android.content.Intent("android.intent.action.VIEW", android.net.Uri.parse("tel://6509313940")), 65536);
	                if ((v8_12 == null) || (v8_12.size() == 0)) {
	                    if (v7_11.length() > 0) {
	                        v7_11.append(",");
	                    }
	                    v7_11.append("t");
	                }
	                com.admob.android.ads.b.d = v7_11.toString();
	            }
	            String v7_13 = com.admob.android.ads.b.d;
	            if ((v7_13 != null) && (v7_13.length() > 0)) {
	                com.admob.android.ads.b.a(v0_4, "ic", v7_13);
	            }
	            com.admob.android.ads.b.a(v0_4, "audio", String.valueOf(com.admob.android.ads.AdManager.a(new com.admob.android.ads.v(p6)).ordinal()));
	            String v7_20 = (com.admob.android.ads.b.b + 1);
	            com.admob.android.ads.b.b = v7_20;
	            if (v7_20 != 1) {
	                com.admob.android.ads.b.a(v0_4, "stats[reqs]", String.valueOf(com.admob.android.ads.b.b));
	                com.admob.android.ads.b.a(v0_4, "stats[time]", String.valueOf(((System.currentTimeMillis() - com.admob.android.ads.b.c) / 1000)));
	            } else {
	                com.admob.android.ads.b.c = System.currentTimeMillis();
	                com.admob.android.ads.b.a(v0_4, "pub_data[identifier]", com.admob.android.ads.AdManager.getApplicationPackageName(p6));
	                com.admob.android.ads.b.a(v0_4, "pub_data[version]", String.valueOf(com.admob.android.ads.AdManager.getApplicationVersion(p6)));
	            }
	            return v0_4.toString();
	        } else {
	            throw new IllegalStateException("Publisher ID is not set!  To serve ads you must set your publisher ID assigned from www.admob.com.  Either add it to AndroidManifest.xml under the <application> tag or call AdManager.setPublisherId().");
	        }
	    }
	
	
	    static void a(String p4)
	    {
	        String v0;
	        if (p4 != null) {
	            v0 = p4;
	        } else {
	            v0 = "http://r.admob.com/ad_source.php";
	        }
	        if ((!"http://r.admob.com/ad_source.php".equals(v0)) && (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 5))) {
	            android.util.Log.w("AdMobSDK", new StringBuilder().append("NOT USING PRODUCTION AD SERVER!  Using ").append(v0).toString());
	        }
	        com.admob.android.ads.b.a = v0;
	        return;
	    }
	
	
	    private static void a(StringBuilder p4, String p5, String p6)
	    {
	        if ((p6 != null) && (p6.length() > 0)) {
	            try {
	                p4.append("&").append(java.net.URLEncoder.encode(p5, "UTF-8")).append("=").append(java.net.URLEncoder.encode(p6, "UTF-8"));
	            } catch (String v0_8) {
	                if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                    android.util.Log.e("AdMobSDK", "UTF-8 encoding is not supported on this device.  Ad requests are impossible.", v0_8);
	                }
	            }
	            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                android.util.Log.d("AdMobSDK", new StringBuilder().append("    ").append(p5).append(": ").append(p6).toString());
	            }
	        }
	        return;
	    }
	
