	
	    q$1()
	    {
	        return;
	    }
	
	
	    public final void a(com.admob.android.ads.e p4)
	    {
	        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	            android.util.Log.d("AdMobSDK", new StringBuilder().append("Click processed at ").append(p4.c()).toString());
	        }
	        return;
	    }
	
	
	    public final void a(com.admob.android.ads.e p4, Exception p5)
	    {
	        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	            android.util.Log.d("AdMobSDK", new StringBuilder().append("Click processing failed at ").append(p4.c()).toString(), p5);
	        }
	        return;
	    }
	
