	public static final enum com.admob.android.ads.j$a a
	public static final enum com.admob.android.ads.j$a b
	public static final enum com.admob.android.ads.j$a c
	public static final enum com.admob.android.ads.j$a d
	private static enum com.admob.android.ads.j$a e
	private static enum com.admob.android.ads.j$a f
	private static enum com.admob.android.ads.j$a g
	private static enum com.admob.android.ads.j$a h
	private static enum com.admob.android.ads.j$a i
	private static enum com.admob.android.ads.j$a j
	private static final synthetic Lcom.admob.android.ads.j$a l
	private java.lang.String k
	
	    static j$a()
	    {
	        com.admob.android.ads.j$a.e = new com.admob.android.ads.j$a("CLICK_TO_MAP", 0, "map");
	        com.admob.android.ads.j$a.f = new com.admob.android.ads.j$a("CLICK_TO_VIDEO", 1, "video");
	        com.admob.android.ads.j$a.g = new com.admob.android.ads.j$a("CLICK_TO_APP", 2, "app");
	        com.admob.android.ads.j$a.a = new com.admob.android.ads.j$a("CLICK_TO_BROWSER", 3, "url");
	        com.admob.android.ads.j$a.h = new com.admob.android.ads.j$a("CLICK_TO_CALL", 4, "call");
	        com.admob.android.ads.j$a.i = new com.admob.android.ads.j$a("CLICK_TO_MUSIC", 5, "itunes");
	        com.admob.android.ads.j$a.b = new com.admob.android.ads.j$a("CLICK_TO_CANVAS", 6, "canvas");
	        com.admob.android.ads.j$a.j = new com.admob.android.ads.j$a("CLICK_TO_CONTACT", 7, "contact");
	        com.admob.android.ads.j$a.c = new com.admob.android.ads.j$a("CLICK_TO_INTERACTIVE_VIDEO", 8, "movie");
	        com.admob.android.ads.j$a.d = new com.admob.android.ads.j$a("CLICK_TO_FULLSCREEN_BROWSER", 9, "screen");
	        com.admob.android.ads.j$a[] v0_21 = new com.admob.android.ads.j$a[10];
	        v0_21[0] = com.admob.android.ads.j$a.e;
	        v0_21[1] = com.admob.android.ads.j$a.f;
	        v0_21[2] = com.admob.android.ads.j$a.g;
	        v0_21[3] = com.admob.android.ads.j$a.a;
	        v0_21[4] = com.admob.android.ads.j$a.h;
	        v0_21[5] = com.admob.android.ads.j$a.i;
	        v0_21[6] = com.admob.android.ads.j$a.b;
	        v0_21[7] = com.admob.android.ads.j$a.j;
	        v0_21[8] = com.admob.android.ads.j$a.c;
	        v0_21[9] = com.admob.android.ads.j$a.d;
	        com.admob.android.ads.j$a.l = v0_21;
	        return;
	    }
	
	
	    private j$a(String p1, int p2, String p3)
	    {
	        this(p1, p2);
	        this.k = p3;
	        return;
	    }
	
	
	    public static com.admob.android.ads.j$a a(String p6)
	    {
	        com.admob.android.ads.j$a v0 = 0;
	        com.admob.android.ads.j$a[] v1 = com.admob.android.ads.j$a.values();
	        int v3 = 0;
	        while (v3 < v1.length) {
	            com.admob.android.ads.j$a v4 = v1[v3];
	            if (!v4.toString().equals(p6)) {
	                v3++;
	            } else {
	                v0 = v4;
	                break;
	            }
	        }
	        return v0;
	    }
	
	
	    public static com.admob.android.ads.j$a valueOf(String p1)
	    {
	        return ((com.admob.android.ads.j$a) Enum.valueOf(com.admob.android.ads.j$a, p1));
	    }
	
	
	    public static com.admob.android.ads.j$a[] values()
	    {
	        return ((com.admob.android.ads.j$a[]) com.admob.android.ads.j$a.l.clone());
	    }
	
	
	    public final String toString()
	    {
	        return this.k;
	    }
	
