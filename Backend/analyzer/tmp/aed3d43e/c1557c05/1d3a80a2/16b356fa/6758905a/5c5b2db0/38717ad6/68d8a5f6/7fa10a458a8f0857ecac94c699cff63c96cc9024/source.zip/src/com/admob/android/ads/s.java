	private static com.admob.android.ads.s a
	private java.io.File b
	private  c
	private  d
	private java.util.PriorityQueue e
	private java.util.Hashtable f
	
	    static s()
	    {
	        com.admob.android.ads.s.a = 0;
	        return;
	    }
	
	
	    private s(android.content.Context p4, long p5)
	    {
	        this.d = 524288;
	        this.c = 0;
	        this.e = 0;
	        this.f = 0;
	        java.io.File v1_1 = new java.io.File(p4.getCacheDir(), "admob_img_cache");
	        if (v1_1.exists()) {
	            if (!v1_1.isDirectory()) {
	                v1_1.delete();
	                v1_1.mkdir();
	            }
	        } else {
	            v1_1.mkdir();
	        }
	        this.b = v1_1;
	        this.a(this.b);
	        return;
	    }
	
	
	    public static com.admob.android.ads.s a(android.content.Context p3)
	    {
	        if (com.admob.android.ads.s.a == null) {
	            com.admob.android.ads.s.a = new com.admob.android.ads.s(p3, 524288);
	        }
	        return com.admob.android.ads.s.a;
	    }
	
	
	    public static void a()
	    {
	        new com.admob.android.ads.s$a(com.admob.android.ads.s.a).start();
	        return;
	    }
	
	
	    static synthetic void a(com.admob.android.ads.s p0)
	    {
	        p0.b();
	        return;
	    }
	
	
	    private void a(java.io.File p9)
	    {
	        java.io.File[] v0 = p9.listFiles();
	        this.e = new java.util.PriorityQueue(20, new com.admob.android.ads.s$b());
	        this.f = new java.util.Hashtable();
	        int v1_4 = v0.length;
	        int v2_1 = 0;
	        while (v2_1 < v1_4) {
	            long v3_2 = v0[v2_1];
	            if ((v3_2 != 0) && (v3_2.canRead())) {
	                this.e.add(v3_2);
	                this.f.put(v3_2.getName(), v3_2);
	                this.c = (this.c + v3_2.length());
	            }
	            v2_1++;
	        }
	        return;
	    }
	
	
	    private declared_synchronized void b()
	    {
	        try {
	            while ((this.c > this.d) && (this.e.size() > 0)) {
	                java.io.File v0_6 = ((java.io.File) this.e.peek());
	                if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 2)) {
	                    android.util.Log.v("AdMobSDK", new StringBuilder().append("cache: evicting bitmap ").append(v0_6.getName()).append(" totalBytes ").append(this.c).toString());
	                }
	                this.b(v0_6);
	                v0_6.delete();
	            }
	        } catch (java.io.File v0_7) {
	            throw v0_7;
	        }
	        return;
	    }
	
	
	    private declared_synchronized void b(java.io.File p5)
	    {
	        if (p5 != null) {
	            try {
	                String v1_2;
	                String v0_1 = this.e.remove(p5);
	            } catch (String v0_8) {
	                throw v0_8;
	            }
	            if (this.f.remove(p5.getName()) == null) {
	                v1_2 = 0;
	            } else {
	                v1_2 = 1;
	            }
	            if ((v0_1 & v1_2) != 0) {
	                this.c = (this.c - p5.length());
	                if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 2)) {
	                    android.util.Log.v("AdMobSDK", new StringBuilder().append("Cache: removed file ").append(p5.getName()).append(" totalBytes ").append(this.c).toString());
	                }
	            }
	        }
	        return;
	    }
	
	
	    private declared_synchronized void c(java.io.File p5)
	    {
	        if (p5 != null) {
	            try {
	                if ((this.e.contains(p5)) || (this.f.get(p5.getName()) != null)) {
	                    if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 2)) {
	                        android.util.Log.v("AdMobSDK", "Cache: trying to add a file that\'s already in index");
	                    }
	                    this.b(p5);
	                }
	            } catch (String v0_14) {
	                throw v0_14;
	            }
	            this.e.add(p5);
	            this.f.put(p5.getName(), p5);
	            this.c = (this.c + p5.length());
	            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 2)) {
	                android.util.Log.v("AdMobSDK", new StringBuilder().append("cache: added file: ").append(p5.getName()).append(" totalBytes ").append(this.c).toString());
	            }
	        }
	        return;
	    }
	
	
	    public final declared_synchronized android.graphics.Bitmap a(String p7)
	    {
	        try {
	            android.graphics.Bitmap v0_3;
	            android.graphics.Bitmap v0_2 = ((java.io.File) this.f.get(p7));
	        } catch (android.graphics.Bitmap v0_6) {
	            throw v0_6;
	        }
	        if (v0_2 == null) {
	            v0_3 = 0;
	        } else {
	            android.graphics.Bitmap v1_1 = android.graphics.BitmapFactory.decodeFile(v0_2.getAbsolutePath());
	            if (v1_1 == null) {
	            } else {
	                this.e.remove(v0_2);
	                v0_2.setLastModified(System.currentTimeMillis());
	                this.e.add(v0_2);
	                if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 2)) {
	                    android.util.Log.v("AdMobSDK", new StringBuilder().append("cache: found bitmap ").append(v0_2.getName()).append(" totalBytes ").append(this.c).append(" new modified ").append(v0_2.lastModified()).toString());
	                }
	                v0_3 = v1_1;
	            }
	        }
	        return v0_3;
	    }
	
	
	    public final declared_synchronized void a(String p6, android.graphics.Bitmap p7)
	    {
	        try {
	            String v1_1 = new java.io.File(this.b, p6);
	            String v0_3 = ((java.io.File) this.f.get(p6));
	        } catch (String v0_10) {
	            throw v0_10;
	        }
	        if (v0_3 != null) {
	            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 2)) {
	                android.util.Log.v("AdMobSDK", new StringBuilder().append("cache: found bitmap ").append(v1_1.getName()).append(" and removing ").toString());
	            }
	            this.b(v0_3);
	        }
	        if (v1_1.exists()) {
	            v1_1.delete();
	        }
	        try {
	            p7.compress(android.graphics.Bitmap$CompressFormat.PNG, 100, new java.io.FileOutputStream(v1_1));
	            this.c(v1_1);
	        } catch (String v0) {
	            return;
	        }
	        if (!com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 2)) {
	            return;
	        } else {
	            android.util.Log.v("AdMobSDK", new StringBuilder().append("cache: added bitmap ").append(v1_1.getName()).append(" totalBytes ").append(this.c).append(" lastModified ").append(v1_1.lastModified()).toString());
	            return;
	        }
	    }
	
