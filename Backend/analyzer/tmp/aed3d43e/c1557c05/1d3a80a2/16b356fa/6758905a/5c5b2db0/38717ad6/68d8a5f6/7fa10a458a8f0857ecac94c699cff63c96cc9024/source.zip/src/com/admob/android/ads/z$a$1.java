	private synthetic com.admob.android.ads.z$a a
	
	    z$a$1(com.admob.android.ads.z$a p1)
	    {
	        this.a = p1;
	        return;
	    }
	
	
	    public final void run()
	    {
	        if (!this.a.a) {
	            this.a.a = 1;
	            if (this.a.c != null) {
	                this.a.c.a(0);
	            }
	        }
	        return;
	    }
	
