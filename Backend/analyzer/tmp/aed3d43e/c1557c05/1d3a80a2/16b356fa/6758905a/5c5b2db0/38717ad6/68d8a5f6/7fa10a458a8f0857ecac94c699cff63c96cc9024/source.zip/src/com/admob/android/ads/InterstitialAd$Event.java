	public static final enum com.admob.android.ads.InterstitialAd$Event APP_START
	public static final enum com.admob.android.ads.InterstitialAd$Event OTHER
	public static final enum com.admob.android.ads.InterstitialAd$Event POST_ROLL
	public static final enum com.admob.android.ads.InterstitialAd$Event PRE_ROLL
	public static final enum com.admob.android.ads.InterstitialAd$Event SCREEN_CHANGE
	private static final synthetic Lcom.admob.android.ads.InterstitialAd$Event a
	
	    static InterstitialAd$Event()
	    {
	        com.admob.android.ads.InterstitialAd$Event.APP_START = new com.admob.android.ads.InterstitialAd$Event("APP_START", 0);
	        com.admob.android.ads.InterstitialAd$Event.SCREEN_CHANGE = new com.admob.android.ads.InterstitialAd$Event("SCREEN_CHANGE", 1);
	        com.admob.android.ads.InterstitialAd$Event.PRE_ROLL = new com.admob.android.ads.InterstitialAd$Event("PRE_ROLL", 2);
	        com.admob.android.ads.InterstitialAd$Event.POST_ROLL = new com.admob.android.ads.InterstitialAd$Event("POST_ROLL", 3);
	        com.admob.android.ads.InterstitialAd$Event.OTHER = new com.admob.android.ads.InterstitialAd$Event("OTHER", 4);
	        com.admob.android.ads.InterstitialAd$Event[] v0_11 = new com.admob.android.ads.InterstitialAd$Event[5];
	        v0_11[0] = com.admob.android.ads.InterstitialAd$Event.APP_START;
	        v0_11[1] = com.admob.android.ads.InterstitialAd$Event.SCREEN_CHANGE;
	        v0_11[2] = com.admob.android.ads.InterstitialAd$Event.PRE_ROLL;
	        v0_11[3] = com.admob.android.ads.InterstitialAd$Event.POST_ROLL;
	        v0_11[4] = com.admob.android.ads.InterstitialAd$Event.OTHER;
	        com.admob.android.ads.InterstitialAd$Event.a = v0_11;
	        return;
	    }
	
	
	    private InterstitialAd$Event(String p1, int p2)
	    {
	        this(p1, p2);
	        return;
	    }
	
	
	    public static com.admob.android.ads.InterstitialAd$Event valueOf(String p1)
	    {
	        return ((com.admob.android.ads.InterstitialAd$Event) Enum.valueOf(com.admob.android.ads.InterstitialAd$Event, p1));
	    }
	
	
	    public static com.admob.android.ads.InterstitialAd$Event[] values()
	    {
	        return ((com.admob.android.ads.InterstitialAd$Event[]) com.admob.android.ads.InterstitialAd$Event.a.clone());
	    }
	
