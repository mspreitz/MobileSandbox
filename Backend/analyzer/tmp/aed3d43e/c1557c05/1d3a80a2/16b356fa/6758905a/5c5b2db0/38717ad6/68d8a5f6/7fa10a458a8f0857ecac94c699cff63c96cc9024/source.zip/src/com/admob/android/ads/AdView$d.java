	  a
	private java.lang.ref.WeakReference b
	
	    public AdView$d(com.admob.android.ads.AdView p2)
	    {
	        this.b = new ref.WeakReference(p2);
	        return;
	    }
	
	
	    public final void run()
	    {
	        try {
	            String v0_2 = ((com.admob.android.ads.AdView) this.b.get());
	        } catch (String v0_3) {
	            if (!com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                return;
	            } else {
	                android.util.Log.e("AdMobSDK", new StringBuilder().append("exception caught in RefreshHandler.run(), ").append(v0_3.getMessage()).toString());
	                return;
	            }
	        }
	        if ((this.a) || (v0_2 == null)) {
	            return;
	        } else {
	            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                String v1_4 = (com.admob.android.ads.AdView.h(v0_2) / 1000);
	                if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                    android.util.Log.d("AdMobSDK", new StringBuilder().append("Requesting a fresh ad because a request interval passed (").append(v1_4).append(" seconds).").toString());
	                }
	            }
	            com.admob.android.ads.AdView.i(v0_2);
	            return;
	        }
	    }
	
