	final synthetic synteo.spysat.Application this$0
	
	    Application$5(synteo.spysat.Application p1)
	    {
	        this.this$0 = p1;
	        return;
	    }
	
	
	    public void onClick(android.content.DialogInterface p2, int p3)
	    {
	        synteo.spysat.Application.access$6(this.this$0);
	        return;
	    }
	
