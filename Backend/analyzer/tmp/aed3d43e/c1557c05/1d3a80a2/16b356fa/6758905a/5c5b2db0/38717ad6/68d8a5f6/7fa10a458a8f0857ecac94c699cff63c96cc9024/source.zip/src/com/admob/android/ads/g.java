	private static  a
	
	    static g()
	    {
	        com.admob.android.ads.g.a = 0;
	        return;
	    }
	
	
	    public g()
	    {
	        return;
	    }
	
	
	    public static com.admob.android.ads.e a(String p1, String p2, String p3)
	    {
	        return com.admob.android.ads.g.a(p1, p2, p3, 0);
	    }
	
	
	    public static com.admob.android.ads.e a(String p7, String p8, String p9, com.admob.android.ads.h p10)
	    {
	        return com.admob.android.ads.g.a(p7, p8, p9, p10, 5000, 0, 0);
	    }
	
	
	    public static com.admob.android.ads.e a(String p7, String p8, String p9, com.admob.android.ads.h p10, int p11)
	    {
	        com.admob.android.ads.e v0_1 = com.admob.android.ads.g.a(p7, 0, p9, p10, 5000, 0, 0);
	        if (v0_1 != null) {
	            v0_1.a(1);
	        }
	        return v0_1;
	    }
	
	
	    public static com.admob.android.ads.e a(String p8, String p9, String p10, com.admob.android.ads.h p11, int p12, java.util.Map p13, String p14)
	    {
	        return new com.admob.android.ads.i(p8, p9, p10, p11, p12, 0, p14);
	    }
	
	
	    public static com.admob.android.ads.e a(String p7, String p8, String p9, org.json.JSONObject p10, com.admob.android.ads.h p11)
	    {
	        String v6;
	        if (p10 != null) {
	            v6 = p10.toString();
	        } else {
	            v6 = 0;
	        }
	        com.admob.android.ads.e v0_2 = com.admob.android.ads.g.a(p7, p8, p9, p11, 5000, 0, v6);
	        v0_2.a("application/json");
	        return v0_2;
	    }
	
