	
	    public ak(float p1, float p2)
	    {
	        this(p1, p2);
	        return;
	    }
	
	
	    protected final void applyTransformation(float p5, android.view.animation.Transformation p6)
	    {
	        if ((((double) p5) >= 0) || (((double) p5) <= 1.0)) {
	            super.applyTransformation(p5, p6);
	        }
	        return;
	    }
	
