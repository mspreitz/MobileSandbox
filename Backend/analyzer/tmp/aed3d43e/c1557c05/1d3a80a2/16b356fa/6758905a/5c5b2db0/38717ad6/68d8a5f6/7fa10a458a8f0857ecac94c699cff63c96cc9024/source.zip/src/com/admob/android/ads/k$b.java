	private org.json.JSONObject a
	private java.lang.ref.WeakReference b
	
	    public k$b(org.json.JSONObject p2, com.admob.android.ads.k p3)
	    {
	        this.a = p2;
	        this.b = new ref.WeakReference(p3);
	        return;
	    }
	
	
	    public final void run()
	    {
	        try {
	            com.admob.android.ads.AdView v0_2 = ((com.admob.android.ads.k) this.b.get());
	        } catch (com.admob.android.ads.AdView v0_4) {
	            if (!com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                return;
	            } else {
	                android.util.Log.e("AdMobSDK", "exception caught in AdClickThread.run(), ", v0_4);
	                return;
	            }
	        }
	        if ((v0_2 == null) || (v0_2.a == null)) {
	            return;
	        } else {
	            v0_2.a.a(this.a);
	            if (v0_2.b == null) {
	                return;
	            } else {
	                v0_2.b.performClick();
	                return;
	            }
	        }
	    }
	
