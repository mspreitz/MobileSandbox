	private java.lang.ref.WeakReference a
	
	    public k$a(com.admob.android.ads.k p2)
	    {
	        this.a = new ref.WeakReference(p2);
	        return;
	    }
	
	
	    public final void run()
	    {
	        try {
	            com.admob.android.ads.k v4_2 = ((com.admob.android.ads.k) this.a.get());
	        } catch (String v0_2) {
	            if (!com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                return;
	            } else {
	                android.util.Log.e("AdMobSDK", new StringBuilder().append("exception caught in AdContainer post run(), ").append(v0_2.getMessage()).toString());
	                return;
	            }
	        }
	        if (v4_2 == null) {
	            return;
	        } else {
	            v4_2.addView(v4_2.c);
	            return;
	        }
	    }
	
