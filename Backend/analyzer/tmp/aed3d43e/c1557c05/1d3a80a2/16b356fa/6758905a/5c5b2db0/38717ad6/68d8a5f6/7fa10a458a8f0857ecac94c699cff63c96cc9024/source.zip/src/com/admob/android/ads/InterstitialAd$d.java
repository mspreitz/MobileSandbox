	private java.lang.ref.WeakReference a
	private java.lang.ref.WeakReference b
	
	    public InterstitialAd$d(android.app.Activity p2, com.admob.android.ads.InterstitialAd p3)
	    {
	        this.a = new ref.WeakReference(p2);
	        this.b = new ref.WeakReference(p3);
	        return;
	    }
	
	
	    public final void run()
	    {
	        android.app.Activity v0_2 = ((android.app.Activity) this.a.get());
	        com.admob.android.ads.InterstitialAd v2_2 = ((com.admob.android.ads.InterstitialAd) this.b.get());
	        if ((v0_2 != null) && (v2_2 != null)) {
	            v2_2.a(v0_2);
	        }
	        return;
	    }
	
