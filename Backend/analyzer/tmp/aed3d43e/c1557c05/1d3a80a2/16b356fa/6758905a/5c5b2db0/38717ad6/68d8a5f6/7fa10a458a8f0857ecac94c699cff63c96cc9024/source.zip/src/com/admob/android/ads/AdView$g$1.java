	private synthetic com.admob.android.ads.k a
	private synthetic com.admob.android.ads.AdView b
	private synthetic com.admob.android.ads.k c
	
	    AdView$g$1(com.admob.android.ads.AdView$g p1, com.admob.android.ads.k p2, com.admob.android.ads.AdView p3, com.admob.android.ads.k p4)
	    {
	        this.a = p2;
	        this.b = p3;
	        this.c = p4;
	        return;
	    }
	
	
	    public final void onAnimationEnd(android.view.animation.Animation p3)
	    {
	        if (this.a != null) {
	            this.b.removeView(this.a);
	        }
	        com.admob.android.ads.AdView.c(this.b, this.c);
	        if (this.a != null) {
	            this.a.e();
	        }
	        return;
	    }
	
	
	    public final void onAnimationRepeat(android.view.animation.Animation p1)
	    {
	        return;
	    }
	
	
	    public final void onAnimationStart(android.view.animation.Animation p1)
	    {
	        return;
	    }
	
