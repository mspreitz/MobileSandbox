	private static  a
	
	    static c()
	    {
	        com.admob.android.ads.c.a = 0;
	        return;
	    }
	
	
	    c()
	    {
	        return;
	    }
	
	
	    public static void a(android.content.Context p4)
	    {
	        if (!com.admob.android.ads.c.a) {
	            com.admob.android.ads.c.a = 1;
	            if (com.admob.android.ads.AdManager.isEmulator()) {
	                try {
	                    String v0_4 = com.admob.android.ads.b.a(p4, 0, 0, 0);
	                    String v1_2 = new StringBuilder();
	                    v1_2.append("http://api.admob.com/v1/pubcode/android_sdk_emulator_notice");
	                    v1_2.append("?");
	                    v1_2.append(v0_4);
	                    String v0_6 = com.admob.android.ads.g.a(v1_2.toString(), "developer_message", com.admob.android.ads.AdManager.getUserId(p4));
	                } catch (String v0_11) {
	                    if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 2)) {
	                        android.util.Log.v("AdMobSDK", "Unhandled exception retrieving developer message.", v0_11);
	                    }
	                }
	                if (v0_6.d()) {
	                    String v0_7 = v0_6.a();
	                    if (v0_7 != null) {
	                        String v0_10 = new org.json.JSONObject(new org.json.JSONTokener(new String(v0_7))).getString("data");
	                        if ((v0_10 != null) && (!v0_10.equals(""))) {
	                            android.util.Log.w("AdMobSDK", v0_10);
	                        }
	                    }
	                }
	            }
	        }
	        return;
	    }
	
