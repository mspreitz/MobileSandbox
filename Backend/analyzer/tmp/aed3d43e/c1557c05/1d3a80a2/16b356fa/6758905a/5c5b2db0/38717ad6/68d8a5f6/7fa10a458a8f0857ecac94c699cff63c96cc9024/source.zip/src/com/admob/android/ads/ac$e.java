	private java.lang.ref.WeakReference a
	private java.lang.ref.WeakReference b
	private java.lang.ref.WeakReference c
	
	    public ac$e(com.admob.android.ads.ac p2, com.admob.android.ads.o p3, ref.WeakReference p4)
	    {
	        this.a = new ref.WeakReference(p2);
	        this.b = new ref.WeakReference(p3);
	        this.c = p4;
	        return;
	    }
	
	
	    public final void onClick(android.view.View p8)
	    {
	        com.admob.android.ads.ac v0_2 = ((com.admob.android.ads.ac) this.a.get());
	        if (v0_2 != null) {
	            com.admob.android.ads.ac.a(v0_2, 0);
	            ref.WeakReference v1_3 = ((com.admob.android.ads.o) this.b.get());
	            if (v1_3 != null) {
	                com.admob.android.ads.q v3_1;
	                String v2_0 = v0_2.getContext();
	                if (v0_2.j) {
	                    v3_1 = 0;
	                } else {
	                    v0_2.j = 1;
	                    v3_1 = new java.util.HashMap();
	                    v3_1.put("event", "interaction");
	                }
	                v0_2.f.a(v1_3.e, v3_1);
	                com.admob.android.ads.q v3_4 = v0_2.e();
	                if (v3_4 != null) {
	                    v0_2.f();
	                }
	                v0_2.a(v3_4);
	                com.admob.android.ads.q v3_6 = new com.admob.android.ads.q();
	                try {
	                    v3_6.a(v2_0, new org.json.JSONObject(v1_3.f), 0);
	                } catch (ref.WeakReference v1_6) {
	                    if (!com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                    } else {
	                        android.util.Log.e("AdMobSDK", "Could not create JSONObject from button click", v1_6);
	                    }
	                }
	                v3_6.b();
	                if (this.c != null) {
	                    android.app.Activity v7_2 = ((android.app.Activity) this.c.get());
	                    if (v7_2 != null) {
	                        v3_6.a(v7_2, v0_2);
	                    }
	                }
	            }
	        }
	        return;
	    }
	
