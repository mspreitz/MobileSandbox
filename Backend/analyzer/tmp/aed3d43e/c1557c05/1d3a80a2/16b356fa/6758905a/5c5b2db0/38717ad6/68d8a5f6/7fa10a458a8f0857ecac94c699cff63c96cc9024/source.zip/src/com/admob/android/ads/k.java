	private static  i
	private static com.admob.android.ads.k$d j
	protected com.admob.android.ads.j a
	final com.admob.android.ads.AdView b
	protected android.widget.ProgressBar c
	private java.util.Vector d
	private android.view.View e
	private  f
	private  g
	private android.view.View h
	
	    static k()
	    {
	        com.admob.android.ads.k.i = -1082130432;
	        com.admob.android.ads.k.j = 0;
	        return;
	    }
	
	
	    public k(com.admob.android.ads.j p4, android.content.Context p5, com.admob.android.ads.AdView p6)
	    {
	        this(p5);
	        this.f = -1;
	        this.b = p6;
	        this.setId(1);
	        com.admob.android.ads.k.b(p5);
	        this.e = 0;
	        this.a(0);
	        return;
	    }
	
	
	    public static float a(android.content.Context p1)
	    {
	        com.admob.android.ads.k.b(p1);
	        return com.admob.android.ads.k.i;
	    }
	
	
	    private static java.util.Vector a(int p9, int p10, int p11, long p12, java.util.Vector p14)
	    {
	        java.util.Vector v0_0;
	        if (p14 != null) {
	            v0_0 = p14;
	        } else {
	            v0_0 = new java.util.Vector();
	        }
	        String v1_3;
	        String v1_1 = (((float) p12) / 1148846080);
	        if ((p10 == -1) || (p11 == -1)) {
	            String v3_1 = new Object[2];
	            v3_1[0] = Integer.valueOf(p9);
	            v3_1[1] = Float.valueOf(v1_1);
	            v1_3 = String.format("{%d,%f}", v3_1);
	        } else {
	            String v3_3 = new Object[4];
	            v3_3[0] = Integer.valueOf(p9);
	            v3_3[1] = Integer.valueOf(p10);
	            v3_3[2] = Integer.valueOf(p11);
	            v3_3[3] = Float.valueOf(v1_1);
	            v1_3 = String.format("{%d,%d,%d,%f}", v3_3);
	        }
	        v0_0.add(v1_3);
	        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 2)) {
	            android.util.Log.v("AdMobSDK", new StringBuilder().append("recordEvent:").append(v1_3).toString());
	        }
	        return v0_0;
	    }
	
	
	    private java.util.Vector a(android.view.KeyEvent p8, java.util.Vector p9)
	    {
	        java.util.Vector v0_1;
	        java.util.Vector v0_0 = p8.getAction();
	        long v3 = (p8.getEventTime() - this.f);
	        if ((v0_0 != null) && (v0_0 != 1)) {
	            v0_1 = p9;
	        } else {
	            java.util.Vector v0_2;
	            if (v0_0 != 1) {
	                v0_2 = 0;
	            } else {
	                v0_2 = 1;
	            }
	            v0_1 = com.admob.android.ads.k.a(v0_2, -1, -1, v3, p9);
	        }
	        return v0_1;
	    }
	
	
	    private java.util.Vector a(android.view.MotionEvent p7, boolean p8, java.util.Vector p9)
	    {
	        java.util.Vector v0_1;
	        java.util.Vector v0_0 = p7.getAction();
	        long v3_1 = (p7.getEventTime() - this.f);
	        if ((v0_0 != null) && (v0_0 != 1)) {
	            v0_1 = p9;
	        } else {
	            java.util.Vector v0_2;
	            if (v0_0 != 1) {
	                v0_2 = 0;
	            } else {
	                v0_2 = 1;
	            }
	            v0_1 = com.admob.android.ads.k.a(v0_2, ((int) p7.getX()), ((int) p7.getY()), v3_1, p9);
	        }
	        return v0_1;
	    }
	
	
	    private static void a(android.view.View p3, org.json.JSONObject p4)
	    {
	        if ((p3 instanceof com.admob.android.ads.l)) {
	            android.view.View v2_0 = ((com.admob.android.ads.l) p3).j();
	            int v1_2 = ((com.admob.android.ads.l) p3).i();
	            if ((v2_0 != null) && (v1_2 != 0)) {
	                try {
	                    p4.put(v1_2, v2_0);
	                } catch (int v1) {
	                }
	            }
	        }
	        if ((p3 instanceof android.view.ViewGroup)) {
	            int v1_4 = 0;
	            while (v1_4 < ((android.view.ViewGroup) p3).getChildCount()) {
	                com.admob.android.ads.k.a(((android.view.ViewGroup) p3).getChildAt(v1_4), p4);
	                v1_4++;
	            }
	        }
	        return;
	    }
	
	
	    private static void b(android.content.Context p2)
	    {
	        if (com.admob.android.ads.k.i < 0) {
	            com.admob.android.ads.k.i = p2.getResources().getDisplayMetrics().density;
	        }
	        return;
	    }
	
	
	    public static float d()
	    {
	        return com.admob.android.ads.k.i;
	    }
	
	
	    private boolean k()
	    {
	        if ((this.a != null) && (this.a.m())) {
	            int v0_3 = 0;
	        } else {
	            v0_3 = 1;
	        }
	        return v0_3;
	    }
	
	
	    private boolean l()
	    {
	        if ((this.a == null) || ((android.os.SystemClock.uptimeMillis() - this.f) <= this.a.d())) {
	            int v0_4 = 0;
	        } else {
	            v0_4 = 1;
	        }
	        return v0_4;
	    }
	
	
	    private void m()
	    {
	        if ((this.a != null) && (this.isPressed())) {
	            this.setPressed(0);
	            if (!this.g) {
	                com.admob.android.ads.AdView v0_6;
	                this.g = 1;
	                org.json.JSONObject v7 = this.n();
	                if (this.h == null) {
	                    v0_6 = 0;
	                } else {
	                    v0_6 = 1;
	                }
	                if (v0_6 == null) {
	                    this.a.a(v7);
	                    if (this.b != null) {
	                        this.b.performClick();
	                    }
	                } else {
	                    android.view.animation.AnimationSet v8_1 = new android.view.animation.AnimationSet(1);
	                    float v5 = (((float) this.h.getWidth()) / 1073741824);
	                    float v6 = (((float) this.h.getHeight()) / 1073741824);
	                    com.admob.android.ads.AdView v0_18 = new android.view.animation.ScaleAnimation(1065353216, 1067030938, 1065353216, 1067030938, v5, v6);
	                    v0_18.setDuration(200);
	                    v8_1.addAnimation(v0_18);
	                    com.admob.android.ads.AdView v0_20 = new android.view.animation.ScaleAnimation(1067030938, 981668463, 1067030938, 981668463, v5, v6);
	                    v0_20.setDuration(299);
	                    v0_20.setStartOffset(200);
	                    v0_20.setAnimationListener(this);
	                    v8_1.addAnimation(v0_20);
	                    this.postDelayed(new com.admob.android.ads.k$b(v7, this), 500);
	                    this.h.startAnimation(v8_1);
	                }
	            }
	        }
	        return;
	    }
	
	
	    private org.json.JSONObject n()
	    {
	        try {
	            String v1_1 = new org.json.JSONObject();
	            com.admob.android.ads.k.a(this, v1_1);
	            String v2_1 = new org.json.JSONObject();
	        } catch (String v1_2) {
	            String v1_3 = 0;
	            Exception v0_1 = v1_2;
	            android.util.Log.w("AdMobSDK", "Exception while processing interaction history.", v0_1);
	            Exception v0_3 = v1_3;
	            return v0_3;
	        }
	        try {
	            v2_1.put("interactions", v1_1);
	            v0_3 = v2_1;
	        } catch (Exception v0_1) {
	            v1_3 = v2_1;
	        }
	        return v0_3;
	    }
	
	
	    public final void a()
	    {
	        this.post(new com.admob.android.ads.k$c(this));
	        return;
	    }
	
	
	    public final void a(android.view.View p3, android.widget.RelativeLayout$LayoutParams p4)
	    {
	        if ((p3 != null) && (p3 != this.h)) {
	            this.h = p3;
	            this.c = new android.widget.ProgressBar(this.getContext());
	            this.c.setIndeterminate(1);
	            this.c.setId(2);
	            if (p4 != null) {
	                this.c.setLayoutParams(p4);
	            }
	            this.c.setVisibility(4);
	            this.post(new com.admob.android.ads.k$a(this));
	        }
	        return;
	    }
	
	
	    public final void a(com.admob.android.ads.j p3)
	    {
	        this.a = p3;
	        if (p3 != null) {
	            p3.a(this);
	            this.setFocusable(1);
	            this.setClickable(1);
	        } else {
	            this.setFocusable(0);
	            this.setClickable(0);
	        }
	        return;
	    }
	
	
	    public final void b()
	    {
	        android.view.View v0_0 = this.getContext();
	        this.setBackgroundDrawable(v0_0.getResources().getDrawable(17301602));
	        android.widget.RelativeLayout$LayoutParams v1_3 = v0_0.getResources().getDrawable(17301602);
	        v1_3.setAlpha(128);
	        this.e = new android.view.View(v0_0);
	        this.e.setBackgroundDrawable(v1_3);
	        this.e.setVisibility(4);
	        this.addView(this.e, new android.widget.RelativeLayout$LayoutParams(-1, -1));
	        return;
	    }
	
	
	    public final com.admob.android.ads.j c()
	    {
	        return this.a;
	    }
	
	
	    public final boolean dispatchTouchEvent(android.view.MotionEvent p8)
	    {
	        boolean v0_1;
	        if (!this.k()) {
	            v0_1 = super.dispatchTouchEvent(p8);
	        } else {
	            boolean v0_2 = p8.getAction();
	            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 2)) {
	                android.util.Log.v("AdMobSDK", new StringBuilder().append("dispatchTouchEvent: action=").append(v0_2).append(" x=").append(p8.getX()).append(" y=").append(p8.getY()).toString());
	            }
	            if (this.l()) {
	                if ((this.a == null) || (this.a.a(this.a.h()).contains(((int) p8.getX()), ((int) p8.getY())))) {
	                    int v1_16 = 1;
	                } else {
	                    v1_16 = 0;
	                }
	                if (v1_16 != 0) {
	                    this.d = this.a(p8, 1, this.d);
	                }
	                if ((v0_2) && (v0_2 != 2)) {
	                    if (v0_2 != 1) {
	                        if (v0_2 == 3) {
	                            this.setPressed(0);
	                        }
	                    } else {
	                        if ((this.isPressed()) && (v1_16 != 0)) {
	                            this.m();
	                        }
	                        this.setPressed(0);
	                    }
	                } else {
	                    this.setPressed(v1_16);
	                }
	            }
	            v0_1 = 1;
	        }
	        return v0_1;
	    }
	
	
	    public final boolean dispatchTrackballEvent(android.view.MotionEvent p5)
	    {
	        if (this.k()) {
	            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 2)) {
	                android.util.Log.v("AdMobSDK", new StringBuilder().append("dispatchTrackballEvent: action=").append(p5.getAction()).toString());
	            }
	            if (this.l()) {
	                this.d = this.a(p5, 1, this.d);
	                if (p5.getAction() != 0) {
	                    if (p5.getAction() == 1) {
	                        if (this.hasFocus()) {
	                            this.m();
	                        }
	                        this.setPressed(0);
	                    }
	                } else {
	                    this.setPressed(1);
	                }
	            }
	        }
	        return super.onTrackballEvent(p5);
	    }
	
	
	    public final void e()
	    {
	        if (this.a != null) {
	            this.a.i();
	            this.a = 0;
	        }
	        return;
	    }
	
	
	    protected final void f()
	    {
	        this.g = 0;
	        if (this.c != null) {
	            this.c.setVisibility(4);
	        }
	        if (this.h != null) {
	            this.h.setVisibility(0);
	        }
	        return;
	    }
	
	
	    public final void g()
	    {
	        java.util.Vector v1_1 = new java.util.Vector();
	        android.view.View v0_0 = 0;
	        while (v0_0 < this.getChildCount()) {
	            v1_1.add(this.getChildAt(v0_0));
	            v0_0++;
	        }
	        if (com.admob.android.ads.k.j == null) {
	            com.admob.android.ads.k.j = new com.admob.android.ads.k$d();
	        }
	        java.util.Collections.sort(v1_1, com.admob.android.ads.k.j);
	        int v2_2 = (v1_1.size() - 1);
	        while (v2_2 >= 0) {
	            if (this.indexOfChild(((android.view.View) v1_1.elementAt(v2_2))) != v2_2) {
	                this.bringChildToFront(((android.view.View) v1_1.elementAt(v2_2)));
	            }
	            v2_2--;
	        }
	        if (this.e != null) {
	            this.e.bringToFront();
	        }
	        return;
	    }
	
	
	    public final long h()
	    {
	        long v0_1 = (android.os.SystemClock.uptimeMillis() - this.f);
	        if ((this.f < 0) || ((v0_1 < 0) || (v0_1 > 10000000))) {
	            v0_1 = 0;
	        }
	        return v0_1;
	    }
	
	
	    public final String i()
	    {
	        return "container";
	    }
	
	
	    public final org.json.JSONObject j()
	    {
	        org.json.JSONObject v0_0 = 0;
	        if (this.d != null) {
	            v0_0 = new org.json.JSONObject();
	            try {
	                v0_0.put("touches", new org.json.JSONArray(this.d));
	            } catch (Exception v1) {
	            }
	        }
	        return v0_0;
	    }
	
	
	    public final void onAnimationEnd(android.view.animation.Animation p1)
	    {
	        return;
	    }
	
	
	    public final void onAnimationRepeat(android.view.animation.Animation p1)
	    {
	        return;
	    }
	
	
	    public final void onAnimationStart(android.view.animation.Animation p1)
	    {
	        return;
	    }
	
	
	    protected final void onDraw(android.graphics.Canvas p5)
	    {
	        if ((this.isPressed()) || (this.isFocused())) {
	            p5.clipRect(3, 3, (this.getWidth() - 3), (this.getHeight() - 3));
	        }
	        super.onDraw(p5);
	        if (this.f == -1) {
	            this.f = android.os.SystemClock.uptimeMillis();
	            if (this.a != null) {
	                this.a.j();
	            }
	        }
	        return;
	    }
	
	
	    public final boolean onKeyDown(int p4, android.view.KeyEvent p5)
	    {
	        if (this.k()) {
	            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 2)) {
	                android.util.Log.v("AdMobSDK", new StringBuilder().append("onKeyDown: keyCode=").append(p4).toString());
	            }
	            if ((p4 == 66) || (p4 == 23)) {
	                this.d = this.a(p5, this.d);
	                this.setPressed(1);
	            }
	        }
	        return super.onKeyDown(p4, p5);
	    }
	
	
	    public final boolean onKeyUp(int p4, android.view.KeyEvent p5)
	    {
	        if (this.k()) {
	            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 2)) {
	                android.util.Log.v("AdMobSDK", new StringBuilder().append("onKeyUp: keyCode=").append(p4).toString());
	            }
	            if ((this.l()) && ((p4 == 66) || (p4 == 23))) {
	                this.d = this.a(p5, this.d);
	                this.m();
	            }
	            this.setPressed(0);
	        }
	        return super.onKeyUp(p4, p5);
	    }
	
	
	    public final void setPressed(boolean p3)
	    {
	        if (((this.k()) && ((!this.g) || (!p3))) && (this.isPressed() != p3)) {
	            if (this.e != null) {
	                if (!p3) {
	                    this.e.setVisibility(4);
	                } else {
	                    this.e.bringToFront();
	                    this.e.setVisibility(0);
	                }
	            }
	            super.setPressed(p3);
	            this.invalidate();
	        }
	        return;
	    }
	
