	private java.lang.ref.WeakReference a
	private java.lang.ref.WeakReference b
	
	    public AdView$g(com.admob.android.ads.k p2, com.admob.android.ads.AdView p3)
	    {
	        this.b = new ref.WeakReference(p2);
	        this.a = new ref.WeakReference(p3);
	        return;
	    }
	
	
	    public final void run()
	    {
	        try {
	            com.admob.android.ads.AdView v8 = ((com.admob.android.ads.AdView) this.a.get());
	            com.admob.android.ads.k v9 = ((com.admob.android.ads.k) this.b.get());
	        } catch (com.admob.android.ads.an v1_13) {
	            if (!com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                return;
	            } else {
	                android.util.Log.e("AdMobSDK", new StringBuilder().append("exception caught in SwapViews.run(), ").append(v1_13.getMessage()).toString());
	                return;
	            }
	        }
	        if ((v8 == null) || (v9 == null)) {
	            return;
	        } else {
	            com.admob.android.ads.k v10 = com.admob.android.ads.AdView.a(v8);
	            if (v10 != null) {
	                v10.setVisibility(8);
	            }
	            v9.setVisibility(0);
	            com.admob.android.ads.an v1_12 = new com.admob.android.ads.an(1119092736, 0, (((float) v8.getWidth()) / 1073741824), (((float) v8.getHeight()) / 1073741824), (-1093874483 * ((float) v8.getWidth())), 0);
	            v1_12.setDuration(700);
	            v1_12.setFillAfter(1);
	            v1_12.setInterpolator(new android.view.animation.DecelerateInterpolator());
	            v1_12.setAnimationListener(new com.admob.android.ads.AdView$g$1(this, v10, v8, v9));
	            v8.startAnimation(v1_12);
	            return;
	        }
	    }
	
