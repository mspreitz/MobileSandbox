	private final java.lang.String a
	private final java.lang.String b
	private final java.lang.String c
	private java.lang.String d
	private com.admob.android.ads.d$a e
	private java.util.HashSet f
	private  g
	
	    public d(String p2, String p3, String p4, String p5)
	    {
	        this.a = p2;
	        this.b = p3;
	        this.c = p4;
	        this.d = p5;
	        this.e = 0;
	        this.f = new java.util.HashSet();
	        this.g = 0;
	        return;
	    }
	
	
	    private String a(String p7, java.util.Map p8, boolean p9)
	    {
	        String v0_1 = new StringBuilder();
	        try {
	            v0_1.append("rt=1&ex=1");
	            v0_1.append("&a=").append(this.a);
	            v0_1.append("&p=").append(java.net.URLEncoder.encode(p7, "UTF-8"));
	            v0_1.append("&o=").append(this.d);
	            v0_1.append("&v=").append("20101109-ANDROID-3312276cc1406347");
	            java.util.Iterator v1_9 = System.currentTimeMillis();
	            v0_1.append("&z").append("=").append((v1_9 / 1000)).append(".").append((v1_9 % 1000));
	            v0_1.append("&h%5BHTTP_HOST%5D=").append(java.net.URLEncoder.encode(this.c, "UTF-8"));
	            v0_1.append("&h%5BHTTP_REFERER%5D=http%3A%2F%2F").append(this.b);
	        } catch (String v0) {
	            String v0_2 = 0;
	            return v0_2;
	        }
	        if (p9) {
	            v0_1.append("&startvisit=1");
	        }
	        if (p8 != null) {
	            java.util.Iterator v1_16 = p8.keySet();
	            if (v1_16 != null) {
	                java.util.Iterator v1_17 = v1_16.iterator();
	                while (v1_17.hasNext()) {
	                    String v6_2 = ((String) v1_17.next());
	                    v0_1.append("&").append(v6_2).append("=").append(java.net.URLEncoder.encode(((String) p8.get(v6_2))));
	                }
	            }
	        }
	        v0_2 = v0_1.toString();
	        return v0_2;
	    }
	
	
	    private void b(com.admob.android.ads.e p2)
	    {
	        this.f.remove(p2);
	        return;
	    }
	
	
	    public final void a(com.admob.android.ads.e p5)
	    {
	        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 2)) {
	            android.util.Log.v("AdMobSDK", new StringBuilder().append("Analytics event ").append(p5.b()).append(" has been recorded.").toString());
	            String v0_9 = this.f.size();
	            if (v0_9 > null) {
	                android.util.Log.v("AdMobSDK", new StringBuilder().append("Pending Analytics requests: ").append(v0_9).toString());
	            }
	        }
	        this.b(p5);
	        return;
	    }
	
	
	    public final void a(com.admob.android.ads.e p4, Exception p5)
	    {
	        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 5)) {
	            android.util.Log.w("AdMobSDK", new StringBuilder().append("analytics request failed for ").append(p4.b()).toString(), p5);
	        }
	        this.b(p4);
	        return;
	    }
	
	
	    public final void a(String p9, java.util.Map p10)
	    {
	        if ((this.c != null) && (p9 != null)) {
	            String v0_4;
	            this.g = (this.g + 1);
	            if (this.g != 1) {
	                v0_4 = 0;
	            } else {
	                v0_4 = 1;
	            }
	            String v6 = this.a(p9, p10, v0_4);
	            if (v6 == null) {
	                if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                    android.util.Log.e("AdMobSDK", "Could not create analytics URL.  Analytics data not tracked.");
	                }
	            } else {
	                if (this.f != null) {
	                    String v0_10 = com.admob.android.ads.g.a("http://r.admob.com/ad_source.php", "AnalyticsData", this.d, this, 5000, 0, v6);
	                    this.f.add(v0_10);
	                    v0_10.f();
	                }
	                if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                    android.util.Log.d("AdMobSDK", new StringBuilder().append("Analytics event ").append(this.c).append("/").append(p9).append(" data:").append(v6).append(" has been recorded.").toString());
	                }
	            }
	        }
	        return;
	    }
	
