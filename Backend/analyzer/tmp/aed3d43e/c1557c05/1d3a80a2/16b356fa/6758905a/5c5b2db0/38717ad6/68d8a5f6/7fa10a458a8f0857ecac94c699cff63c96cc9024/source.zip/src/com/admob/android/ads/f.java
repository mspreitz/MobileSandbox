	private static java.util.concurrent.Executor m
	private static java.lang.String n
	protected java.lang.String a
	protected  b
	protected java.lang.Exception c
	protected java.util.Map d
	protected  e
	protected  f
	protected java.lang.String g
	protected com.admob.android.ads.h h
	protected java.net.URL i
	protected B j
	protected  k
	protected java.lang.String l
	private java.lang.String o
	private java.lang.Object p
	
	    static f()
	    {
	        com.admob.android.ads.f.m = 0;
	        return;
	    }
	
	
	    protected f(String p3, String p4, com.admob.android.ads.h p5, int p6, java.util.Map p7, String p8)
	    {
	        this.c = 0;
	        this.o = p3;
	        this.g = p4;
	        this.h = p5;
	        this.b = p6;
	        this.d = p7;
	        this.k = 1;
	        this.e = 0;
	        this.f = 3;
	        if (p8 == null) {
	            this.l = 0;
	            this.a = 0;
	        } else {
	            this.l = p8;
	            this.a = "application/x-www-form-urlencoded";
	        }
	        return;
	    }
	
	
	    public static String h()
	    {
	        if (com.admob.android.ads.f.n == null) {
	            String v0_2 = new StringBuffer();
	            String v1_0 = android.os.Build$VERSION.RELEASE;
	            if (v1_0.length() <= 0) {
	                v0_2.append("1.0");
	            } else {
	                v0_2.append(v1_0);
	            }
	            v0_2.append("; ");
	            String v1_2 = java.util.Locale.getDefault();
	            Object[] v2_1 = v1_2.getLanguage();
	            if (v2_1 == null) {
	                v0_2.append("en");
	            } else {
	                v0_2.append(v2_1.toLowerCase());
	                String v1_4 = v1_2.getCountry();
	                if (v1_4 != null) {
	                    v0_2.append("-");
	                    v0_2.append(v1_4.toLowerCase());
	                }
	            }
	            String v1_6 = android.os.Build.MODEL;
	            if (v1_6.length() > 0) {
	                v0_2.append("; ");
	                v0_2.append(v1_6);
	            }
	            String v1_7 = android.os.Build.ID;
	            if (v1_7.length() > 0) {
	                v0_2.append(" Build/");
	                v0_2.append(v1_7);
	            }
	            Object[] v2_8 = new Object[2];
	            v2_8[0] = v0_2;
	            v2_8[1] = "20101109";
	            com.admob.android.ads.f.n = String.format("Mozilla/5.0 (Linux; U; Android %s) AppleWebKit/525.10+ (KHTML, like Gecko) Version/3.0.4 Mobile Safari/523.12.2 (AdMob-ANDROID-%s)", v2_8);
	            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                android.util.Log.d("AdMobSDK", new StringBuilder().append("Phone\'s user-agent is:  ").append(com.admob.android.ads.f.n).toString());
	            }
	        }
	        return com.admob.android.ads.f.n;
	    }
	
	
	    public final void a(int p1)
	    {
	        this.f = p1;
	        return;
	    }
	
	
	    public void a(com.admob.android.ads.h p1)
	    {
	        this.h = p1;
	        return;
	    }
	
	
	    public final void a(Object p1)
	    {
	        this.p = p1;
	        return;
	    }
	
	
	    public final void a(String p1)
	    {
	        this.a = p1;
	        return;
	    }
	
	
	    public final byte[] a()
	    {
	        return this.j;
	    }
	
	
	    public final String b()
	    {
	        return this.o;
	    }
	
	
	    public final java.net.URL c()
	    {
	        return this.i;
	    }
	
	
	    public final void f()
	    {
	        if (com.admob.android.ads.f.m == null) {
	            com.admob.android.ads.f.m = java.util.concurrent.Executors.newCachedThreadPool();
	        }
	        com.admob.android.ads.f.m.execute(this);
	        return;
	    }
	
	
	    public final Object g()
	    {
	        return this.p;
	    }
	
