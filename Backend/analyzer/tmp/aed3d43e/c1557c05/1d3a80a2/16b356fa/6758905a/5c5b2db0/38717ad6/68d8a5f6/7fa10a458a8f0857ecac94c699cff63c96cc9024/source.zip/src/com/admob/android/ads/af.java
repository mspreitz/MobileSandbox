	public  a
	public  b
	public  c
	
	    public af(android.content.Context p2, float p3)
	    {
	        this(p2);
	        this.a = -1082130432;
	        this.b = 0;
	        this.setGravity(80);
	        this.c = p3;
	        return;
	    }
	
	
	    protected final void onMeasure(int p9, int p10)
	    {
	        super.onMeasure(p9, p10);
	        if (this.b) {
	            float v0_1 = this.getMeasuredWidth();
	            android.graphics.Typeface v1 = this.getTypeface();
	            float v2 = this.getTextSize();
	            CharSequence v3 = this.getText();
	            android.text.TextPaint v4_1 = new android.text.TextPaint(this.getPaint());
	            if (v3 != null) {
	                float v5_1 = v2;
	                while (v5_1 >= this.a) {
	                    v4_1.setTypeface(v1);
	                    v4_1.setTextSize(v5_1);
	                    if (v4_1.measureText(v3, 0, v3.length()) <= ((float) v0_1)) {
	                        break;
	                    }
	                    v5_1 -= 1056964608;
	                }
	                if (v2 != v5_1) {
	                    this.setTextSize((v5_1 / this.c));
	                }
	            }
	        }
	        return;
	    }
	
