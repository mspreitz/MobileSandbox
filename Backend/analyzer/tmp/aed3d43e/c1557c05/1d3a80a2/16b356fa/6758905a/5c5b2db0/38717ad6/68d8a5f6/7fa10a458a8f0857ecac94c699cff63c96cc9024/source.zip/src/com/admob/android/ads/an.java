	private final F a
	private final F b
	private final  c
	private final  d
	private final  e
	private final  f
	private android.graphics.Camera g
	
	    public an(float p8, float p9, float p10, float p11, float p12, boolean p13)
	    {
	        float[] v1 = new float[3];
	        v1[0] = 0;
	        v1[1] = p8;
	        v1[2] = 0;
	        float[] v2_1 = new float[3];
	        v2_1[0] = 0;
	        v2_1[1] = p9;
	        v2_1[2] = 0;
	        this(v1, v2_1, p10, p11, p12, p13);
	        return;
	    }
	
	
	    public an(float[] p1, float[] p2, float p3, float p4, float p5, boolean p6)
	    {
	        this.a = p1;
	        this.b = p2;
	        this.c = p3;
	        this.d = p4;
	        this.e = p5;
	        this.f = p6;
	        return;
	    }
	
	
	    protected final void applyTransformation(float p11, android.view.animation.Transformation p12)
	    {
	        if ((((double) p11) >= 0) && (((double) p11) <= 1.0)) {
	            int v0_4 = this.a;
	            float v2_2 = new float[3];
	            float v3_0 = 0;
	            while (v3_0 < 3) {
	                v2_2[v3_0] = (v0_4[v3_0] + ((this.b[v3_0] - v0_4[v3_0]) * p11));
	                v3_0++;
	            }
	            int v0_5 = this.c;
	            float v1_1 = this.d;
	            float v3_1 = this.g;
	            android.graphics.Matrix v4_0 = p12.getMatrix();
	            v3_1.save();
	            if (!this.f) {
	                v3_1.translate(0, 0, (this.e * (1065353216 - p11)));
	            } else {
	                v3_1.translate(0, 0, (this.e * p11));
	            }
	            v3_1.rotateX(v2_2[0]);
	            v3_1.rotateY(v2_2[1]);
	            v3_1.rotateZ(v2_2[2]);
	            v3_1.getMatrix(v4_0);
	            v3_1.restore();
	            v4_0.preTranslate((- v0_5), (- v1_1));
	            v4_0.postTranslate(v0_5, v1_1);
	            p12.setTransformationType(android.view.animation.Transformation.TYPE_MATRIX);
	        } else {
	            p12.setTransformationType(android.view.animation.Transformation.TYPE_IDENTITY);
	        }
	        return;
	    }
	
	
	    public final void initialize(int p2, int p3, int p4, int p5)
	    {
	        super.initialize(p2, p3, p4, p5);
	        this.g = new android.graphics.Camera();
	        return;
	    }
	
