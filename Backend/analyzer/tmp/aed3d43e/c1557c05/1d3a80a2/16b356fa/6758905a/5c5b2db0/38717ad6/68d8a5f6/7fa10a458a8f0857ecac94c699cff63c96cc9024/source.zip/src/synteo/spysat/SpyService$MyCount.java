	final synthetic synteo.spysat.SpyService this$0
	
	    public SpyService$MyCount(synteo.spysat.SpyService p5)
	    {
	        this.this$0 = p5;
	        this(((long) (synteo.spysat.Application.m_nInverval * 1000)), ((long) (synteo.spysat.Application.m_nInverval * 200)));
	        return;
	    }
	
	
	    public void onFinish()
	    {
	        synteo.spysat.SpyService.access$1(this.this$0, new synteo.spysat.MyLoc());
	        double v15 = 0;
	        double v17 = 0;
	        int v3 = 0;
	        int v12 = 0;
	        String v10 = "";
	        if (!synteo.spysat.Application.isEmptyData()) {
	            if (!this.this$0.isEmptyCords()) {
	                if (!synteo.spysat.SpyService.access$2()) {
	                    synteo.spysat.SpyService.access$3(1);
	                    synteo.spysat.MyLoc v9 = this.this$0.getCords();
	                    if (v9 != null) {
	                        try {
	                            v15 = v9.lat;
	                            v17 = v9.lon;
	                            v12 = v9.spd;
	                            v3 = v9.alt;
	                            java.net.URL v13_0 = new java.net.URL;
	                            v13_0(new StringBuilder("http://spysat.pl/dh/g.php?u=").append(synteo.spysat.Application.m_strLogin).append("&p=").append(synteo.spysat.Application.m_strPIN).append("&x=").append(v15).append("&y=").append(v17).append("&z=").append(v3).append("&s=").append(v12).toString());
	                            java.net.URLConnection v14_0 = v13_0.openConnection();
	                            v14_0.setConnectTimeout(3300);
	                            v14_0.setReadTimeout(3300);
	                            java.io.BufferedInputStream v5_1 = new java.io.BufferedInputStream(v14_0.getInputStream());
	                            org.apache.http.util.ByteArrayBuffer v4_0 = new org.apache.http.util.ByteArrayBuffer;
	                            v4_0(50);
	                        } catch (byte v19_27) {
	                            v10 = v19_27.getMessage();
	                            synteo.spysat.SpyService.access$3(0);
	                        }
	                        while(true) {
	                            int v6_0 = v5_1.read();
	                            if (v6_0 == -1) {
	                                break;
	                            }
	                            v4_0.append(((byte) v6_0));
	                        }
	                        v10 = new String;
	                        v10(v4_0.toByteArray());
	                    }
	                    synteo.spysat.SpyService.access$3(0);
	                    synteo.spysat.Application.strStatus = new StringBuilder(String.valueOf(synteo.spysat.SpyService.now())).append("\n").append(v15).append("\n").append(v17).append("\n").append(v3).append("\n").append(v12).append("\n").append(v9.size).append("\n").append(v10).toString();
	                    this.start();
	                } else {
	                    this.start();
	                }
	            } else {
	                synteo.spysat.Application.strStatus = this.this$0.getString(2130968586);
	                if (!synteo.spysat.SpyService.access$2()) {
	                    try {
	                        java.net.URL v13_1 = new java.net.URL;
	                        v13_1(new StringBuilder("http://spysat.pl/dh/g.php?u=").append(synteo.spysat.Application.m_strLogin).append("&p=").append(synteo.spysat.Application.m_strPIN).append("&k=y&v=200&prov=spysat").toString());
	                        java.net.URLConnection v14_1 = v13_1.openConnection();
	                        v14_1.setReadTimeout(4000);
	                        v14_1.setConnectTimeout(4000);
	                        java.io.BufferedInputStream v5_3 = new java.io.BufferedInputStream(v14_1.getInputStream());
	                        org.apache.http.util.ByteArrayBuffer v4_1 = new org.apache.http.util.ByteArrayBuffer;
	                        v4_1(50);
	                    } catch (byte v19) {
	                    }
	                    while(true) {
	                        int v6_1 = v5_3.read();
	                        if (v6_1 == -1) {
	                            break;
	                        }
	                        v4_1.append(((byte) v6_1));
	                    }
	                    new String(v4_1.toByteArray());
	                }
	                this.start();
	            }
	        } else {
	            synteo.spysat.Application.strStatus = this.this$0.getString(2130968585);
	            this.start();
	        }
	        return;
	    }
	
	
	    public void onTick(long p8)
	    {
	        synteo.spysat.Application.strStatus = new StringBuilder(String.valueOf(synteo.spysat.Application.strStatus)).append(".").toString();
	        if (synteo.spysat.SpyService.access$0(this.this$0).hasData) {
	            this.this$0.addCords(synteo.spysat.SpyService.access$0(this.this$0).lat, synteo.spysat.SpyService.access$0(this.this$0).lon, synteo.spysat.SpyService.access$0(this.this$0).alt, synteo.spysat.SpyService.access$0(this.this$0).spd);
	            synteo.spysat.SpyService.access$1(this.this$0, new synteo.spysat.MyLoc());
	        }
	        return;
	    }
	
