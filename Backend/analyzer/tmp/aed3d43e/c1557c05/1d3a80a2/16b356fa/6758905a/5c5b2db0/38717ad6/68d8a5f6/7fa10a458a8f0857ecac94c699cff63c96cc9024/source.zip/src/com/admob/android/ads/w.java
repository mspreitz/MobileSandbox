	public java.lang.String a
	public  b
	
	    public w()
	    {
	        this.a = 0;
	        this.b = 0;
	        return;
	    }
	
	
	    public w(String p1, boolean p2)
	    {
	        this.a = p1;
	        this.b = p2;
	        return;
	    }
	
	
	    public final android.os.Bundle a()
	    {
	        android.os.Bundle v0_1 = new android.os.Bundle();
	        v0_1.putString("u", this.a);
	        v0_1.putBoolean("p", this.b);
	        return v0_1;
	    }
	
	
	    public final boolean equals(Object p7)
	    {
	        int v0_1;
	        if (!(p7 instanceof com.admob.android.ads.w)) {
	            v0_1 = 0;
	        } else {
	            if ((this.a != null) || (((com.admob.android.ads.w) p7).a == null)) {
	                int v0_4 = 0;
	            } else {
	                v0_4 = 1;
	            }
	            if ((this.a == null) || (this.a.equals(((com.admob.android.ads.w) p7).a))) {
	                int v1_3 = 0;
	            } else {
	                v1_3 = 1;
	            }
	            int v2_2;
	            if (this.b == ((com.admob.android.ads.w) p7).b) {
	                v2_2 = 0;
	            } else {
	                v2_2 = 1;
	            }
	            if ((v0_4 != 0) || ((v1_3 != 0) || (v2_2 != 0))) {
	                v0_1 = 0;
	            } else {
	                v0_1 = 1;
	            }
	        }
	        return v0_1;
	    }
	
	
	    public final int hashCode()
	    {
	        int v0_1;
	        if (this.a == null) {
	            v0_1 = super.hashCode();
	        } else {
	            v0_1 = this.a.hashCode();
	        }
	        return v0_1;
	    }
	
