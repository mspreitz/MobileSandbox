	private java.lang.ref.WeakReference a
	
	    public AdView$b(com.admob.android.ads.AdView p2)
	    {
	        this.a = new ref.WeakReference(p2);
	        return;
	    }
	
	
	    public final void run()
	    {
	        com.admob.android.ads.AdView v14_2 = ((com.admob.android.ads.AdView) this.a.get());
	        if (v14_2 != null) {
	            try {
	                String v1_0 = v14_2.getContext();
	            } catch (Exception v0_7) {
	                if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                    android.util.Log.e("AdMobSDK", "Unhandled exception requesting a fresh ad.", v0_7);
	                }
	                com.admob.android.ads.AdView.f(v14_2);
	                com.admob.android.ads.AdView.a(v14_2, 0);
	                com.admob.android.ads.AdView.b(v14_2, 1);
	            } catch (Exception v0_8) {
	                com.admob.android.ads.AdView.a(v14_2, 0);
	                com.admob.android.ads.AdView.b(v14_2, 1);
	                throw v0_8;
	            }
	            if (com.admob.android.ads.b.a(com.admob.android.ads.AdView.c(v14_2), v1_0, com.admob.android.ads.AdView.d(v14_2), com.admob.android.ads.AdView.e(v14_2), v14_2.getPrimaryTextColor(), v14_2.getSecondaryTextColor(), v14_2.getBackgroundColor(), new com.admob.android.ads.k(0, v1_0, v14_2), ((int) (((float) v14_2.getMeasuredWidth()) / com.admob.android.ads.k.d())), v14_2.a(), 0, v14_2.b()) == null) {
	                com.admob.android.ads.AdView.f(v14_2);
	            }
	            com.admob.android.ads.AdView.a(v14_2, 0);
	            com.admob.android.ads.AdView.b(v14_2, 1);
	        }
	        return;
	    }
	
