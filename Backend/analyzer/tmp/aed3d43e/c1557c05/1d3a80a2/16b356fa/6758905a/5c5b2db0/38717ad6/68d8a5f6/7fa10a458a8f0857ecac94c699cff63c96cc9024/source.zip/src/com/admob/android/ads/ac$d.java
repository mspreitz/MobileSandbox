	private java.lang.ref.WeakReference a
	
	    public ac$d(com.admob.android.ads.ac p2)
	    {
	        this.a = new ref.WeakReference(p2);
	        return;
	    }
	
	
	    public final boolean onTouch(android.view.View p3, android.view.MotionEvent p4)
	    {
	        int v0_1;
	        com.admob.android.ads.ac v2_2 = ((com.admob.android.ads.ac) this.a.get());
	        if (v2_2 != null) {
	            com.admob.android.ads.ac.a(v2_2, 0);
	            com.admob.android.ads.ac.a(v2_2, p4);
	            v0_1 = 0;
	        } else {
	            v0_1 = 0;
	        }
	        return v0_1;
	    }
	
