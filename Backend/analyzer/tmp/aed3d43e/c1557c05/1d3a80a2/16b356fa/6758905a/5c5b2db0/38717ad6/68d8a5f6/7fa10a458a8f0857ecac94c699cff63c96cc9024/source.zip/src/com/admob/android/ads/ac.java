	 android.view.ViewGroup d
	 android.widget.VideoView e
	 com.admob.android.ads.d f
	  g
	  h
	  i
	  j
	 com.admob.android.ads.aa k
	private  l
	private android.widget.Button m
	private java.lang.Runnable n
	private  o
	private com.admob.android.ads.ac$b p
	private java.lang.ref.WeakReference q
	private android.widget.MediaController r
	
	    public ac(android.content.Context p3, ref.WeakReference p4)
	    {
	        this(p3);
	        this.i = 0;
	        this.j = 0;
	        this.q = p4;
	        this.n = new com.admob.android.ads.ac$c(this);
	        this.h = 0;
	        this.i = 0;
	        this.j = 0;
	        return;
	    }
	
	
	    private void a(android.content.Context p5)
	    {
	        com.admob.android.ads.aa v0_1 = this.c.h;
	        this.e = new android.widget.VideoView(p5);
	        android.widget.VideoView v1_3 = new com.admob.android.ads.ac$a(this);
	        this.e.setOnPreparedListener(v1_3);
	        this.e.setOnCompletionListener(v1_3);
	        this.e.setVideoPath(v0_1.a);
	        this.e.setBackgroundDrawable(0);
	        this.e.setOnErrorListener(v1_3);
	        com.admob.android.ads.aa v0_6 = new android.widget.RelativeLayout$LayoutParams(-1, -1);
	        v0_6.addRule(13);
	        this.addView(this.e, v0_6);
	        if (this.k != null) {
	            this.k.b();
	        }
	        return;
	    }
	
	
	    public static void a(android.view.View p3)
	    {
	        android.view.animation.AlphaAnimation v0_1 = new android.view.animation.AlphaAnimation(0, 1065353216);
	        v0_1.setDuration(1000);
	        v0_1.setFillAfter(1);
	        p3.startAnimation(v0_1);
	        p3.invalidate();
	        return;
	    }
	
	
	    static synthetic void a(com.admob.android.ads.ac p0)
	    {
	        p0.g();
	        return;
	    }
	
	
	    static synthetic void a(com.admob.android.ads.ac p0, android.content.Context p1)
	    {
	        p0.a(p1);
	        return;
	    }
	
	
	    static synthetic void a(com.admob.android.ads.ac p4, android.view.MotionEvent p5)
	    {
	        android.util.Log.v("AdMobSDK", "fadeBars()");
	        if ((p4.e()) && (p4.k != null)) {
	            if (p4.g != 2) {
	                if (p5.getAction() == 0) {
	                    if (!p4.k.b) {
	                        p4.k.b();
	                    } else {
	                        p4.k.a();
	                    }
	                }
	            } else {
	                p4.a.removeCallbacks(p4.n);
	                if (!p4.k.b) {
	                    p4.k.b();
	                }
	                p4.a.postDelayed(p4.n, 3000);
	            }
	        }
	        return;
	    }
	
	
	    static synthetic void a(com.admob.android.ads.ac p1, boolean p2)
	    {
	        p1.b(0);
	        return;
	    }
	
	
	    public static void b(android.view.View p3)
	    {
	        android.view.animation.AlphaAnimation v0_1 = new android.view.animation.AlphaAnimation(1065353216, 0);
	        v0_1.setDuration(1000);
	        v0_1.setFillAfter(1);
	        p3.startAnimation(v0_1);
	        p3.invalidate();
	        return;
	    }
	
	
	    private void b(boolean p1)
	    {
	        this.o = p1;
	        if (!p1) {
	            this.g();
	        }
	        return;
	    }
	
	
	    private void g()
	    {
	        if (this.p != null) {
	            this.a.removeCallbacks(this.p);
	            this.p = 0;
	        }
	        return;
	    }
	
	
	    private void h()
	    {
	        if (this.c.h.c()) {
	            android.widget.RelativeLayout$LayoutParams v0_3 = this.getContext();
	            this.d = new android.widget.RelativeLayout(v0_3);
	            android.view.ViewGroup v1_3 = new android.widget.ImageView(v0_3);
	            android.widget.RelativeLayout$LayoutParams v0_5 = this.c.b();
	            if (v0_5 != null) {
	                android.widget.RelativeLayout$LayoutParams v0_7 = ((android.graphics.Bitmap) v0_5.get(this.c.h.f));
	                if (v0_7 != null) {
	                    float v3_2 = this.getResources().getDisplayMetrics().density;
	                    v1_3.setImageDrawable(new android.graphics.drawable.BitmapDrawable(v0_7));
	                    android.widget.RelativeLayout$LayoutParams v2_6 = new android.widget.RelativeLayout$LayoutParams(com.admob.android.ads.j.a(v0_7.getWidth(), ((double) v3_2)), com.admob.android.ads.j.a(v0_7.getHeight(), ((double) v3_2)));
	                    v2_6.addRule(13);
	                    this.d.addView(v1_3, v2_6);
	                    this.d.setBackgroundColor(0);
	                    this.d.setVisibility(4);
	                    this.addView(this.d, new android.widget.RelativeLayout$LayoutParams(-1, -1));
	                }
	            }
	            this.l = System.currentTimeMillis();
	        }
	        return;
	    }
	
	
	    public final void a()
	    {
	        if (!this.h) {
	            com.admob.android.ads.ac$g v0_2 = new com.admob.android.ads.ac$g(this);
	            android.os.Handler v1_1 = (System.currentTimeMillis() - this.l);
	            long v3_6 = ((long) ((int) (this.c.h.g * 1000.0)));
	            if (v3_6 <= v1_1) {
	                this.a.post(v0_2);
	            } else {
	                this.a.postDelayed(v0_2, (v3_6 - v1_1));
	            }
	        } else {
	            this.a.post(new com.admob.android.ads.ac$f(this));
	        }
	        return;
	    }
	
	
	    public final void a(android.content.res.Configuration p3)
	    {
	        this.g = p3.orientation;
	        if ((this.k == null) || (!this.e())) {
	            this.a.removeCallbacks(this.n);
	        } else {
	            if ((this.g != 2) || (!this.k.b)) {
	                if ((!this.k.b) && (this.g == 1)) {
	                    this.k.b();
	                }
	            } else {
	                this.k.a();
	            }
	        }
	        return;
	    }
	
	
	    public final void a(boolean p15)
	    {
	        this.a.removeCallbacks(this.n);
	        if (this.d == null) {
	            this.h();
	        }
	        if (this.d != null) {
	            com.admob.android.ads.ac.a(this.d);
	        }
	        if (this.k != null) {
	            com.admob.android.ads.aa v6 = this.k;
	            android.view.ViewGroup v1_1 = this.getContext();
	            int v4_0 = this.c;
	            float v7 = this.b;
	            if (v6.a == null) {
	                long v2_1 = new android.widget.RelativeLayout(v1_1);
	                android.graphics.Bitmap v5_1 = new android.widget.Button(v1_1);
	                v5_1.setTextColor(-1);
	                v5_1.setOnClickListener(new com.admob.android.ads.ac$h(this));
	                int v8_3 = new android.graphics.drawable.BitmapDrawable(((android.graphics.Bitmap) v4_0.b().get(v4_0.h.l)));
	                v8_3.setBounds(0, 0, ((int) (1124466688 * v7)), ((int) (1124466688 * v7)));
	                v5_1.setWidth(((int) (1124466688 * v7)));
	                v5_1.setHeight(134);
	                v5_1.setBackgroundDrawable(v8_3);
	                com.admob.android.ads.aa v0_16 = new android.widget.RelativeLayout$LayoutParams(((int) (1124466688 * v7)), ((int) (1124466688 * v7)));
	                v0_16.addRule(13);
	                v2_1.addView(v5_1, v0_16);
	                v2_1.setOnClickListener(new com.admob.android.ads.ac$h(this));
	                com.admob.android.ads.aa v0_20 = new android.widget.TextView(v1_1);
	                v0_20.setTextColor(-1);
	                v0_20.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
	                v0_20.setText("Replay");
	                v0_20.setPadding(0, 0, 0, ((int) (1096810496 * v7)));
	                android.graphics.Bitmap v5_8 = new android.widget.RelativeLayout$LayoutParams(-2, -2);
	                v5_8.addRule(12);
	                v5_8.addRule(14);
	                v2_1.addView(v0_20, v5_8);
	                v6.a = new com.admob.android.ads.x(v1_1, v2_1, 134, 134, ((android.graphics.Bitmap) v4_0.b().get(v4_0.h.k)));
	                v6.a.setOnClickListener(new com.admob.android.ads.ac$h(this));
	                v6.a.setVisibility(4);
	                com.admob.android.ads.aa v0_27 = new android.widget.RelativeLayout$LayoutParams(((int) (1124466688 * v7)), ((int) (1124466688 * v7)));
	                v0_27.addRule(13);
	                this.addView(v6.a, v0_27);
	            }
	            if (p15) {
	                com.admob.android.ads.aa v0_28 = this.k;
	                if (v0_28.a != null) {
	                    v0_28.a.bringToFront();
	                    com.admob.android.ads.ac.a(v0_28.a);
	                }
	            }
	            if (!this.k.b) {
	                this.k.b();
	            }
	        }
	        if ((this.o) && (this.p == null)) {
	            this.p = new com.admob.android.ads.ac$b(this);
	            this.a.postDelayed(this.p, 7500);
	        }
	        return;
	    }
	
	
	    public final void b()
	    {
	        if (this.d != null) {
	            com.admob.android.ads.ac.b(this.d);
	        }
	        if (this.m != null) {
	            com.admob.android.ads.ac.b(this.m);
	        }
	        if ((this.k != null) && (!this.k.b)) {
	            this.k.b();
	        }
	        if (this.k != null) {
	            android.os.Handler v0_9 = this.k;
	            if (v0_9.a != null) {
	                com.admob.android.ads.ac.b(v0_9.a);
	            }
	        }
	        this.invalidate();
	        if ((this.g == 2) && ((this.k != null) && (this.k.b))) {
	            this.a.postDelayed(this.n, 3000);
	        }
	        this.a.postDelayed(new com.admob.android.ads.ac$f(this), 1000);
	        return;
	    }
	
	
	    public final void c()
	    {
	        this.f();
	        java.util.HashMap v0_0 = 0;
	        if (this.i) {
	            v0_0 = new java.util.HashMap();
	            v0_0.put("event", "completed");
	        }
	        this.f.a("done", v0_0);
	        this.d();
	        return;
	    }
	
	
	    void d()
	    {
	        if (this.q != null) {
	            android.app.Activity v1_2 = ((android.app.Activity) this.q.get());
	            if (v1_2 != null) {
	                v1_2.finish();
	            }
	        }
	        return;
	    }
	
	
	    boolean e()
	    {
	        if ((this.e == null) || (!this.e.isPlaying())) {
	            int v0_3 = 0;
	        } else {
	            v0_3 = 1;
	        }
	        return v0_3;
	    }
	
	
	    void f()
	    {
	        if (this.e != null) {
	            this.e.stopPlayback();
	            this.e.setVisibility(4);
	            this.removeView(this.e);
	            this.e = 0;
	        }
	        return;
	    }
	
	
	    protected final void onAttachedToWindow()
	    {
	        this.p = 0;
	        if (this.c != null) {
	            this.b(this.c.l);
	            com.admob.android.ads.p v3 = this.c.h;
	            if (v3 != null) {
	                android.widget.MediaController v1_1 = this.getContext();
	                if (com.admob.android.ads.AdManager.getOrientation(v1_1) != "l") {
	                    this.g = 1;
	                } else {
	                    this.g = 2;
	                }
	                android.widget.VideoView v0_11;
	                this.f = new com.admob.android.ads.d(this.c.j, com.admob.android.ads.AdManager.getPublisherId(v1_1), this.c.i, com.admob.android.ads.AdManager.getUserId(v1_1));
	                this.f.a("video", 0);
	                this.a(v1_1);
	                if (!this.c.l) {
	                    v0_11 = "Done";
	                } else {
	                    v0_11 = "Skip";
	                }
	                android.widget.MediaController v2_5 = com.admob.android.ads.t.a(v0_11);
	                if (v3.c()) {
	                    this.h();
	                    if (this.d != null) {
	                        com.admob.android.ads.ac.a(this.d);
	                    }
	                    if ((!v3.j) || (!v3.c())) {
	                        this.m = new android.widget.Button(v1_1);
	                        this.m.setOnClickListener(new com.admob.android.ads.ac$i(this, 1));
	                        this.m.setBackgroundResource(17301509);
	                        this.m.setTextSize(1095761920);
	                        this.m.setText(v2_5);
	                        this.m.setVisibility(4);
	                        android.widget.VideoView v0_25 = new android.widget.RelativeLayout$LayoutParams(((int) (1113063424 * this.b)), ((int) (1108344832 * this.b)));
	                        v0_25.addRule(11);
	                        v0_25.addRule(12);
	                        v0_25.setMargins(0, 0, ((int) (1073741824 * this.b)), ((int) (1090519040 * this.b)));
	                        this.addView(this.m, v0_25);
	                        com.admob.android.ads.ac.a(this.m);
	                    }
	                }
	                if ((v3.c != 2) || ((v3.m == null) || (v3.m.size() <= 0))) {
	                    android.widget.MediaController v1_2;
	                    if (v3.c != 0) {
	                        v1_2 = 0;
	                    } else {
	                        v1_2 = 1;
	                    }
	                    android.widget.VideoView v0_34 = ((android.app.Activity) this.q.get());
	                    if ((v0_34 != null) && (this.e != null)) {
	                        this.r = new android.widget.MediaController(v0_34, v1_2);
	                        this.r.setAnchorView(this.e);
	                        this.e.setMediaController(this.r);
	                    }
	                } else {
	                    this.k = new com.admob.android.ads.aa();
	                    this.k.a(v1_1, v2_5, v3, this.b, this, this.c, this.q);
	                }
	            } else {
	                if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                    android.util.Log.e("AdMobSDK", "movieInfo is null");
	                }
	            }
	        } else {
	            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                android.util.Log.e("AdMobSDK", "openerInfo is null");
	            }
	        }
	        return;
	    }
	
