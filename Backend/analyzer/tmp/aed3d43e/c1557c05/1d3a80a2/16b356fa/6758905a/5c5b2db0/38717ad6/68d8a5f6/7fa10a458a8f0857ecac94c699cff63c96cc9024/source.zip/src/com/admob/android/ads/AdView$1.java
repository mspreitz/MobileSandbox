	private synthetic com.admob.android.ads.k a
	private synthetic com.admob.android.ads.AdView b
	
	    AdView$1(com.admob.android.ads.AdView p1, com.admob.android.ads.k p2)
	    {
	        this.b = p1;
	        this.a = p2;
	        return;
	    }
	
	
	    public final void onAnimationEnd(android.view.animation.Animation p5)
	    {
	        this.b.post(new com.admob.android.ads.AdView$g(this.a, this.b));
	        return;
	    }
	
	
	    public final void onAnimationRepeat(android.view.animation.Animation p1)
	    {
	        return;
	    }
	
	
	    public final void onAnimationStart(android.view.animation.Animation p1)
	    {
	        return;
	    }
	
