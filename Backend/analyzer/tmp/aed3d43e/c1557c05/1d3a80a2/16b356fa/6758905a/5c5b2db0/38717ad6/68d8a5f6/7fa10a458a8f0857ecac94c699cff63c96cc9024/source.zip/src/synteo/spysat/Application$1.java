	final synthetic synteo.spysat.Application this$0
	
	    Application$1(synteo.spysat.Application p1)
	    {
	        this.this$0 = p1;
	        return;
	    }
	
	
	    public void onClick(android.view.View p6)
	    {
	        synteo.spysat.Application.m_strLogin = synteo.spysat.Application.access$0(this.this$0).getText().toString();
	        synteo.spysat.Application.m_strPIN = synteo.spysat.Application.access$1(this.this$0).getText().toString();
	        try {
	            synteo.spysat.Application.m_nInverval = Integer.parseInt(synteo.spysat.Application.access$2(this.this$0).getText().toString());
	        } catch (synteo.spysat.Application v1_13) {
	            synteo.spysat.Application.m_nInverval = 15;
	        }
	        if (synteo.spysat.Application.m_nInverval < 15) {
	            synteo.spysat.Application.m_nInverval = 15;
	        }
	        try {
	            synteo.spysat.Application.m_nDelta = Integer.parseInt(synteo.spysat.Application.access$3(this.this$0).getText().toString());
	        } catch (synteo.spysat.Application v1_20) {
	            synteo.spysat.Application.m_nDelta = 25;
	        }
	        if (synteo.spysat.Application.m_nDelta < 0) {
	            synteo.spysat.Application.m_nDelta = 0;
	        }
	        if (!synteo.spysat.Application.isEmptyData()) {
	            synteo.spysat.Application.strStatus = this.this$0.getString(2130968576);
	        } else {
	            synteo.spysat.Application.strStatus = this.this$0.getString(2130968585);
	        }
	        this.this$0.messageBox("Info", this.this$0.getString(2130968595));
	        return;
	    }
	
