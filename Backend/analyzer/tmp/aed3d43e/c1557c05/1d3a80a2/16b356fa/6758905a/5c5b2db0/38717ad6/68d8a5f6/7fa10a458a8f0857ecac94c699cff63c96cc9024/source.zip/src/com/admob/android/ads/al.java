	
	    public al(float p1, float p2, float p3, float p4, float p5, float p6)
	    {
	        this(p1, p2, p3, p4, p5, p6);
	        return;
	    }
	
	
	    protected final void applyTransformation(float p5, android.view.animation.Transformation p6)
	    {
	        if ((((double) p5) >= 0) || (((double) p5) <= 1.0)) {
	            super.applyTransformation(p5, p6);
	        }
	        return;
	    }
	
