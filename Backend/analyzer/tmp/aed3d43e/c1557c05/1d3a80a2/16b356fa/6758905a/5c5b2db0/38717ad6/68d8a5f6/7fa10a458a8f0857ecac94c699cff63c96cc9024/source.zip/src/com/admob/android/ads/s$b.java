	
	    s$b()
	    {
	        return;
	    }
	
	
	    public final bridge synthetic int compare(Object p8, Object p9)
	    {
	        if ((((java.io.File) p8) != null) || (((java.io.File) p9) != null)) {
	            if ((((java.io.File) p8) == null) || (((java.io.File) p9) == null)) {
	                if (((java.io.File) p8) != null) {
	                    int v0_0 = 1;
	                    return v0_0;
	                }
	            } else {
	                int v0_1 = ((java.io.File) p8).lastModified();
	                long v2 = ((java.io.File) p9).lastModified();
	                if (v0_1 != v2) {
	                    if (v0_1 >= v2) {
	                        v0_0 = 1;
	                        return v0_0;
	                    }
	                } else {
	                    v0_0 = 0;
	                    return v0_0;
	                }
	            }
	            v0_0 = -1;
	        } else {
	            v0_0 = 0;
	        }
	        return v0_0;
	    }
	
