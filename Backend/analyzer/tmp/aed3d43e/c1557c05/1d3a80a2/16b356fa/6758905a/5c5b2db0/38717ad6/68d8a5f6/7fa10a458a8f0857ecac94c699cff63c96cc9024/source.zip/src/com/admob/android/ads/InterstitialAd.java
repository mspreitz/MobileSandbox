	public static final java.lang.String ADMOB_INTENT_BOOLEAN
	private static android.os.Handler a
	private static java.util.Timer b
	private static com.admob.android.ads.InterstitialAd$a c
	private com.admob.android.ads.InterstitialAd$Event d
	private java.lang.ref.WeakReference e
	private  f
	private  g
	private com.admob.android.ads.j h
	private java.lang.String i
	private java.lang.String j
	private com.admob.android.ads.InterstitialAd$c k
	private  l
	
	    static InterstitialAd()
	    {
	        com.admob.android.ads.InterstitialAd.a = 0;
	        com.admob.android.ads.InterstitialAd.b = 0;
	        com.admob.android.ads.InterstitialAd.c = 0;
	        return;
	    }
	
	
	    public InterstitialAd(com.admob.android.ads.InterstitialAd$Event p4, com.admob.android.ads.InterstitialAdListener p5)
	    {
	        this.d = p4;
	        this.e = new ref.WeakReference(p5);
	        this.f = 0;
	        this.g = 0;
	        this.h = 0;
	        this.i = 0;
	        this.j = 0;
	        this.k = new com.admob.android.ads.InterstitialAd$c(this);
	        this.l = -1;
	        if (com.admob.android.ads.InterstitialAd.a == null) {
	            com.admob.android.ads.InterstitialAd.a = new android.os.Handler();
	        }
	        return;
	    }
	
	
	    static synthetic void a(com.admob.android.ads.InterstitialAd p4)
	    {
	        if (com.admob.android.ads.InterstitialAd.h()) {
	            com.admob.android.ads.InterstitialAd.g();
	            p4.k.a = 0;
	            try {
	                com.admob.android.ads.InterstitialAd.c.a = 1;
	                com.admob.android.ads.InterstitialAd.c = 0;
	            } catch (String v0) {
	            }
	            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 5)) {
	                String v0_7;
	                String v0_6 = com.admob.android.ads.j.n();
	                if (v0_6 <= 0) {
	                    v0_7 = "";
	                } else {
	                    v0_7 = new StringBuilder().append(": ").append(v0_6).toString();
	                }
	                android.util.Log.w("AdMobSDK", new StringBuilder().append("request timed out (client timeout").append(v0_7).append(")").toString());
	            }
	            p4.c();
	        }
	        return;
	    }
	
	
	    static synthetic void a(com.admob.android.ads.InterstitialAd p0, com.admob.android.ads.j p1)
	    {
	        p0.h = p1;
	        return;
	    }
	
	
	    private static void g()
	    {
	        if (com.admob.android.ads.InterstitialAd.b != null) {
	            com.admob.android.ads.InterstitialAd.b.cancel();
	            com.admob.android.ads.InterstitialAd.b = 0;
	        }
	        return;
	    }
	
	
	    private static boolean h()
	    {
	        int v0_1;
	        if (com.admob.android.ads.InterstitialAd.c == null) {
	            v0_1 = 0;
	        } else {
	            v0_1 = 1;
	        }
	        return v0_1;
	    }
	
	
	    final void a()
	    {
	        if (com.admob.android.ads.InterstitialAd.a != null) {
	            com.admob.android.ads.InterstitialAd.a.post(new com.admob.android.ads.InterstitialAd$e(this));
	        }
	        return;
	    }
	
	
	    final void a(android.app.Activity p6)
	    {
	        if (this.f) {
	            this.g = 1;
	            this.f = 0;
	            String v0_3 = this.h.a();
	            if (v0_3 != null) {
	                android.content.pm.PackageManager v1_1 = p6.getPackageManager();
	                String v0_5 = v0_3.b.iterator();
	                while (v0_5.hasNext()) {
	                    android.content.Intent v5_2 = ((android.content.Intent) v0_5.next());
	                    if (v1_1.resolveActivity(v5_2, 65536) != null) {
	                        try {
	                            p6.startActivityForResult(v5_2, 0);
	                        } catch (Exception v2) {
	                        }
	                    }
	                }
	                if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                    android.util.Log.e("AdMobSDK", "Could not find a resolving intent on ad click");
	                }
	            }
	        } else {
	            if (!this.g) {
	                if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                    android.util.Log.e("AdMobSDK", "Cannot call show before interstitial is ready");
	                }
	            } else {
	                if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                    android.util.Log.e("AdMobSDK", "Show has already been called.  Please create and request a new interstitial");
	                }
	            }
	        }
	        return;
	    }
	
	
	    final void b()
	    {
	        com.admob.android.ads.InterstitialAd.g();
	        if ((this.l != -1) && (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 2))) {
	            android.util.Log.v("AdMobSDK", new StringBuilder().append("total request time: ").append((android.os.SystemClock.uptimeMillis() - this.l)).toString());
	        }
	        this.f = 1;
	        com.admob.android.ads.InterstitialAd.c = 0;
	        Exception v0_12 = ((com.admob.android.ads.InterstitialAdListener) this.e.get());
	        if (v0_12 != null) {
	            try {
	                v0_12.onReceiveInterstitial(this);
	            } catch (Exception v0_13) {
	                android.util.Log.w("AdMobSDK", "Unhandled exception raised in your InterstitialAdListener.onReceiveInterstitial.", v0_13);
	            }
	        }
	        return;
	    }
	
	
	    final void c()
	    {
	        if (com.admob.android.ads.InterstitialAd.a != null) {
	            com.admob.android.ads.InterstitialAd.a.post(new com.admob.android.ads.InterstitialAd$b(this));
	        }
	        return;
	    }
	
	
	    final void d()
	    {
	        com.admob.android.ads.InterstitialAd.c = 0;
	        Exception v0_3 = ((com.admob.android.ads.InterstitialAdListener) this.e.get());
	        if (v0_3 != null) {
	            try {
	                v0_3.onFailedToReceiveInterstitial(this);
	            } catch (Exception v0_4) {
	                android.util.Log.w("AdMobSDK", "Unhandled exception raised in your InterstitialAdListener.onFailedToReceiveInterstitial.", v0_4);
	            }
	        }
	        return;
	    }
	
	
	    final com.admob.android.ads.InterstitialAd$Event e()
	    {
	        return this.d;
	    }
	
	
	    final com.admob.android.ads.InterstitialAd$c f()
	    {
	        return this.k;
	    }
	
	
	    public String getKeywords()
	    {
	        return this.j;
	    }
	
	
	    public String getSearchQuery()
	    {
	        return this.i;
	    }
	
	
	    public boolean isReady()
	    {
	        return this.f;
	    }
	
	
	    public void requestAd(android.content.Context p6)
	    {
	        if (!com.admob.android.ads.InterstitialAd.h()) {
	            float v0_2 = new com.admob.android.ads.InterstitialAd$a(this, p6);
	            com.admob.android.ads.InterstitialAd.c = v0_2;
	            v0_2.start();
	            this.l = android.os.SystemClock.uptimeMillis();
	            float v0_4 = com.admob.android.ads.j.a(p6);
	            if (v0_4 > 0) {
	                com.admob.android.ads.InterstitialAd$f v1_4 = new com.admob.android.ads.InterstitialAd$f(this);
	                if (com.admob.android.ads.InterstitialAd.b == null) {
	                    com.admob.android.ads.InterstitialAd.b = new java.util.Timer();
	                }
	                com.admob.android.ads.InterstitialAd.b.schedule(v1_4, ((long) (v0_4 * 1148846080)));
	            }
	        } else {
	            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                android.util.Log.e("AdMobSDK", "A request is already in progress.  This request will fail.");
	            }
	            this.c();
	        }
	        return;
	    }
	
	
	    public void setKeywords(String p1)
	    {
	        this.j = p1;
	        return;
	    }
	
	
	    public void setListener(com.admob.android.ads.InterstitialAdListener p2)
	    {
	        this.e = new ref.WeakReference(p2);
	        return;
	    }
	
	
	    public void setSearchQuery(String p1)
	    {
	        this.i = p1;
	        return;
	    }
	
	
	    public void show(android.app.Activity p3)
	    {
	        com.admob.android.ads.InterstitialAd.a.post(new com.admob.android.ads.InterstitialAd$d(p3, this));
	        return;
	    }
	
