	public static final  main
	public static final  setup
	
	    public R$layout()
	    {
	        return;
	    }
	
