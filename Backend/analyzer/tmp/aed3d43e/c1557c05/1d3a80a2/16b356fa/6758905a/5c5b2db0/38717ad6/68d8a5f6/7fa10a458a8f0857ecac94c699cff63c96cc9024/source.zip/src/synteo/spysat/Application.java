	public static final java.lang.String ACTIONS
	private static final  MENU_DEVICES
	private static final  MENU_QUIT
	private static final  MENU_SETTINGS
	private static final  MENU_URL
	private static final  MENU_VIDEO
	public static final java.lang.String PREFS_NAME
	public static final java.lang.String PUBLISHER
	private static android.content.Intent mSpyService
	public static  m_nDelta
	public static  m_nInverval
	public static java.lang.String m_strLogin
	public static java.lang.String m_strPIN
	public static java.lang.String strStatus
	private synteo.spysat.Application$UICount counter
	protected android.view.View$OnClickListener mButtonAccListener
	private android.view.View$OnClickListener mButtonCancelListener
	private android.view.View$OnClickListener mButtonSaveListener
	private android.view.View$OnClickListener mButtonVideoListener
	private synteo.spysat.SpyMainView mainView
	private android.widget.Button settingsButtonAcc
	private android.widget.Button settingsButtonCancel
	private android.widget.Button settingsButtonSave
	private android.widget.Button settingsButtonVideo
	private android.widget.TextView settingsDeltaView
	private android.widget.EditText settingsEditDelta
	private android.widget.EditText settingsEditInterval
	private android.widget.EditText settingsEditLogin
	private android.widget.EditText settingsEditPIN
	private android.widget.TextView settingsInfoView
	private android.widget.TextView settingsIntervalView
	private android.widget.LinearLayout settingsLayout
	private android.widget.TextView settingsLoginView
	private android.widget.TextView settingsPINView
	
	    static Application()
	    {
	        synteo.spysat.Application.m_nInverval = 15;
	        synteo.spysat.Application.m_nDelta = 20;
	        return;
	    }
	
	
	    public Application()
	    {
	        this.mButtonSaveListener = new synteo.spysat.Application$1(this);
	        this.mButtonCancelListener = new synteo.spysat.Application$2(this);
	        this.mButtonAccListener = new synteo.spysat.Application$3(this);
	        this.mButtonVideoListener = new synteo.spysat.Application$4(this);
	        return;
	    }
	
	
	    static synthetic android.widget.EditText access$0(synteo.spysat.Application p1)
	    {
	        return p1.settingsEditLogin;
	    }
	
	
	    static synthetic android.widget.EditText access$1(synteo.spysat.Application p1)
	    {
	        return p1.settingsEditPIN;
	    }
	
	
	    static synthetic android.widget.EditText access$2(synteo.spysat.Application p1)
	    {
	        return p1.settingsEditInterval;
	    }
	
	
	    static synthetic android.widget.EditText access$3(synteo.spysat.Application p1)
	    {
	        return p1.settingsEditDelta;
	    }
	
	
	    static synthetic void access$4(synteo.spysat.Application p0)
	    {
	        p0.showMain();
	        return;
	    }
	
	
	    static synthetic synteo.spysat.SpyMainView access$5(synteo.spysat.Application p1)
	    {
	        return p1.mainView;
	    }
	
	
	    static synthetic void access$6(synteo.spysat.Application p0)
	    {
	        p0.quit();
	        return;
	    }
	
	
	    public static boolean isEmptyData()
	    {
	        if ((synteo.spysat.Application.m_strLogin != null) && (!"".equals(synteo.spysat.Application.m_strLogin))) {
	            if ((synteo.spysat.Application.m_strPIN != null) && (!"".equals(synteo.spysat.Application.m_strPIN))) {
	                int v0_6 = 0;
	            } else {
	                v0_6 = 1;
	            }
	        } else {
	            v0_6 = 1;
	        }
	        return v0_6;
	    }
	
	
	    private void quit()
	    {
	        this.stopService(synteo.spysat.Application.mSpyService);
	        synteo.spysat.Application.mSpyService = 0;
	        this.finish();
	        return;
	    }
	
	
	    private void showMain()
	    {
	        this.setContentView(this.mainView);
	        return;
	    }
	
	
	    private void showSettings()
	    {
	        this.settingsLayout = new android.widget.LinearLayout(this);
	        this.settingsLayout.setOrientation(1);
	        this.settingsEditLogin = new android.widget.EditText(this);
	        this.settingsEditLogin.setText(synteo.spysat.Application.m_strLogin);
	        this.settingsEditPIN = new android.widget.EditText(this);
	        this.settingsEditPIN.setText(synteo.spysat.Application.m_strPIN);
	        this.settingsEditInterval = new android.widget.EditText(this);
	        this.settingsEditInterval.setText(String.valueOf(synteo.spysat.Application.m_nInverval));
	        this.settingsEditInterval.setWidth(160);
	        this.settingsEditInterval.setInputType(2);
	        this.settingsIntervalView = new android.widget.TextView(this);
	        this.settingsIntervalView.setText(2130968593);
	        this.settingsIntervalView.setWidth(160);
	        this.settingsEditDelta = new android.widget.EditText(this);
	        this.settingsEditDelta.setText(String.valueOf(synteo.spysat.Application.m_nDelta));
	        this.settingsEditDelta.setWidth(160);
	        this.settingsEditDelta.setInputType(2);
	        this.settingsDeltaView = new android.widget.TextView(this);
	        this.settingsDeltaView.setText(2130968594);
	        this.settingsDeltaView.setWidth(160);
	        this.settingsInfoView = new android.widget.TextView(this);
	        this.settingsInfoView.setText(2130968579);
	        this.settingsInfoView.setOnClickListener(this.mButtonAccListener);
	        this.settingsLoginView = new android.widget.TextView(this);
	        this.settingsLoginView.setText(2130968581);
	        this.settingsLoginView.setWidth(160);
	        this.settingsPINView = new android.widget.TextView(this);
	        this.settingsPINView.setText(2130968582);
	        this.settingsPINView.setWidth(160);
	        this.settingsButtonSave = new android.widget.Button(this);
	        this.settingsButtonSave.setText(2130968583);
	        this.settingsButtonSave.setOnClickListener(this.mButtonSaveListener);
	        this.settingsButtonCancel = new android.widget.Button(this);
	        this.settingsButtonCancel.setText(2130968584);
	        this.settingsButtonCancel.setOnClickListener(this.mButtonCancelListener);
	        this.settingsButtonAcc = new android.widget.Button(this);
	        this.settingsButtonAcc.setText(2130968587);
	        this.settingsButtonAcc.setTextSize(1101004800);
	        this.settingsButtonAcc.setTextColor(-65536);
	        this.settingsButtonAcc.setOnClickListener(this.mButtonAccListener);
	        this.settingsButtonVideo = new android.widget.Button(this);
	        this.settingsButtonVideo.setText(2130968591);
	        this.settingsButtonVideo.setOnClickListener(this.mButtonVideoListener);
	        this.settingsLayout.addView(this.settingsInfoView);
	        android.widget.LinearLayout v2_1 = new android.widget.LinearLayout(this);
	        v2_1.setOrientation(1);
	        v2_1.addView(this.settingsLoginView);
	        v2_1.addView(this.settingsEditLogin);
	        android.widget.LinearLayout v3_1 = new android.widget.LinearLayout(this);
	        v3_1.setOrientation(1);
	        v3_1.addView(this.settingsPINView);
	        v3_1.addView(this.settingsEditPIN);
	        android.widget.LinearLayout v1_1 = new android.widget.LinearLayout(this);
	        v1_1.setOrientation(0);
	        v1_1.addView(v2_1);
	        v1_1.addView(v3_1);
	        this.settingsLayout.addView(v1_1);
	        android.widget.LinearLayout v2_3 = new android.widget.LinearLayout(this);
	        v2_3.setOrientation(1);
	        v2_3.addView(this.settingsIntervalView);
	        v2_3.addView(this.settingsEditInterval);
	        android.widget.LinearLayout v3_3 = new android.widget.LinearLayout(this);
	        v3_3.setOrientation(1);
	        v3_3.addView(this.settingsDeltaView);
	        v3_3.addView(this.settingsEditDelta);
	        android.widget.LinearLayout v1_3 = new android.widget.LinearLayout(this);
	        v1_3.setOrientation(0);
	        v1_3.addView(v2_3);
	        v1_3.addView(v3_3);
	        this.settingsLayout.addView(v1_3);
	        this.settingsLayout.addView(this.settingsButtonSave);
	        this.settingsLayout.addView(this.settingsButtonCancel);
	        this.settingsLayout.addView(this.settingsButtonAcc);
	        com.admob.android.ads.AdManager.setPublisherId("a14c517269c490f");
	        this.settingsLayout.addView(new com.admob.android.ads.AdView(this));
	        this.settingsLayout.addView(this.settingsButtonVideo);
	        this.setContentView(this.settingsLayout);
	        return;
	    }
	
	
	    public synteo.spysat.Application getApp()
	    {
	        return this;
	    }
	
	
	    public void messageBox(String p4, String p5)
	    {
	        android.app.AlertDialog v0 = new android.app.AlertDialog$Builder(this).create();
	        v0.setTitle(p4);
	        v0.setMessage(p5);
	        v0.setButton("OK", new synteo.spysat.Application$5(this));
	        v0.show();
	        return;
	    }
	
	
	    public void onCreate(android.os.Bundle p6)
	    {
	        super.onCreate(p6);
	        this.requestWindowFeature(1);
	        this.getWindow().setFlags(1024, 1024);
	        synteo.spysat.Application.strStatus = this.getString(2130968576);
	        this.mainView = new synteo.spysat.SpyMainView(this);
	        this.setContentView(this.mainView);
	        android.content.SharedPreferences v0 = this.getSharedPreferences("SpySatPrefs", 0);
	        synteo.spysat.Application.m_strLogin = v0.getString("login", "");
	        synteo.spysat.Application.m_strPIN = v0.getString("pin", "");
	        synteo.spysat.Application.m_nInverval = v0.getInt("int", 15);
	        synteo.spysat.Application.m_nDelta = v0.getInt("delta", 20);
	        if (synteo.spysat.Application.mSpyService != null) {
	            this.stopService(synteo.spysat.Application.mSpyService);
	            synteo.spysat.Application.mSpyService = 0;
	        }
	        synteo.spysat.Application.mSpyService = new android.content.Intent(this, synteo.spysat.SpyService);
	        this.startService(synteo.spysat.Application.mSpyService);
	        if (this.counter != null) {
	            this.counter.cancel();
	            this.counter = 0;
	        }
	        this.counter = new synteo.spysat.Application$UICount(this);
	        this.counter.start();
	        if (("".equals(synteo.spysat.Application.m_strLogin)) || ("".equals(synteo.spysat.Application.m_strPIN))) {
	            this.showSettings();
	        }
	        return;
	    }
	
	
	    public boolean onCreateOptionsMenu(android.view.Menu p5)
	    {
	        p5.add(0, 0, 0, 2130968580);
	        p5.add(0, 2, 0, 2130968590);
	        p5.add(0, 3, 0, 2130968591);
	        p5.add(0, 4, 0, "Supported devices");
	        p5.add(0, 1, 0, 2130968578);
	        return 1;
	    }
	
	
	    protected void onDestroy()
	    {
	        this.counter.cancel();
	        this.counter = 0;
	        super.onDestroy();
	        return;
	    }
	
	
	    public boolean onKeyDown(int p2, android.view.KeyEvent p3)
	    {
	        boolean v0_1;
	        if (p2 != 4) {
	            v0_1 = super.onKeyDown(p2, p3);
	        } else {
	            v0_1 = 1;
	        }
	        return v0_1;
	    }
	
	
	    public boolean onOptionsItemSelected(android.view.MenuItem p3)
	    {
	        int v0_1;
	        switch (p3.getItemId()) {
	            case 0:
	                this.showSettings();
	                v0_1 = 1;
	                break;
	            case 1:
	                this.quit();
	                v0_1 = 1;
	                break;
	            case 2:
	                this.openHelpPage();
	                v0_1 = 1;
	                break;
	            case 3:
	                this.openVideoPage();
	                v0_1 = 1;
	                break;
	            case 4:
	                this.openDevicesPage();
	                v0_1 = 1;
	                break;
	            default:
	                v0_1 = 0;
	        }
	        return v0_1;
	    }
	
	
	    protected void onStop()
	    {
	        super.onStop();
	        this.saveSettings();
	        return;
	    }
	
	
	    protected void openDevicesPage()
	    {
	        this.startActivity(new android.content.Intent("android.intent.action.VIEW", android.net.Uri.parse("http://spysat.eu/free-gps-tracking-devices_f_21_n_1")));
	        return;
	    }
	
	
	    protected void openHelpPage()
	    {
	        this.startActivity(new android.content.Intent("android.intent.action.VIEW", android.net.Uri.parse(this.getResources().getString(2130968588))));
	        return;
	    }
	
	
	    protected void openHomePage()
	    {
	        this.startActivity(new android.content.Intent("android.intent.action.VIEW", android.net.Uri.parse(this.getResources().getString(2130968592))));
	        return;
	    }
	
	
	    protected void openVideoPage()
	    {
	        this.startActivity(new android.content.Intent("android.intent.action.VIEW", android.net.Uri.parse("http://www.youtube.com/watch?v=oL9NQMiJe2Y")));
	        return;
	    }
	
	
	    protected void saveSettings()
	    {
	        android.content.SharedPreferences$Editor v0 = this.getSharedPreferences("SpySatPrefs", 0).edit();
	        v0.putString("pin", synteo.spysat.Application.m_strPIN);
	        v0.putString("login", synteo.spysat.Application.m_strLogin);
	        v0.putInt("int", synteo.spysat.Application.m_nInverval);
	        v0.putInt("delta", synteo.spysat.Application.m_nDelta);
	        v0.commit();
	        return;
	    }
	
