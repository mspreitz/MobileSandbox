	public java.lang.String a
	public java.lang.String b
	public java.lang.String c
	public com.admob.android.ads.r d
	public java.lang.String e
	public java.lang.String f
	
	    public o()
	    {
	        this.d = new com.admob.android.ads.r();
	        return;
	    }
	
	
	    public final android.os.Bundle a()
	    {
	        android.os.Bundle v0_1 = new android.os.Bundle();
	        v0_1.putString("ad", this.a);
	        v0_1.putString("au", this.b);
	        v0_1.putString("t", this.c);
	        v0_1.putBundle("oi", com.admob.android.ads.AdView$a.a(this.d));
	        v0_1.putString("ap", this.e);
	        v0_1.putString("json", this.f);
	        return v0_1;
	    }
	
	
	    public final boolean a(android.os.Bundle p4)
	    {
	        int v0_12;
	        if (p4 != null) {
	            this.a = p4.getString("ad");
	            this.b = p4.getString("au");
	            this.c = p4.getString("t");
	            if (this.d.a(p4.getBundle("oi"))) {
	                this.e = p4.getString("ap");
	                this.f = p4.getString("json");
	                v0_12 = 1;
	            } else {
	                v0_12 = 0;
	            }
	        } else {
	            v0_12 = 0;
	        }
	        return v0_12;
	    }
	
