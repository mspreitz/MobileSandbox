	private java.lang.ref.WeakReference a
	private  b
	
	    public ac$i(com.admob.android.ads.ac p2, boolean p3)
	    {
	        this.a = new ref.WeakReference(p2);
	        this.b = p3;
	        return;
	    }
	
	
	    public final void onClick(android.view.View p5)
	    {
	        com.admob.android.ads.ac v0_2 = ((com.admob.android.ads.ac) this.a.get());
	        if (v0_2 != null) {
	            if (this.b) {
	                v0_2.f.a("skip", 0);
	            }
	            v0_2.c();
	        }
	        return;
	    }
	
