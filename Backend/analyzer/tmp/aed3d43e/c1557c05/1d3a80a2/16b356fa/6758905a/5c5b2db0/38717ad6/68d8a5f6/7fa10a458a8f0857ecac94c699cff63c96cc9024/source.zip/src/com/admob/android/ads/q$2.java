	static final synthetic I a
	
	    static q$2()
	    {
	        NoSuchFieldError v0_2 = new int[com.admob.android.ads.j$a.values().length];
	        com.admob.android.ads.q$2.a = v0_2;
	        try {
	            com.admob.android.ads.q$2.a[com.admob.android.ads.j$a.b.ordinal()] = 1;
	            try {
	                com.admob.android.ads.q$2.a[com.admob.android.ads.j$a.d.ordinal()] = 2;
	            } catch (NoSuchFieldError v0) {
	            }
	            try {
	                com.admob.android.ads.q$2.a[com.admob.android.ads.j$a.c.ordinal()] = 3;
	            } catch (NoSuchFieldError v0) {
	            }
	            return;
	        } catch (NoSuchFieldError v0) {
	        }
	    }
	
