	private java.lang.ref.WeakReference a
	
	    public ac$g(com.admob.android.ads.ac p2)
	    {
	        this.a = new ref.WeakReference(p2);
	        return;
	    }
	
	
	    public final void run()
	    {
	        com.admob.android.ads.ac v1_2 = ((com.admob.android.ads.ac) this.a.get());
	        if (v1_2 != null) {
	            v1_2.b();
	        }
	        return;
	    }
	
