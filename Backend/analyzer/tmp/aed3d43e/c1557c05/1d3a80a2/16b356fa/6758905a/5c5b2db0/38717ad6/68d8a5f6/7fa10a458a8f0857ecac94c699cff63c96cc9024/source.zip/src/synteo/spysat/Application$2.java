	final synthetic synteo.spysat.Application this$0
	
	    Application$2(synteo.spysat.Application p1)
	    {
	        this.this$0 = p1;
	        return;
	    }
	
	
	    public void onClick(android.view.View p2)
	    {
	        synteo.spysat.Application.access$4(this.this$0);
	        return;
	    }
	
