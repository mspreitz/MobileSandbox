	public java.lang.String a
	public java.lang.String b
	public  c
	public  d
	public java.lang.String e
	public java.lang.String f
	public  g
	public java.lang.String h
	public java.lang.String i
	public  j
	public java.lang.String k
	public java.lang.String l
	public java.util.Vector m
	
	    public p()
	    {
	        this.j = 0;
	        this.m = new java.util.Vector();
	        return;
	    }
	
	
	    public final android.os.Bundle a()
	    {
	        android.os.Bundle v0_1 = new android.os.Bundle();
	        v0_1.putString("u", this.a);
	        v0_1.putString("t", this.b);
	        v0_1.putInt("c", this.c);
	        v0_1.putInt("msm", this.d);
	        v0_1.putString("s", this.e);
	        v0_1.putString("sin", this.f);
	        v0_1.putDouble("sd", this.g);
	        v0_1.putString("skd", this.h);
	        v0_1.putString("sku", this.i);
	        v0_1.putByte("nosk", com.admob.android.ads.r.a(this.j));
	        v0_1.putString("rd", this.k);
	        v0_1.putString("ru", this.l);
	        v0_1.putParcelableArrayList("b", com.admob.android.ads.AdView$a.a(this.m));
	        return v0_1;
	    }
	
	
	    public final boolean a(android.os.Bundle p5)
	    {
	        boolean v0_29;
	        if (p5 != null) {
	            this.a = p5.getString("u");
	            this.b = p5.getString("t");
	            this.c = p5.getInt("c");
	            this.d = p5.getInt("msm");
	            this.e = p5.getString("s");
	            this.f = p5.getString("sin");
	            this.g = p5.getDouble("sd");
	            this.h = p5.getString("skd");
	            this.i = p5.getString("sku");
	            this.j = com.admob.android.ads.r.a(p5.getByte("nosk"));
	            this.k = p5.getString("rd");
	            this.l = p5.getString("ru");
	            this.m = 0;
	            boolean v0_27 = p5.getParcelableArrayList("b");
	            if (v0_27) {
	                java.util.Vector v1_1 = new java.util.Vector();
	                java.util.Iterator v2 = v0_27.iterator();
	                while (v2.hasNext()) {
	                    boolean v0_31 = ((android.os.Bundle) v2.next());
	                    if (v0_31) {
	                        com.admob.android.ads.o v3_1 = new com.admob.android.ads.o();
	                        if (v3_1.a(v0_31)) {
	                            v1_1.add(v3_1);
	                        }
	                    }
	                }
	                this.m = v1_1;
	            }
	            v0_29 = 1;
	        } else {
	            v0_29 = 0;
	        }
	        return v0_29;
	    }
	
	
	    public final boolean b()
	    {
	        if ((this.c != 0) && ((this.m != null) && (this.m.size() != 0))) {
	            int v0_4 = 0;
	        } else {
	            v0_4 = 1;
	        }
	        return v0_4;
	    }
	
	
	    public final boolean c()
	    {
	        if ((this.f == null) || ((this.f.length() <= 0) || (this.g <= 0))) {
	            int v0_5 = 0;
	        } else {
	            v0_5 = 1;
	        }
	        return v0_5;
	    }
	
