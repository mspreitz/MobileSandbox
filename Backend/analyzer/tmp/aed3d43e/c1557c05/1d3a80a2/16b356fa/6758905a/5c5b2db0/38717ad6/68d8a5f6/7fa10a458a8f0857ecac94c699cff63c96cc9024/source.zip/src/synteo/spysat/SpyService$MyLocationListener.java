	final synthetic synteo.spysat.SpyService this$0
	
	    private SpyService$MyLocationListener(synteo.spysat.SpyService p1)
	    {
	        this.this$0 = p1;
	        return;
	    }
	
	
	    synthetic SpyService$MyLocationListener(synteo.spysat.SpyService p1, synteo.spysat.SpyService$MyLocationListener p2)
	    {
	        this(p1);
	        return;
	    }
	
	
	    public void onLocationChanged(android.location.Location p8)
	    {
	        if (p8 != null) {
	            synteo.spysat.SpyService.access$0(this.this$0).lon = p8.getLongitude();
	            synteo.spysat.SpyService.access$0(this.this$0).lat = p8.getLatitude();
	            synteo.spysat.SpyService.access$0(this.this$0).hasData = 1;
	            synteo.spysat.SpyService.access$0(this.this$0).alt = ((int) p8.getAltitude());
	            synteo.spysat.SpyService.access$0(this.this$0).spd = ((int) ((3600.0 * ((double) p8.getSpeed())) / 1000.0));
	        }
	        return;
	    }
	
	
	    public void onProviderDisabled(String p1)
	    {
	        return;
	    }
	
	
	    public void onProviderEnabled(String p1)
	    {
	        return;
	    }
	
	
	    public void onStatusChanged(String p1, int p2, android.os.Bundle p3)
	    {
	        return;
	    }
	
