	
	    public am(int p10, float p11, int p12, float p13, int p14, float p15, int p16, float p17)
	    {
	        this(0, p11, 0, p13, 0, p15, 0, p17);
	        return;
	    }
	
	
	    protected final void applyTransformation(float p5, android.view.animation.Transformation p6)
	    {
	        if ((((double) p5) >= 0) || (((double) p5) <= 1.0)) {
	            super.applyTransformation(p5, p6);
	        }
	        return;
	    }
	
