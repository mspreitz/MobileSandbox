	public com.admob.android.ads.r a
	public java.util.Vector b
	private com.admob.android.ads.u c
	private android.widget.PopupWindow d
	
	    public q()
	    {
	        this.a = new com.admob.android.ads.r();
	        this.b = new java.util.Vector();
	        this.c = new com.admob.android.ads.u(this);
	        this.d = 0;
	        return;
	    }
	
	
	    private static android.os.Bundle a(org.json.JSONObject p4)
	    {
	        android.os.Bundle v0_0 = 0;
	        if (p4 != null) {
	            android.os.Bundle v2_1;
	            java.util.Iterator v1 = p4.keys();
	            if (!v1.hasNext()) {
	                v2_1 = 0;
	            } else {
	                v2_1 = new android.os.Bundle();
	            }
	            while (v1.hasNext()) {
	                android.os.Bundle v0_5 = ((String) v1.next());
	                Object v3 = p4.opt(v0_5);
	                if ((v0_5 != null) && (v3 != null)) {
	                    com.admob.android.ads.q.a(v2_1, v0_5, v3);
	                }
	            }
	            v0_0 = v2_1;
	        }
	        return v0_0;
	    }
	
	
	    private void a(android.content.Context p5)
	    {
	        String v0_0 = p5.getPackageManager();
	        java.util.Iterator v1_1 = this.b.iterator();
	        while (v1_1.hasNext()) {
	            android.content.Intent v4_2 = ((android.content.Intent) v1_1.next());
	            if (v0_0.resolveActivity(v4_2, 65536) != null) {
	                try {
	                    p5.startActivity(v4_2);
	                } catch (Exception v2) {
	                }
	            }
	            return;
	        }
	        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	            android.util.Log.e("AdMobSDK", "Could not find a resolving intent on ad click");
	        }
	        return;
	    }
	
	
	    private void a(android.content.Context p2, String p3)
	    {
	        this.a(this.b(p2, p3));
	        return;
	    }
	
	
	    private void a(android.content.Intent p2)
	    {
	        if (p2 != null) {
	            this.b.add(p2);
	        }
	        return;
	    }
	
	
	    private static void a(android.os.Bundle p7, String p8, Object p9)
	    {
	        if ((p8 != null) && (p9 != null)) {
	            if (!(p9 instanceof String)) {
	                if (!(p9 instanceof Integer)) {
	                    if (!(p9 instanceof Boolean)) {
	                        if (!(p9 instanceof Double)) {
	                            if (!(p9 instanceof Long)) {
	                                if (!(p9 instanceof org.json.JSONObject)) {
	                                    if (((p9 instanceof org.json.JSONArray)) && ((p8 != null) && (((org.json.JSONArray) p9) != null))) {
	                                        Long[] v0_8 = new java.util.Vector();
	                                        long[] v1_0 = ((org.json.JSONArray) p9).length();
	                                        int v2_0 = 0;
	                                        while (v2_0 < v1_0) {
	                                            try {
	                                                v0_8.add(((org.json.JSONArray) p9).get(v2_0));
	                                                v2_0++;
	                                            } catch (int v2) {
	                                                if (!com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                                                    break;
	                                                }
	                                                android.util.Log.e("AdMobSDK", "couldn\'t read bundle array while adding extras");
	                                                break;
	                                            }
	                                        }
	                                        if (v1_0 != null) {
	                                            try {
	                                                long[] v1_2 = v0_8.get(0);
	                                            } catch (Long[] v0) {
	                                                if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                                                    android.util.Log.e("AdMobSDK", "Couldn\'t read in array when making extras");
	                                                }
	                                            }
	                                            if (!(v1_2 instanceof String)) {
	                                                if (!(v1_2 instanceof Integer)) {
	                                                    if (!(v1_2 instanceof Boolean)) {
	                                                        if (!(v1_2 instanceof Double)) {
	                                                            if ((v1_2 instanceof Long)) {
	                                                                long[] v1_5 = new Long[0];
	                                                                Long[] v0_10 = ((Long[]) v0_8.toArray(v1_5));
	                                                                long[] v1_7 = new long[v0_10.length];
	                                                                int v2_7 = 0;
	                                                                while (v2_7 < v1_7.length) {
	                                                                    v1_7[v2_7] = v0_10[v2_7].longValue();
	                                                                    v2_7++;
	                                                                }
	                                                                p7.putLongArray(p8, v1_7);
	                                                            }
	                                                        } else {
	                                                            long[] v1_9 = new Double[0];
	                                                            Long[] v0_12 = ((Double[]) v0_8.toArray(v1_9));
	                                                            long[] v1_11 = new double[v0_12.length];
	                                                            int v2_8 = 0;
	                                                            while (v2_8 < v1_11.length) {
	                                                                v1_11[v2_8] = v0_12[v2_8].doubleValue();
	                                                                v2_8++;
	                                                            }
	                                                            p7.putDoubleArray(p8, v1_11);
	                                                        }
	                                                    } else {
	                                                        long[] v1_13 = new Boolean[0];
	                                                        Long[] v0_14 = ((Boolean[]) v0_8.toArray(v1_13));
	                                                        long[] v1_15 = new boolean[v0_14.length];
	                                                        int v2_9 = 0;
	                                                        while (v2_9 < v1_15.length) {
	                                                            v1_15[v2_9] = v0_14[v2_9].booleanValue();
	                                                            v2_9++;
	                                                        }
	                                                        p7.putBooleanArray(p8, v1_15);
	                                                    }
	                                                } else {
	                                                    long[] v1_17 = new Integer[0];
	                                                    Long[] v0_16 = ((Integer[]) v0_8.toArray(v1_17));
	                                                    long[] v1_19 = new int[v0_16.length];
	                                                    int v2_10 = 0;
	                                                    while (v2_10 < v0_16.length) {
	                                                        v1_19[v2_10] = v0_16[v2_10].intValue();
	                                                        v2_10++;
	                                                    }
	                                                    p7.putIntArray(p8, v1_19);
	                                                }
	                                            } else {
	                                                long[] v1_21 = new String[0];
	                                                p7.putStringArray(p8, ((String[]) v0_8.toArray(v1_21)));
	                                            }
	                                        }
	                                    }
	                                } else {
	                                    p7.putBundle(p8, com.admob.android.ads.q.a(((org.json.JSONObject) p9)));
	                                }
	                            } else {
	                                p7.putLong(p8, ((Long) p9).longValue());
	                            }
	                        } else {
	                            p7.putDouble(p8, ((Double) p9).doubleValue());
	                        }
	                    } else {
	                        p7.putBoolean(p8, ((Boolean) p9).booleanValue());
	                    }
	                } else {
	                    p7.putInt(p8, ((Integer) p9).intValue());
	                }
	            } else {
	                p7.putString(p8, ((String) p9));
	            }
	        }
	        return;
	    }
	
	
	    private void a(String p2)
	    {
	        this.a.d = p2;
	        return;
	    }
	
	
	    public static void a(java.util.List p5, org.json.JSONObject p6, String p7)
	    {
	        if (p5 != null) {
	            java.util.Iterator v0 = p5.iterator();
	            while (v0.hasNext()) {
	                com.admob.android.ads.w v5_2 = ((com.admob.android.ads.w) v0.next());
	                com.admob.android.ads.e v1_2 = new com.admob.android.ads.q$1();
	                org.json.JSONObject v2 = 0;
	                if (v5_2.b) {
	                    v2 = p6;
	                }
	                com.admob.android.ads.g.a(v5_2.a, "click_time_tracking", p7, v2, v1_2).f();
	            }
	        }
	        return;
	    }
	
	
	    private static android.content.Intent b(android.content.Context p2)
	    {
	        return new android.content.Intent(p2, com.admob.android.ads.AdMobActivity);
	    }
	
	
	    private android.content.Intent b(android.content.Context p4, String p5)
	    {
	        android.content.Intent v0_0 = 0;
	        android.net.Uri v1_1 = this.a.a;
	        if (v1_1 != null) {
	            switch (com.admob.android.ads.q$2.a[v1_1.ordinal()]) {
	                case 1:
	                    this.a(p5);
	                    break;
	                case 2:
	                    v0_0 = com.admob.android.ads.q.b(p4);
	                    break;
	                case 3:
	                    if ((this.a.h == null) || (this.a.h.b())) {
	                    } else {
	                        v0_0 = com.admob.android.ads.q.b(p4);
	                    }
	                    break;
	            }
	            v0_0 = new android.content.Intent();
	            v0_0.setAction("android.intent.action.VIEW");
	            v0_0.setData(android.net.Uri.parse(p5));
	        }
	        return v0_0;
	    }
	
	
	    public final void a()
	    {
	        if (this.d != null) {
	            this.d.dismiss();
	            this.d = 0;
	        }
	        return;
	    }
	
	
	    public final void a(android.app.Activity p12, android.view.View p13)
	    {
	        if (this.a.a != com.admob.android.ads.j$a.b) {
	            if (this.c.a()) {
	                this.a(p12);
	            } else {
	                this.c.d = new ref.WeakReference(p12);
	                this.c.b();
	            }
	        } else {
	            com.admob.android.ads.u v1_7 = this.a.d;
	            ref.WeakReference v2_4 = this.a.b;
	            this.d = new android.widget.PopupWindow(p12);
	            int v3_3 = new android.graphics.Rect();
	            p13.getWindowVisibleDisplayFrame(v3_3);
	            int v4_1 = ((double) com.admob.android.ads.k.d());
	            android.widget.RelativeLayout v6_1 = new android.widget.RelativeLayout(p12);
	            v6_1.setGravity(17);
	            com.admob.android.ads.y v7_2 = new com.admob.android.ads.y(p12, v2_4, this);
	            v7_2.setBackgroundColor(-1);
	            v7_2.setId(1);
	            android.widget.RelativeLayout$LayoutParams v5_1 = new android.widget.RelativeLayout$LayoutParams(com.admob.android.ads.j.a(320, v4_1), com.admob.android.ads.j.a(295, v4_1));
	            v5_1.addRule(13);
	            v6_1.addView(v7_2, v5_1);
	            v7_2.a(v1_7);
	            v7_2.loadUrl("http://mm.admob.com/static/android/canvas.html");
	            this.d.setBackgroundDrawable(0);
	            this.d.setFocusable(1);
	            this.d.setClippingEnabled(0);
	            this.d.setWidth(v3_3.width());
	            this.d.setHeight(v3_3.height());
	            this.d.setContentView(v6_1);
	            this.d.showAtLocation(p13.getRootView(), 0, v3_3.left, v3_3.top);
	            com.admob.android.ads.u v1_16 = v6_1.getLayoutParams();
	            if ((v1_16 instanceof android.view.WindowManager$LayoutParams)) {
	                android.view.WindowManager v11_1 = ((android.view.WindowManager$LayoutParams) v1_16);
	                v11_1.flags = (v11_1.flags | 6);
	                v11_1.dimAmount = 1056964608;
	                ((android.view.WindowManager) p12.getSystemService("window")).updateViewLayout(v6_1, v1_16);
	            }
	        }
	        return;
	    }
	
	
	    public final void a(android.content.Context p5, org.json.JSONArray p6)
	    {
	        int v0 = 0;
	        while (v0 < p6.length()) {
	            try {
	                this.a(p5, p6.getJSONObject(v0));
	            } catch (String v1) {
	                if (!com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                } else {
	                    android.util.Log.e("AdMobSDK", new StringBuilder().append("Could not form an intent from ad action response: ").append(p6.toString()).toString());
	                }
	            }
	            v0++;
	        }
	        return;
	    }
	
	
	    public final void a(android.content.Context p7, org.json.JSONObject p8)
	    {
	        if (p8 != null) {
	            android.content.Intent v0_1 = p8.optString("u");
	            if ((v0_1 == null) || (v0_1.equals(""))) {
	                android.content.Intent v0_3 = p8.optString("a", "android.intent.action.VIEW");
	                android.net.Uri v1_4 = p8.optString("d", 0);
	                if (this.a.d == null) {
	                    this.a(v1_4);
	                }
	                android.content.Intent v0_4;
	                int v2_3 = p8.optInt("f", 0);
	                android.os.Bundle v3_3 = com.admob.android.ads.q.a(p8.optJSONObject("b"));
	                if (this.a.a == null) {
	                    v0_4 = 0;
	                } else {
	                    switch (com.admob.android.ads.q$2.a[this.a.a.ordinal()]) {
	                        case 1:
	                            v0_4 = this.b(p7, v1_4);
	                            break;
	                        default:
	                            android.content.Intent v4_5 = new android.content.Intent(v0_3, android.net.Uri.parse(v1_4));
	                            if (v2_3 != 0) {
	                                v4_5.addFlags(v2_3);
	                            }
	                            if (v3_3 != null) {
	                                v4_5.putExtras(v3_3);
	                            }
	                            v0_4 = v4_5;
	                    }
	                }
	                this.a(v0_4);
	            } else {
	                this.a(p7, v0_1);
	            }
	        }
	        return;
	    }
	
	
	    public final void a(android.content.Context p5, org.json.JSONObject p6, com.admob.android.ads.u p7)
	    {
	        String v0_0;
	        if (p7 != null) {
	            v0_0 = p7;
	        } else {
	            v0_0 = this.c;
	        }
	        this.a.a(p6, v0_0, com.admob.android.ads.AdManager.getUserId(p5));
	        this.a.d = p6.optString("u");
	        String v0_3 = p6.optJSONArray("ua");
	        int v1_3 = p6.optJSONObject("ac");
	        String v2_1 = p6.optJSONArray("ac");
	        if (v2_1 == null) {
	            if (v1_3 == 0) {
	                if (v0_3 == null) {
	                    if ((this.a.d != null) && (this.a.d.length() > 0)) {
	                        this.a(p5, this.a.d);
	                    }
	                } else {
	                    int v1_4 = 0;
	                    while (v1_4 < v0_3.length()) {
	                        String v2_3 = v0_3.optString(v1_4);
	                        if (v2_3 != null) {
	                            this.a(p5, v2_3);
	                        }
	                        v1_4++;
	                    }
	                }
	            } else {
	                this.a(p5, v1_3);
	            }
	        } else {
	            this.a(p5, v2_1);
	        }
	        return;
	    }
	
	
	    public final void a(java.util.Hashtable p5)
	    {
	        if (this.a != null) {
	            com.admob.android.ads.r v1 = this.a;
	            if (p5 != null) {
	                java.util.Iterator v2 = p5.keySet().iterator();
	                while (v2.hasNext()) {
	                    String v4_2 = ((String) v2.next());
	                    v1.k.putParcelable(v4_2, ((android.os.Parcelable) p5.get(v4_2)));
	                }
	            }
	        }
	        return;
	    }
	
	
	    public final void b()
	    {
	        if ((this.a != null) && (this.c())) {
	            android.content.Intent v0_2 = 0;
	            if (this.b.size() > 0) {
	                v0_2 = ((android.content.Intent) this.b.firstElement());
	            }
	            if (v0_2 != null) {
	                v0_2.putExtra("o", this.a.a());
	            }
	        }
	        return;
	    }
	
	
	    public final boolean c()
	    {
	        if ((this.a == null) || (((this.a.a != com.admob.android.ads.j$a.c) || ((this.a.h == null) || (this.a.h.b()))) && (this.a.a != com.admob.android.ads.j$a.d))) {
	            int v0_10 = 0;
	        } else {
	            v0_10 = 1;
	        }
	        return v0_10;
	    }
	
	
	    public final void k()
	    {
	        int v0_3;
	        this.a(this.c.a);
	        this.b();
	        int v0_2 = this.c;
	        if (v0_2.d == null) {
	            v0_3 = 0;
	        } else {
	            v0_3 = ((android.content.Context) v0_2.d.get());
	        }
	        if (v0_3 != 0) {
	            this.a(v0_3);
	        }
	        return;
	    }
	
	
	    public final void l()
	    {
	        return;
	    }
	
