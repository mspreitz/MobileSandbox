	public java.util.Hashtable a
	public java.util.HashSet b
	public com.admob.android.ads.s c
	public java.lang.ref.WeakReference d
	private com.admob.android.ads.u$a e
	
	    public u(com.admob.android.ads.u$a p3)
	    {
	        this.a = new java.util.Hashtable();
	        this.b = new java.util.HashSet();
	        this.c = 0;
	        this.e = p3;
	        this.d = 0;
	        return;
	    }
	
	
	    private void a(String p3, String p4, String p5, boolean p6)
	    {
	        com.admob.android.ads.e v0 = com.admob.android.ads.g.a(p3, p4, p5, this);
	        if (p6) {
	            v0.a(Boolean.valueOf(1));
	        }
	        this.b.add(v0);
	        return;
	    }
	
	
	    public final void a(com.admob.android.ads.e p9)
	    {
	        Throwable v1_0 = p9.b();
	        com.admob.android.ads.u$a v0_0 = p9.a();
	        if (v0_0 == null) {
	            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                android.util.Log.d("AdMobSDK", new StringBuilder().append("Failed reading asset(").append(v1_0).append(") for ad").toString());
	            }
	            this.c();
	        } else {
	            try {
	                String v2 = android.graphics.BitmapFactory.decodeByteArray(v0_0, 0, v0_0.length);
	            } catch (com.admob.android.ads.u$a v0_9) {
	                if (!com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                } else {
	                    android.util.Log.e("AdMobSDK", "couldn\'t create a Bitmap", v0_9);
	                }
	            }
	            if (v2 == null) {
	                if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                    android.util.Log.d("AdMobSDK", new StringBuilder().append("Failed reading asset(").append(v1_0).append(") as a bitmap.").toString());
	                }
	                this.c();
	            } else {
	                com.admob.android.ads.u$a v0_17 = p9.g();
	                if (((v0_17 instanceof Boolean)) && (((Boolean) v0_17).booleanValue())) {
	                    this.c.a(v1_0, v2);
	                }
	                this.a.put(v1_0, v2);
	                if (this.b != null) {
	                    try {
	                        this.b.remove(p9);
	                    } catch (Throwable v1_4) {
	                        throw v1_4;
	                    }
	                    if ((this.a()) && (this.e != null)) {
	                        this.e.k();
	                    }
	                }
	            }
	        }
	        return;
	    }
	
	
	    public final void a(com.admob.android.ads.e p9, Exception p10)
	    {
	        if (p10 == null) {
	            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                String v0_1;
	                StringBuilder v1_1;
	                if (p9 == null) {
	                    v0_1 = 0;
	                    v1_1 = 0;
	                } else {
	                    String v0_2 = p9.b();
	                    StringBuilder v1_2 = p9.c();
	                    if (v1_2 == null) {
	                        v1_1 = v0_2;
	                        v0_1 = 0;
	                    } else {
	                        v1_1 = v0_2;
	                        v0_1 = v1_2.toString();
	                    }
	                }
	                android.util.Log.d("AdMobSDK", new StringBuilder().append("Failed downloading assets for ad: ").append(v1_1).append(" ").append(v0_1).toString());
	            }
	        } else {
	            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                String v0_6;
	                StringBuilder v1_6;
	                if (p9 == null) {
	                    v0_6 = 0;
	                    v1_6 = 0;
	                } else {
	                    String v0_7 = p9.b();
	                    StringBuilder v1_7 = p9.c();
	                    if (v1_7 == null) {
	                        v1_6 = v0_7;
	                        v0_6 = 0;
	                    } else {
	                        v1_6 = v0_7;
	                        v0_6 = v1_7.toString();
	                    }
	                }
	                android.util.Log.d("AdMobSDK", new StringBuilder().append("Failed downloading assets for ad: ").append(v1_6).append(" ").append(v0_6).toString(), p10);
	            }
	        }
	        this.c();
	        return;
	    }
	
	
	    public final void a(org.json.JSONObject p10, String p11)
	    {
	        if (this.b != null) {
	            try {
	                if (p10 != null) {
	                    java.util.Iterator v2 = p10.keys();
	                    while (v2.hasNext()) {
	                        int v3_2;
	                        String v0_3 = ((String) v2.next());
	                        int v3_0 = p10.getJSONObject(v0_3);
	                        java.util.Hashtable v4_1 = v3_0.getString("u");
	                        if (v3_0.optInt("c", 0) != 1) {
	                            v3_2 = 0;
	                        } else {
	                            v3_2 = 1;
	                        }
	                        if ((v3_2 == 0) || (this.c == null)) {
	                            this.a(v4_1, v0_3, p11, 0);
	                        } else {
	                            int v3_6 = this.c.a(v0_3);
	                            if (v3_6 == 0) {
	                                this.a(v4_1, v0_3, p11, 1);
	                            } else {
	                                this.a.put(v0_3, v3_6);
	                            }
	                        }
	                    }
	                }
	            } catch (String v0_4) {
	                throw v0_4;
	            }
	        }
	        return;
	    }
	
	
	    public final boolean a()
	    {
	        if ((this.b != null) && (this.b.size() != 0)) {
	            int v0_3 = 0;
	        } else {
	            v0_3 = 1;
	        }
	        return v0_3;
	    }
	
	
	    public final void b()
	    {
	        if (this.b != null) {
	            try {
	                Throwable v1_1 = this.b.iterator();
	            } catch (Throwable v1_2) {
	                throw v1_2;
	            }
	            while (v1_1.hasNext()) {
	                ((com.admob.android.ads.e) v1_1.next()).f();
	            }
	        }
	        return;
	    }
	
	
	    public final void c()
	    {
	        if (this.b != null) {
	            try {
	                java.util.Iterator v2 = this.b.iterator();
	            } catch (int v0_5) {
	                throw v0_5;
	            }
	            while (v2.hasNext()) {
	                ((com.admob.android.ads.e) v2.next()).e();
	            }
	            this.b.clear();
	            this.b = 0;
	        }
	        this.d();
	        if (this.e != null) {
	            this.e.l();
	        }
	        return;
	    }
	
	
	    public final void d()
	    {
	        if (this.a != null) {
	            this.a.clear();
	            this.a = 0;
	        }
	        return;
	    }
	
