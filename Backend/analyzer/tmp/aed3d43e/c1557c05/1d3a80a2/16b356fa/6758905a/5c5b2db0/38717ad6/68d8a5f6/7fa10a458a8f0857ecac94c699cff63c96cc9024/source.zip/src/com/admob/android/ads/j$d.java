	private java.lang.ref.WeakReference a
	private org.json.JSONArray b
	
	    public j$d(com.admob.android.ads.j p2, org.json.JSONArray p3)
	    {
	        this.a = new ref.WeakReference(p2);
	        this.b = p3;
	        return;
	    }
	
	
	    public final void run()
	    {
	        try {
	            ref.WeakReference v0_2 = ((com.admob.android.ads.j) this.a.get());
	        } catch (ref.WeakReference v0_3) {
	            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                android.util.Log.e("AdMobSDK", new StringBuilder().append("exception caught in Ad$ViewAdd.run(), ").append(v0_3.getMessage()).toString());
	                v0_3.printStackTrace();
	            }
	            com.admob.android.ads.j v4_2 = ((com.admob.android.ads.j) this.a.get());
	            if (v4_2 == null) {
	                return;
	            } else {
	                com.admob.android.ads.j.a(v4_2);
	                return;
	            }
	        }
	        if (v0_2 == null) {
	            return;
	        } else {
	            com.admob.android.ads.j.a(v0_2, this.b);
	            return;
	        }
	    }
	
