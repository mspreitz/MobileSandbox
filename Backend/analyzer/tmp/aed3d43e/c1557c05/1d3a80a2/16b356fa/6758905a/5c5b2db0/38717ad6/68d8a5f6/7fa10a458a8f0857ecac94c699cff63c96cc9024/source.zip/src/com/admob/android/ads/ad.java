	private java.lang.ref.WeakReference a
	private com.admob.android.ads.ag b
	private java.util.Map c
	protected java.lang.ref.WeakReference d
	
	    public ad(com.admob.android.ads.view.AdMobWebView p2)
	    {
	        this(p2, 0);
	        return;
	    }
	
	
	    public ad(com.admob.android.ads.view.AdMobWebView p4, ref.WeakReference p5)
	    {
	        this.d = new ref.WeakReference(p4);
	        this.a = p5;
	        this.b = new com.admob.android.ads.ag(((android.app.Activity) p5.get()), this.d);
	        this.c = 0;
	        p4.addJavascriptInterface(this.b, "JsProxy");
	        return;
	    }
	
	
	    public static java.util.Hashtable a(String p5)
	    {
	        java.util.Hashtable v0_0 = 0;
	        if (p5 != null) {
	            v0_0 = new java.util.Hashtable();
	            java.util.StringTokenizer v1_1 = new java.util.StringTokenizer(p5, "&");
	            while (v1_1.hasMoreTokens()) {
	                String v2_2 = v1_1.nextToken();
	                int v3_1 = v2_2.indexOf(61);
	                if (v3_1 != -1) {
	                    String v4_2 = v2_2.substring(0, v3_1);
	                    String v2_3 = v2_2.substring((v3_1 + 1));
	                    if ((v4_2 != null) && (v2_3 != null)) {
	                        v0_0.put(v4_2, v2_3);
	                    }
	                }
	            }
	        }
	        return v0_0;
	    }
	
	
	    public void onPageFinished(android.webkit.WebView p6, String p7)
	    {
	        String v0_2 = ((com.admob.android.ads.view.AdMobWebView) this.d.get());
	        if (v0_2 != null) {
	            if ((p7 != null) && (p7.equals(v0_2.c))) {
	                if (this.c == null) {
	                    this.c = new java.util.HashMap();
	                    String v1_5 = v0_2.getContext();
	                    this.c.put("sdkVersion", "20101109-ANDROID-3312276cc1406347");
	                    this.c.put("ua", com.admob.android.ads.f.h());
	                    this.c.put("portrait", com.admob.android.ads.AdManager.getOrientation(v1_5));
	                    this.c.put("width", String.valueOf(v0_2.getWidth()));
	                    this.c.put("height", String.valueOf(v0_2.getHeight()));
	                    this.c.put("isu", com.admob.android.ads.AdManager.getUserId(v1_5));
	                }
	                Object[] v2_8 = new Object[2];
	                v2_8[0] = "loaded";
	                v2_8[1] = this.c;
	                v0_2.a("onEvent", v2_8);
	            } else {
	                if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 4)) {
	                    android.util.Log.i("AdMobSDK", new StringBuilder().append("Unexpected page loaded, urlThatFinished: ").append(p7).toString());
	                }
	            }
	        }
	        return;
	    }
	
	
	    public boolean shouldOverrideUrlLoading(android.webkit.WebView p9, String p10)
	    {
	        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 2)) {
	            android.util.Log.v("AdMobSDK", new StringBuilder().append("shouldOverrideUrlLoading, url: ").append(p10).toString());
	        }
	        int v0_15;
	        int v0_9 = ((com.admob.android.ads.view.AdMobWebView) this.d.get());
	        if (v0_9 != 0) {
	            String v1_1 = v0_9.getContext();
	            try {
	                String v2_1 = new java.net.URI(p10);
	            } catch (int v0_26) {
	                android.util.Log.w("AdMobSDK", "Bad link URL in AdMob web view.", v0_26);
	                v0_15 = 0;
	            }
	            if (!"admob".equals(v2_1.getScheme())) {
	            } else {
	                String v3_2 = v2_1.getHost();
	                if (!"launch".equals(v3_2)) {
	                    if (!"open".equals(v3_2)) {
	                        if (!"closecanvas".equals(v3_2)) {
	                            if (!"log".equals(v3_2)) {
	                                if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                                    android.util.Log.d("AdMobSDK", new StringBuilder().append("Received message from JS but didn\'t know how to handle: ").append(p10).toString());
	                                }
	                                v0_15 = 1;
	                            } else {
	                                int v0_16 = v2_1.getQuery();
	                                if (v0_16 == 0) {
	                                } else {
	                                    int v0_17 = com.admob.android.ads.ad.a(v0_16);
	                                    if (v0_17 == 0) {
	                                    } else {
	                                        String v8_2 = ((String) v0_17.get("string"));
	                                        if (v8_2 == null) {
	                                        } else {
	                                            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                                                android.util.Log.d("AdMobSDK", new StringBuilder().append("<AdMob:WebView>: ").append(v8_2).toString());
	                                            }
	                                            v0_15 = 1;
	                                        }
	                                    }
	                                }
	                            }
	                        } else {
	                            if (p9 != v0_9) {
	                            } else {
	                                v0_9.a();
	                                v0_15 = 1;
	                            }
	                        }
	                    } else {
	                        String v1_19 = v2_1.getQuery();
	                        if (v1_19 == null) {
	                        } else {
	                            String v1_20 = com.admob.android.ads.ad.a(v1_19);
	                            if (v1_20 == null) {
	                            } else {
	                                String v8_4 = ((String) v1_20.get("vars"));
	                                if (v8_4 == null) {
	                                } else {
	                                    v0_9.loadUrl(new StringBuilder().append("javascript: JsProxy.setDataAndOpen(").append(v8_4).append(")").toString());
	                                    v0_15 = 1;
	                                }
	                            }
	                        }
	                    }
	                } else {
	                    int v0_21 = v2_1.getQuery();
	                    if (v0_21 == 0) {
	                    } else {
	                        int v0_22 = com.admob.android.ads.ad.a(v0_21);
	                        if (v0_22 == 0) {
	                        } else {
	                            int v0_24 = ((String) v0_22.get("url"));
	                            if (v0_24 == 0) {
	                            } else {
	                                if (!(v1_1 instanceof android.app.Activity)) {
	                                    v1_1 = ((android.content.Context) this.a.get());
	                                }
	                                if (v1_1 != null) {
	                                    v1_1.startActivity(new android.content.Intent("android.intent.action.VIEW", android.net.Uri.parse(v0_24)));
	                                }
	                                v0_15 = 1;
	                            }
	                        }
	                    }
	                }
	            }
	        } else {
	            v0_15 = 0;
	        }
	        return v0_15;
	    }
	
