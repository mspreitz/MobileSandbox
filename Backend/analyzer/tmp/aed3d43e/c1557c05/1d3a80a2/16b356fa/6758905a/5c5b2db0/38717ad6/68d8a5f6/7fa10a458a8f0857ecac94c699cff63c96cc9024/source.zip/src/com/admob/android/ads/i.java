	private java.net.HttpURLConnection m
	private java.net.URL n
	
	    public i(String p9, String p10, String p11, com.admob.android.ads.h p12, int p13, java.util.Map p14, String p15)
	    {
	        this(p10, p11, p12, p13, p14, p15);
	        try {
	            this.n = new java.net.URL(p9);
	            this.i = this.n;
	        } catch (int v0_4) {
	            this.n = 0;
	            this.c = v0_4;
	        }
	        this.m = 0;
	        this.e = 0;
	        return;
	    }
	
	
	    private void i()
	    {
	        if (this.m != null) {
	            this.m.disconnect();
	            this.m = 0;
	        }
	        return;
	    }
	
	
	    public final boolean d()
	    {
	        Exception v1_2;
	        if (this.n != null) {
	            byte[] v3_0 = 0;
	            while ((this.e < this.f) && (v3_0 == null)) {
	                if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 2)) {
	                    android.util.Log.v("AdMobSDK", new StringBuilder().append("attempt ").append(this.e).append(" to connect to url ").append(this.n).toString());
	                }
	                try {
	                    byte[] v2_7;
	                    this.i();
	                    this.m = ((java.net.HttpURLConnection) this.n.openConnection());
	                    this.m.setUseCaches(1);
	                    this.m.setInstanceFollowRedirects(1);
	                } catch (Exception v1_39) {
	                    byte[] v2_18 = 0;
	                    if (v2_18 != null) {
	                        try {
	                            v2_18.close();
	                        } catch (byte[] v2) {
	                        }
	                    }
	                    this.i();
	                    throw v1_39;
	                } catch (Exception v1_38) {
	                    v2_18 = 0;
	                    if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                        android.util.Log.d("AdMobSDK", new StringBuilder().append("connection attempt ").append(this.e).append(" failed, url ").append(this.n).toString());
	                    }
	                    if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 2)) {
	                        android.util.Log.v("AdMobSDK", "exception: ", v1_38);
	                    }
	                    this.c = v1_38;
	                    if (v2_18 != null) {
	                        try {
	                            v2_18.close();
	                        } catch (Exception v1) {
	                        }
	                    }
	                    this.i();
	                    Exception v1_40 = 0;
	                    this.e = (this.e + 1);
	                    v3_0 = v1_40;
	                } catch (Exception v1_39) {
	                }
	                if (this.m == null) {
	                    v2_7 = v3_0;
	                } else {
	                    this.m.setRequestProperty("User-Agent", com.admob.android.ads.i.h());
	                    if (this.g != null) {
	                        this.m.setRequestProperty("X-ADMOB-ISU", this.g);
	                    }
	                    this.m.setConnectTimeout(this.b);
	                    this.m.setReadTimeout(this.b);
	                    this.m.setUseCaches(0);
	                    if (this.d != null) {
	                        int v5_2 = this.d.keySet().iterator();
	                        while (v5_2.hasNext()) {
	                            byte[] v2_33 = ((String) v5_2.next());
	                            if (v2_33 != null) {
	                                Exception v1_44 = ((String) this.d.get(v2_33));
	                                if (v1_44 != null) {
	                                    this.m.addRequestProperty(v2_33, v1_44);
	                                }
	                            }
	                        }
	                    }
	                    Exception v1_29;
	                    if (this.l == null) {
	                        this.m.connect();
	                        v1_29 = 0;
	                    } else {
	                        this.m.setRequestMethod("POST");
	                        this.m.setDoOutput(1);
	                        this.m.setRequestProperty("Content-Type", this.a);
	                        this.m.setRequestProperty("Content-Length", Integer.toString(this.l.length()));
	                        v2_18 = new java.io.BufferedWriter(new java.io.OutputStreamWriter(this.m.getOutputStream()), 4096);
	                        try {
	                            v2_18.write(this.l);
	                            v2_18.close();
	                            v1_29 = 0;
	                        } catch (Exception v1_38) {
	                        }
	                    }
	                    try {
	                        byte[] v2_20 = this.m.getResponseCode();
	                    } catch (byte[] v2_32) {
	                        v2_18 = v1_29;
	                        v1_39 = v2_32;
	                    } catch (byte[] v2_31) {
	                        v2_18 = v1_29;
	                        v1_38 = v2_31;
	                    }
	                    if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 2)) {
	                        java.net.URL v4_4 = this.m.getHeaderField("X-AdMob-AdSrc");
	                        if (v4_4 != null) {
	                            android.util.Log.v("AdMobSDK", new StringBuilder().append("Ad response came from server ").append(v4_4).toString());
	                        }
	                    }
	                    if ((v2_20 < 200) || (v2_20 >= 300)) {
	                        if (v2_20 != 302) {
	                            v2_7 = v3_0;
	                        } else {
	                            byte[] v2_22 = this.m.getHeaderField("Location");
	                            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                                android.util.Log.d("AdMobSDK", new StringBuilder().append("Got redirectUrl: ").append(v2_22).toString());
	                            }
	                            this.n = new java.net.URL(v2_22);
	                            this.i();
	                        }
	                    } else {
	                        this.i = this.m.getURL();
	                        if (this.k) {
	                            byte[] v2_27 = new java.io.BufferedInputStream(this.m.getInputStream(), 4096);
	                            byte[] v3_4 = new byte[4096];
	                            java.net.URL v4_18 = new java.io.ByteArrayOutputStream(4096);
	                            while(true) {
	                                int v5_19 = v2_27.read(v3_4);
	                                if (v5_19 == -1) {
	                                    break;
	                                }
	                                v4_18.write(v3_4, 0, v5_19);
	                            }
	                            this.j = v4_18.toByteArray();
	                        }
	                        if (this.h != null) {
	                            this.h.a(this);
	                        }
	                        v2_7 = 1;
	                    }
	                }
	                this.i();
	                this.i();
	                v1_40 = v2_7;
	            }
	            v1_2 = v3_0;
	        } else {
	            if (this.h != null) {
	                this.h.a(this, new Exception("url was null"));
	            }
	            v1_2 = 0;
	        }
	        if ((v1_2 == null) && (this.h != null)) {
	            this.h.a(this, this.c);
	        }
	        return v1_2;
	    }
	
	
	    public final void e()
	    {
	        this.i();
	        this.h = 0;
	        return;
	    }
	
	
	    public final void run()
	    {
	        try {
	            this.d();
	        } catch (com.admob.android.ads.h v0_0) {
	            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                android.util.Log.e("AdMobSDK", new StringBuilder().append("exception caught in AdMobURLConnector.run(), ").append(v0_0.getMessage()).toString());
	            }
	            if (this.h == null) {
	            } else {
	                this.h.a(this, this.c);
	            }
	        }
	        return;
	    }
	
