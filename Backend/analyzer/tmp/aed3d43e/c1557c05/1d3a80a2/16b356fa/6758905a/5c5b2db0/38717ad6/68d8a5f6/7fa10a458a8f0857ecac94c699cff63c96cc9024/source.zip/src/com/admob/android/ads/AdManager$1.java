	private synthetic android.location.LocationManager a
	
	    AdManager$1(android.location.LocationManager p1)
	    {
	        this.a = p1;
	        return;
	    }
	
	
	    public final void onLocationChanged(android.location.Location p6)
	    {
	        com.admob.android.ads.AdManager.a(p6);
	        com.admob.android.ads.AdManager.a(System.currentTimeMillis());
	        this.a.removeUpdates(this);
	        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	            android.util.Log.d("AdMobSDK", new StringBuilder().append("Acquired location ").append(com.admob.android.ads.AdManager.d().getLatitude()).append(",").append(com.admob.android.ads.AdManager.d().getLongitude()).append(" at ").append(new java.util.Date(com.admob.android.ads.AdManager.e()).toString()).append(".").toString());
	        }
	        return;
	    }
	
	
	    public final void onProviderDisabled(String p1)
	    {
	        return;
	    }
	
	
	    public final void onProviderEnabled(String p1)
	    {
	        return;
	    }
	
	
	    public final void onStatusChanged(String p1, int p2, android.os.Bundle p3)
	    {
	        return;
	    }
	
