	private java.lang.ref.WeakReference a
	
	    public ac$c(com.admob.android.ads.ac p2)
	    {
	        this.a = new ref.WeakReference(p2);
	        return;
	    }
	
	
	    public final void run()
	    {
	        com.admob.android.ads.ac v2_2 = ((com.admob.android.ads.ac) this.a.get());
	        if ((v2_2 != null) && ((v2_2.e()) && ((v2_2.g == 2) && (v2_2.k != null)))) {
	            v2_2.k.a();
	        }
	        return;
	    }
	
