	private synthetic com.admob.android.ads.y a
	
	    public y$a(com.admob.android.ads.y p1, com.admob.android.ads.y p2, ref.WeakReference p3)
	    {
	        this.a = p1;
	        this(p2, p3);
	        return;
	    }
	
	
	    public final void onPageFinished(android.webkit.WebView p4, String p5)
	    {
	        if (("http://mm.admob.com/static/android/canvas.html".equals(p5)) && (this.a.b)) {
	            String v0_5 = new StringBuilder();
	            v0_5.append("javascript:cb(\'");
	            v0_5.append(this.a.c);
	            v0_5.append("\',\'");
	            v0_5.append(this.a.a);
	            v0_5.append("\')");
	            this.a.b = 0;
	            this.a.loadUrl(v0_5.toString());
	        }
	        return;
	    }
	
