	public  a
	public android.graphics.PointF b
	
	    public ah()
	    {
	        this.a = 0;
	        this.b = new android.graphics.PointF(1056964608, 1056964608);
	        return;
	    }
	
	
	    public static float a(android.view.View p1)
	    {
	        int v0_0;
	        if (p1 == null) {
	            v0_0 = 0;
	        } else {
	            v0_0 = com.admob.android.ads.ah.c(p1).a;
	        }
	        return v0_0;
	    }
	
	
	    public static android.graphics.PointF b(android.view.View p1)
	    {
	        int v0_0;
	        if (p1 == null) {
	            v0_0 = 0;
	        } else {
	            v0_0 = com.admob.android.ads.ah.c(p1).b;
	        }
	        return v0_0;
	    }
	
	
	    public static com.admob.android.ads.ah c(android.view.View p1)
	    {
	        com.admob.android.ads.ah v0_2;
	        com.admob.android.ads.ah v1_1 = p1.getTag();
	        if ((v1_1 == null) || (!(v1_1 instanceof com.admob.android.ads.ah))) {
	            v0_2 = new com.admob.android.ads.ah();
	        } else {
	            v0_2 = ((com.admob.android.ads.ah) v1_1);
	        }
	        return v0_2;
	    }
	
