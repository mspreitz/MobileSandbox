	private java.lang.ref.WeakReference a
	
	    public InterstitialAd$f(com.admob.android.ads.InterstitialAd p2)
	    {
	        this.a = new ref.WeakReference(p2);
	        return;
	    }
	
	
	    public final void run()
	    {
	        com.admob.android.ads.InterstitialAd v1_2 = ((com.admob.android.ads.InterstitialAd) this.a.get());
	        if (v1_2 != null) {
	            com.admob.android.ads.InterstitialAd.a(v1_2);
	        }
	        return;
	    }
	
