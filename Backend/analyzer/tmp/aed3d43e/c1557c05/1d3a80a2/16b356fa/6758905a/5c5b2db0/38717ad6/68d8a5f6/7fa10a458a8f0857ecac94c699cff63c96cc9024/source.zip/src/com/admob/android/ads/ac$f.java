	private java.lang.ref.WeakReference a
	
	    public ac$f(com.admob.android.ads.ac p2)
	    {
	        this.a = new ref.WeakReference(p2);
	        return;
	    }
	
	
	    public final void run()
	    {
	        com.admob.android.ads.ac v2_2 = ((com.admob.android.ads.ac) this.a.get());
	        if ((v2_2 != null) && (v2_2.e != null)) {
	            v2_2.e.setVisibility(0);
	            v2_2.e.requestLayout();
	            v2_2.e.requestFocus();
	            v2_2.e.start();
	        }
	        return;
	    }
	
