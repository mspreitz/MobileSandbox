	public static final com.admob.android.ads.AdView$f a
	private  b
	private  c
	
	    static AdView$f()
	    {
	        com.admob.android.ads.AdView$f.a = new com.admob.android.ads.AdView$f(320, 48);
	        new com.admob.android.ads.AdView$f(320, 270);
	        new com.admob.android.ads.AdView$f(748, 110);
	        new com.admob.android.ads.AdView$f(488, 80);
	        return;
	    }
	
	
	    private AdView$f(int p1, int p2)
	    {
	        this.b = p1;
	        this.c = p2;
	        return;
	    }
	
	
	    public final String toString()
	    {
	        String v0_1 = new StringBuilder();
	        v0_1.append(String.valueOf(this.b));
	        v0_1.append("x");
	        v0_1.append(String.valueOf(this.c));
	        return v0_1.toString();
	    }
	
