	static final synthetic I a
	static final synthetic I b
	
	    static AdMobActivity$1()
	    {
	        NoSuchFieldError v0_2 = new int[com.admob.android.ads.q$a.values().length];
	        com.admob.android.ads.AdMobActivity$1.b = v0_2;
	        try {
	            com.admob.android.ads.AdMobActivity$1.b[com.admob.android.ads.q$a.b.ordinal()] = 1;
	            try {
	                com.admob.android.ads.AdMobActivity$1.b[com.admob.android.ads.q$a.a.ordinal()] = 2;
	                try {
	                    com.admob.android.ads.AdMobActivity$1.b[com.admob.android.ads.q$a.c.ordinal()] = 3;
	                } catch (NoSuchFieldError v0) {
	                }
	                NoSuchFieldError v0_8 = new int[com.admob.android.ads.j$a.values().length];
	                com.admob.android.ads.AdMobActivity$1.a = v0_8;
	                try {
	                    com.admob.android.ads.AdMobActivity$1.a[com.admob.android.ads.j$a.d.ordinal()] = 1;
	                    try {
	                        com.admob.android.ads.AdMobActivity$1.a[com.admob.android.ads.j$a.c.ordinal()] = 2;
	                    } catch (NoSuchFieldError v0) {
	                    }
	                    return;
	                } catch (NoSuchFieldError v0) {
	                }
	            } catch (NoSuchFieldError v0) {
	            }
	        } catch (NoSuchFieldError v0) {
	        }
	    }
	
