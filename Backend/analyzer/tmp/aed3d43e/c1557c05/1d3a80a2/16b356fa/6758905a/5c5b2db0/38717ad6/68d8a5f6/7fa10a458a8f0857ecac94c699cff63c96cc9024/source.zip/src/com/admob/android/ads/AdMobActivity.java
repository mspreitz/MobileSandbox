	private com.admob.android.ads.r a
	private java.util.Vector b
	
	    public AdMobActivity()
	    {
	        return;
	    }
	
	
	    public void finish()
	    {
	        if ((this.a != null) && (this.a.l)) {
	            android.content.Intent v0_4 = new android.content.Intent();
	            v0_4.putExtra("admob_activity", 1);
	            this.setResult(-1, v0_4);
	        }
	        super.finish();
	        return;
	    }
	
	
	    public void onConfigurationChanged(android.content.res.Configuration p3)
	    {
	        java.util.Iterator v1 = this.b.iterator();
	        while (v1.hasNext()) {
	            ((com.admob.android.ads.ae) v1.next()).a(p3);
	        }
	        super.onConfigurationChanged(p3);
	        return;
	    }
	
	
	    protected void onCreate(android.os.Bundle p10)
	    {
	        super.onCreate(p10);
	        this.b = new java.util.Vector();
	        com.admob.android.ads.ac v0_3 = this.getIntent().getBundleExtra("o");
	        int v1_2 = new com.admob.android.ads.r();
	        if (!v1_2.a(v0_3)) {
	            this.a = 0;
	        } else {
	            this.a = v1_2;
	        }
	        if (this.a != null) {
	            com.admob.android.ads.ac v0_14;
	            com.admob.android.ads.q.a(this.a.c, 0, com.admob.android.ads.AdManager.getUserId(this));
	            com.admob.android.ads.ac v0_9 = this.a.a;
	            ref.WeakReference v6_1 = new ref.WeakReference(this);
	            switch (com.admob.android.ads.AdMobActivity$1.a[v0_9.ordinal()]) {
	                case 1:
	                    this.setTheme(16973831);
	                    v0_14 = com.admob.android.ads.view.AdMobWebView.a(this.getApplicationContext(), this.a.d, 0, this.a.f, this.a.g, com.admob.android.ads.k.a(this), v6_1);
	                    break;
	                case 2:
	                    com.admob.android.ads.ac v0_12 = this.a;
	                    int v3_2 = new com.admob.android.ads.ac(this.getApplicationContext(), v6_1);
	                    v3_2.a(v0_12);
	                    this.b.add(v3_2);
	                    v0_14 = v3_2;
	                    break;
	                default:
	                    v0_14 = 0;
	            }
	            if (v0_14 == null) {
	                this.finish();
	            } else {
	                switch (com.admob.android.ads.AdMobActivity$1.b[this.a.e.ordinal()]) {
	                    case 1:
	                        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 2)) {
	                            android.util.Log.v("AdMobSDK", "Setting target orientation to landscape");
	                        }
	                        this.setRequestedOrientation(0);
	                        break;
	                    case 2:
	                        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 2)) {
	                            android.util.Log.v("AdMobSDK", "Setting target orientation to portrait");
	                        }
	                        this.setRequestedOrientation(1);
	                        break;
	                    default:
	                        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 2)) {
	                            android.util.Log.v("AdMobSDK", "Setting target orientation to sensor");
	                        }
	                        this.setRequestedOrientation(4);
	                }
	                this.setContentView(v0_14);
	            }
	        } else {
	            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                android.util.Log.e("AdMobSDK", "Unable to get openerInfo from intent");
	            }
	        }
	        return;
	    }
	
	
	    protected void onDestroy()
	    {
	        this.b.clear();
	        super.onDestroy();
	        return;
	    }
	
