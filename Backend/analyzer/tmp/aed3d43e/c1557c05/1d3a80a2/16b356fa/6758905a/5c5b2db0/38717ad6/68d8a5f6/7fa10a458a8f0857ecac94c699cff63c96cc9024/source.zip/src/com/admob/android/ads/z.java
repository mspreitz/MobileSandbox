	public org.json.JSONObject a
	public org.json.JSONObject b
	private  e
	
	    public z(android.content.Context p3, com.admob.android.ads.j p4)
	    {
	        this(p3, 0, 0);
	        this.a = 0;
	        this.b = 0;
	        this.e = 0;
	        this.d = new com.admob.android.ads.z$a(this, this, p4);
	        this.setWebViewClient(this.d);
	        return;
	    }
	
	
	    public final void b()
	    {
	        if (((this.d instanceof com.admob.android.ads.z$a)) && ((((com.admob.android.ads.z$a) this.d).b) && (!this.e))) {
	            org.json.JSONObject v0_7;
	            this.e = 1;
	            if (this.a != null) {
	                v0_7 = this.a;
	            } else {
	                v0_7 = "null";
	            }
	            org.json.JSONObject v1_1;
	            if (this.b != null) {
	                v1_1 = this.b;
	            } else {
	                v1_1 = "null";
	            }
	            Object[] v3_1 = new Object[2];
	            v3_1[0] = v0_7;
	            v3_1[1] = v1_1;
	            this.a("init", v3_1);
	        }
	        return;
	    }
	
