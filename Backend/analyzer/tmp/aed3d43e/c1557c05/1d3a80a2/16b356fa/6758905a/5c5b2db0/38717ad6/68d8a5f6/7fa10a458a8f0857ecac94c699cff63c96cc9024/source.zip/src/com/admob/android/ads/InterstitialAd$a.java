	  a
	private com.admob.android.ads.InterstitialAd b
	private java.lang.ref.WeakReference c
	
	    public InterstitialAd$a(com.admob.android.ads.InterstitialAd p2, android.content.Context p3)
	    {
	        this.b = p2;
	        this.c = new ref.WeakReference(p3);
	        this.a = 0;
	        return;
	    }
	
	
	    public final void run()
	    {
	        com.admob.android.ads.InterstitialAd v0_2 = ((android.content.Context) this.c.get());
	        if (v0_2 == null) {
	            if (!this.a) {
	                this.b.c();
	            }
	        } else {
	            try {
	                com.admob.android.ads.InterstitialAd v0_5 = com.admob.android.ads.b.a(this.b.f(), v0_2, this.b.getKeywords(), this.b.getSearchQuery(), this.b.e());
	            } catch (com.admob.android.ads.InterstitialAd v0_10) {
	                throw v0_10;
	            } catch (com.admob.android.ads.InterstitialAd v0_7) {
	                if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                    android.util.Log.e("AdMobSDK", "Unhandled exception requesting a fresh ad.", v0_7);
	                }
	                if (!this.a) {
	                    this.b.c();
	                }
	            }
	            if ((!this.a) && (v0_5 == null)) {
	                this.b.c();
	            }
	        }
	        return;
	    }
	
