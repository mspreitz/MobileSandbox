	public static final enum com.admob.android.ads.j$b a
	public static final enum com.admob.android.ads.j$b b
	public static final enum com.admob.android.ads.j$b c
	private static final synthetic Lcom.admob.android.ads.j$b e
	private java.lang.String d
	
	    static j$b()
	    {
	        com.admob.android.ads.j$b.a = new com.admob.android.ads.j$b("VIEW", 0, "view");
	        com.admob.android.ads.j$b.b = new com.admob.android.ads.j$b("INTERSTITIAL", 1, "full_screen");
	        com.admob.android.ads.j$b.c = new com.admob.android.ads.j$b("BAR", 2, "bar");
	        com.admob.android.ads.j$b[] v0_7 = new com.admob.android.ads.j$b[3];
	        v0_7[0] = com.admob.android.ads.j$b.a;
	        v0_7[1] = com.admob.android.ads.j$b.b;
	        v0_7[2] = com.admob.android.ads.j$b.c;
	        com.admob.android.ads.j$b.e = v0_7;
	        return;
	    }
	
	
	    private j$b(String p1, int p2, String p3)
	    {
	        this(p1, p2);
	        this.d = p3;
	        return;
	    }
	
	
	    public static com.admob.android.ads.j$b valueOf(String p1)
	    {
	        return ((com.admob.android.ads.j$b) Enum.valueOf(com.admob.android.ads.j$b, p1));
	    }
	
	
	    public static com.admob.android.ads.j$b[] values()
	    {
	        return ((com.admob.android.ads.j$b[]) com.admob.android.ads.j$b.e.clone());
	    }
	
	
	    public final String toString()
	    {
	        return this.d;
	    }
	
