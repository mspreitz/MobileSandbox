	
	    public ag(android.app.Activity p1, ref.WeakReference p2)
	    {
	        return;
	    }
	
