	 android.view.ViewGroup a
	  b
	private android.widget.RelativeLayout c
	private android.widget.RelativeLayout d
	private android.widget.Button e
	private java.lang.ref.WeakReference f
	
	    public aa()
	    {
	        this.c = 0;
	        this.d = 0;
	        this.a = 0;
	        this.e = 0;
	        this.b = 0;
	        return;
	    }
	
	
	    public final void a()
	    {
	        com.admob.android.ads.ac.b(this.c);
	        com.admob.android.ads.ac.b(this.d);
	        this.b = 0;
	        return;
	    }
	
	
	    public final void a(android.content.Context p16, String p17, com.admob.android.ads.p p18, float p19, com.admob.android.ads.ac p20, com.admob.android.ads.r p21, ref.WeakReference p22)
	    {
	        this.f = p22;
	        android.widget.RelativeLayout v5_1 = new android.graphics.Rect(0, 0, ((int) (1134559232 * p19)), ((int) (1107820544 * p19)));
	        android.widget.LinearLayout v10_0 = android.graphics.Bitmap.createBitmap(v5_1.width(), v5_1.height(), android.graphics.Bitmap$Config.ARGB_8888);
	        if (v10_0 != null) {
	            int v4_3 = new android.graphics.Canvas(v10_0);
	            com.admob.android.ads.j.a(v4_3, v5_1, -16777216, -1, 127, 1056964608);
	            android.widget.RelativeLayout v5_3 = new android.graphics.Paint();
	            v5_3.setColor(-7829368);
	            android.graphics.drawable.BitmapDrawable v6_5 = new float[8];
	            v6_5[0] = 0;
	            v6_5[1] = 0;
	            v6_5[2] = (1134559232 * p19);
	            v6_5[3] = 0;
	            v6_5[4] = 0;
	            v6_5[5] = ((1107820544 * p19) - 1065353216);
	            v6_5[6] = (1134559232 * p19);
	            v6_5[7] = ((1107820544 * p19) - 1065353216);
	            v4_3.drawLines(v6_5, v5_3);
	            int v4_4 = new android.widget.RelativeLayout;
	            v4_4(p16);
	            this.c = v4_4;
	            int v4_6 = new android.graphics.drawable.BitmapDrawable(v10_0);
	            v4_6.setAlpha(200);
	            this.c.setBackgroundDrawable(v4_6);
	        }
	        int v4_7 = new android.widget.TextView;
	        v4_7(p16);
	        v4_7.setText(p18.b);
	        android.widget.RelativeLayout v5_8 = new android.widget.RelativeLayout$LayoutParams(-2, -2);
	        v4_7.setTextSize(1096810496);
	        v4_7.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
	        v4_7.setTextColor(-1);
	        v4_7.setPadding(((int) (1077936128 * p19)), 0, 0, 0);
	        v5_8.addRule(9);
	        v5_8.addRule(15);
	        this.c.addView(v4_7, v5_8);
	        int v4_8 = new android.widget.TextView;
	        v4_8(p16);
	        v4_8.setText(com.admob.android.ads.t.a("Ads by AdMob"));
	        android.widget.RelativeLayout v5_12 = new android.widget.RelativeLayout$LayoutParams(-2, -2);
	        v4_8.setTextSize(1093664768);
	        v4_8.setTextColor(-1);
	        v4_8.setPadding(0, 0, ((int) (1077936128 * p19)), 0);
	        v5_12.addRule(11);
	        v5_12.addRule(15);
	        this.c.addView(v4_8, v5_12);
	        int v4_10 = new android.widget.RelativeLayout$LayoutParams(-1, ((int) (1107820544 * p19)));
	        v4_10.addRule(10);
	        this.c.setVisibility(4);
	        p20.addView(this.c, v4_10);
	        android.widget.RelativeLayout v5_18 = new android.graphics.Rect(0, 0, ((int) (1134559232 * p19)), ((int) (1112014848 * p19)));
	        android.widget.LinearLayout v10_1 = android.graphics.Bitmap.createBitmap(v5_18.width(), v5_18.height(), android.graphics.Bitmap$Config.ARGB_8888);
	        if (v10_1 != null) {
	            int v4_14 = new android.graphics.Canvas(v10_1);
	            com.admob.android.ads.j.a(v4_14, v5_18, -16777216, -1, 127, 1056964608);
	            android.widget.RelativeLayout v5_20 = new android.graphics.Paint();
	            v5_20.setColor(-7829368);
	            android.graphics.drawable.BitmapDrawable v6_32 = new float[8];
	            v6_32[0] = 0;
	            v6_32[1] = 0;
	            v6_32[2] = (1134559232 * p19);
	            v6_32[3] = 0;
	            v6_32[4] = 0;
	            v6_32[5] = ((1112014848 * p19) - 1065353216);
	            v6_32[6] = (1134559232 * p19);
	            v6_32[7] = ((1112014848 * p19) - 1065353216);
	            v4_14.drawLines(v6_32, v5_20);
	            int v4_15 = new android.widget.RelativeLayout;
	            v4_15(p16);
	            this.d = v4_15;
	            int v4_17 = new android.graphics.drawable.BitmapDrawable(v10_1);
	            v4_17.setAlpha(200);
	            this.d.setBackgroundDrawable(v4_17);
	        }
	        int v4_19 = p21.h.m;
	        if (v4_19 != 0) {
	            android.widget.LinearLayout v10_2 = new android.widget.LinearLayout;
	            v10_2(p16);
	            v10_2.setOrientation(0);
	            android.widget.LinearLayout$LayoutParams v11_1 = new android.widget.LinearLayout$LayoutParams(-2, -1);
	            java.util.Iterator v12 = v4_19.iterator();
	            while (v12.hasNext()) {
	                com.admob.android.ads.o v22_1 = ((com.admob.android.ads.o) v12.next());
	                float v13_1 = new android.widget.LinearLayout$LayoutParams(((int) (1115684864 * p19)), -2);
	                android.graphics.drawable.BitmapDrawable v6_46 = new android.widget.Button;
	                v6_46(p16);
	                int v9_9 = ((android.graphics.Bitmap) p21.b().get(v22_1.b));
	                int v4_38 = new android.graphics.drawable.BitmapDrawable;
	                v4_38(((android.graphics.Bitmap) p21.b().get(v22_1.a)));
	                v4_38.setBounds(0, 0, ((int) (1105199104 * p19)), ((int) (1105199104 * p19)));
	                v6_46.setCompoundDrawables(0, v4_38, 0, 0);
	                v6_46.setBackgroundDrawable(0);
	                v6_46.setBackgroundColor(0);
	                v6_46.setTextSize(1094713344);
	                v6_46.setTextColor(-1);
	                v6_46.setText(v22_1.c);
	                v6_46.setPadding(0, ((int) (1073741824 * p19)), 0, ((int) (1073741824 * p19)));
	                int v4_45 = new com.admob.android.ads.ac$e;
	                v4_45(p20, v22_1, this.f);
	                v6_46.setOnClickListener(v4_45);
	                v10_2.addView(new com.admob.android.ads.x(p16, v6_46, ((int) (1115684864 * p19)), ((int) (1112014848 * p19)), v9_9), v13_1);
	                int v4_48 = new android.widget.ImageView;
	                v4_48(p16);
	                android.widget.RelativeLayout v5_57 = android.graphics.Bitmap.createBitmap(1, ((int) (1107820544 * p19)), android.graphics.Bitmap$Config.ARGB_8888);
	                if (v5_57 != null) {
	                    android.graphics.drawable.BitmapDrawable v6_51 = new android.graphics.Canvas(v5_57);
	                    android.graphics.Paint v7_39 = new android.graphics.Paint();
	                    v7_39.setColor(-7829368);
	                    float[] v8_51 = new float[4];
	                    v8_51[0] = 0;
	                    v8_51[1] = 0;
	                    v8_51[2] = 0;
	                    v8_51[3] = (1107820544 * p19);
	                    v6_51.drawLines(v8_51, v7_39);
	                    v4_48.setBackgroundDrawable(new android.graphics.drawable.BitmapDrawable(v5_57));
	                } else {
	                    v4_48 = 0;
	                }
	                v10_2.addView(v4_48, v11_1);
	            }
	            int v4_22 = new android.widget.RelativeLayout$LayoutParams(-2, -2);
	            v4_22.addRule(15);
	            this.d.addView(v10_2, v4_22);
	        }
	        int v4_23 = new android.widget.Button;
	        v4_23(p16);
	        this.e = v4_23;
	        int v4_24 = this.e;
	        android.widget.RelativeLayout v5_28 = new com.admob.android.ads.ac$i;
	        v5_28(p20, 0);
	        v4_24.setOnClickListener(v5_28);
	        this.e.setBackgroundResource(17301509);
	        this.e.setTextSize(1, 1095761920);
	        this.e.setText(p17);
	        int v4_29 = new android.widget.RelativeLayout$LayoutParams(((int) (1113063424 * p19)), ((int) (1108344832 * p19)));
	        v4_29.addRule(11);
	        v4_29.addRule(15);
	        v4_29.setMargins(0, 0, ((int) (1073741824 * p19)), 0);
	        this.d.addView(this.e, v4_29);
	        int v4_31 = new android.widget.RelativeLayout$LayoutParams(-1, ((int) (1112014848 * p19)));
	        v4_31.addRule(12);
	        this.d.setVisibility(4);
	        p20.addView(this.d, v4_31);
	        int v4_32 = new com.admob.android.ads.ac$d;
	        v4_32(p20);
	        p20.setOnTouchListener(v4_32);
	        return;
	    }
	
	
	    public final void b()
	    {
	        this.d.bringToFront();
	        this.c.bringToFront();
	        com.admob.android.ads.ac.a(this.d);
	        com.admob.android.ads.ac.a(this.c);
	        this.b = 1;
	        return;
	    }
	
