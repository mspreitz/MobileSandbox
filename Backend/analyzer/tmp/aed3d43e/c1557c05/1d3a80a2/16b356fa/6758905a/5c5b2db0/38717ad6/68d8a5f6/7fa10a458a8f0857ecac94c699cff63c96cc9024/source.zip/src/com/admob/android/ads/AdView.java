	private static java.lang.Boolean a
	private static android.os.Handler s
	private com.admob.android.ads.k b
	private  c
	private  d
	private com.admob.android.ads.AdView$d e
	private  f
	private  g
	private  h
	private java.lang.String i
	private java.lang.String j
	private com.admob.android.ads.AdListener k
	private  l
	private  m
	private  n
	private  o
	private com.admob.android.ads.AdView$a p
	private com.admob.android.ads.j$b q
	private com.admob.android.ads.AdView$f r
	
	    static AdView()
	    {
	        com.admob.android.ads.AdView.s = 0;
	        return;
	    }
	
	
	    public AdView(android.app.Activity p3)
	    {
	        this(p3, 0, 0);
	        return;
	    }
	
	
	    public AdView(android.content.Context p2, android.util.AttributeSet p3)
	    {
	        this(p2, p3, 0);
	        return;
	    }
	
	
	    public AdView(android.content.Context p2, android.util.AttributeSet p3, int p4)
	    {
	        this(p2, p3, p4, com.admob.android.ads.AdView$f.a);
	        return;
	    }
	
	
	    public AdView(android.content.Context p10, android.util.AttributeSet p11, int p12, com.admob.android.ads.AdView$f p13)
	    {
	        this(p10, p11, p12);
	        this.m = 1;
	        if (com.admob.android.ads.AdView.a == null) {
	            com.admob.android.ads.AdView.a = new Boolean(this.isInEditMode());
	        }
	        if ((com.admob.android.ads.AdView.s == null) && (!com.admob.android.ads.AdView.a.booleanValue())) {
	            int v0_7 = new android.os.Handler();
	            com.admob.android.ads.AdView.s = v0_7;
	            com.admob.android.ads.j.a(v0_7);
	        }
	        this.r = p13;
	        if (p13 != com.admob.android.ads.AdView$f.a) {
	            this.q = com.admob.android.ads.j$b.a;
	        }
	        int v0_12;
	        android.widget.RelativeLayout$LayoutParams v2_1;
	        int v1_1;
	        this.setDescendantFocusability(262144);
	        this.setClickable(1);
	        this.setLongClickable(0);
	        this.setGravity(17);
	        if (p11 == null) {
	            v0_12 = -1;
	            v1_1 = -1;
	            v2_1 = -16777216;
	        } else {
	            int v0_17 = new StringBuilder().append("http://schemas.android.com/apk/res/").append(p10.getPackageName()).toString();
	            if ((p11.getAttributeBooleanValue(v0_17, "testing", 0)) && (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 5))) {
	                android.util.Log.w("AdMobSDK", "AdView\'s \"testing\" XML attribute has been deprecated and will be ignored.  Please delete it from your XML layout and use AdManager.setTestDevices instead.");
	            }
	            int v1_10 = p11.getAttributeUnsignedIntValue(v0_17, "backgroundColor", -16777216);
	            android.widget.RelativeLayout$LayoutParams v2_5 = p11.getAttributeUnsignedIntValue(v0_17, "textColor", -1);
	            if (v2_5 >= null) {
	                this.setTextColor(v2_5);
	            }
	            android.widget.RelativeLayout$LayoutParams v2_7 = p11.getAttributeUnsignedIntValue(v0_17, "primaryTextColor", -1);
	            int v3_2 = p11.getAttributeUnsignedIntValue(v0_17, "secondaryTextColor", -1);
	            this.i = p11.getAttributeValue(v0_17, "keywords");
	            this.setRequestInterval(p11.getAttributeIntValue(v0_17, "refreshInterval", 0));
	            int v0_18 = p11.getAttributeBooleanValue(v0_17, "isGoneWithoutAd", 0);
	            if (v0_18 != 0) {
	                this.setGoneWithoutAd(v0_18);
	            }
	            v0_12 = v3_2;
	            v2_1 = v1_10;
	            v1_1 = v2_7;
	        }
	        this.setBackgroundColor(v2_1);
	        this.setPrimaryTextColor(v1_1);
	        this.setSecondaryTextColor(v0_12);
	        this.b = 0;
	        this.p = 0;
	        if (!com.admob.android.ads.AdView.a.booleanValue()) {
	            this.c();
	        } else {
	            int v0_24 = new android.widget.TextView(p10, p11, p12);
	            v0_24.setBackgroundColor(this.getBackgroundColor());
	            v0_24.setTextColor(this.getPrimaryTextColor());
	            v0_24.setPadding(10, 10, 10, 10);
	            v0_24.setTextSize(1098907648);
	            v0_24.setGravity(16);
	            v0_24.setText("Ads by AdMob");
	            this.addView(v0_24, new android.widget.RelativeLayout$LayoutParams(-1, -1));
	        }
	        return;
	    }
	
	
	    static synthetic com.admob.android.ads.k a(com.admob.android.ads.AdView p1)
	    {
	        return p1.b;
	    }
	
	
	    static synthetic void a(com.admob.android.ads.AdView p3, com.admob.android.ads.j p4)
	    {
	        if (p3.k != null) {
	            if ((p3.b != null) && (p3.b.getParent() != null)) {
	                try {
	                    p3.k.onReceiveRefreshedAd(p3);
	                } catch (Exception v0_5) {
	                    android.util.Log.w("AdMobSDK", "Unhandled exception raised in your AdListener.onReceiveRefreshedAd.", v0_5);
	                }
	            } else {
	                try {
	                    p3.k.onReceiveAd(p3);
	                } catch (Exception v0_7) {
	                    android.util.Log.w("AdMobSDK", "Unhandled exception raised in your AdListener.onReceiveAd.", v0_7);
	                }
	            }
	        }
	        return;
	    }
	
	
	    static synthetic void a(com.admob.android.ads.AdView p0, com.admob.android.ads.k p1)
	    {
	        p0.a(p1);
	        return;
	    }
	
	
	    private void a(com.admob.android.ads.k p4)
	    {
	        this.b = p4;
	        if (this.l) {
	            android.view.animation.AlphaAnimation v0_2 = new android.view.animation.AlphaAnimation(0, 1065353216);
	            v0_2.setDuration(233);
	            v0_2.startNow();
	            v0_2.setFillAfter(1);
	            v0_2.setInterpolator(new android.view.animation.AccelerateInterpolator());
	            this.startAnimation(v0_2);
	        }
	        return;
	    }
	
	
	    private void a(boolean p6)
	    {
	        try {
	            if ((!p6) || ((this.c <= 0) || (this.getVisibility() != 0))) {
	                if ((!p6) || (this.c == 0)) {
	                    this.d();
	                }
	            } else {
	                String v0_3 = this.c;
	                this.d();
	                if (this.e()) {
	                    this.e = new com.admob.android.ads.AdView$d(this);
	                    com.admob.android.ads.AdView.s.postDelayed(this.e, ((long) v0_3));
	                    if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                        android.util.Log.d("AdMobSDK", new StringBuilder().append("Ad refresh scheduled for ").append(v0_3).append(" from now.").toString());
	                    }
	                }
	            }
	        } catch (String v0_7) {
	            throw v0_7;
	        }
	        return;
	    }
	
	
	    static synthetic boolean a(com.admob.android.ads.AdView p1, boolean p2)
	    {
	        p1.n = 0;
	        return 0;
	    }
	
	
	    static synthetic com.admob.android.ads.AdListener b(com.admob.android.ads.AdView p1)
	    {
	        return p1.k;
	    }
	
	
	    static synthetic void b(com.admob.android.ads.AdView p7, com.admob.android.ads.k p8)
	    {
	        p8.setVisibility(8);
	        com.admob.android.ads.an v0_7 = new com.admob.android.ads.an(0, -1028390912, (((float) p7.getWidth()) / 1073741824), (((float) p7.getHeight()) / 1073741824), (-1093874483 * ((float) p7.getWidth())), 1);
	        v0_7.setDuration(700);
	        v0_7.setFillAfter(1);
	        v0_7.setInterpolator(new android.view.animation.AccelerateInterpolator());
	        v0_7.setAnimationListener(new com.admob.android.ads.AdView$1(p7, p8));
	        p7.startAnimation(v0_7);
	        return;
	    }
	
	
	    static synthetic void b(com.admob.android.ads.AdView p1, boolean p2)
	    {
	        p1.a(1);
	        return;
	    }
	
	
	    static synthetic com.admob.android.ads.AdView$a c(com.admob.android.ads.AdView p1)
	    {
	        if (p1.p == null) {
	            p1.p = new com.admob.android.ads.AdView$a(p1);
	        }
	        return p1.p;
	    }
	
	
	    static synthetic com.admob.android.ads.k c(com.admob.android.ads.AdView p0, com.admob.android.ads.k p1)
	    {
	        p0.b = p1;
	        return p1;
	    }
	
	
	    private void c()
	    {
	        com.admob.android.ads.c.a(this.getContext());
	        if ((this.m) || (super.getVisibility() == 0)) {
	            if (!this.n) {
	                this.n = 1;
	                this.o = android.os.SystemClock.uptimeMillis();
	                new com.admob.android.ads.AdView$b(this).start();
	            } else {
	                if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 5)) {
	                    android.util.Log.w("AdMobSDK", "Ignoring requestFreshAd() because we are requesting an ad right now already.");
	                }
	            }
	        } else {
	            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 5)) {
	                android.util.Log.w("AdMobSDK", "Cannot requestFreshAd() when the AdView is not visible.  Call AdView.setVisibility(View.VISIBLE) first.");
	            }
	        }
	        return;
	    }
	
	
	    static synthetic String d(com.admob.android.ads.AdView p1)
	    {
	        return p1.i;
	    }
	
	
	    private void d()
	    {
	        if (this.e != null) {
	            this.e.a = 1;
	            this.e = 0;
	            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 2)) {
	                android.util.Log.v("AdMobSDK", "Cancelled an ad refresh scheduled for the future.");
	            }
	        }
	        return;
	    }
	
	
	    static synthetic String e(com.admob.android.ads.AdView p1)
	    {
	        return p1.j;
	    }
	
	
	    private boolean e()
	    {
	        int v0_7;
	        if (this.b == null) {
	            v0_7 = 1;
	        } else {
	            int v0_2 = this.b.c();
	            if ((v0_2 == 0) || ((!v0_2.e()) || (this.b.h() >= 120))) {
	            } else {
	                if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                    android.util.Log.d("AdMobSDK", "Cannot refresh CPM ads.  Ignoring request to refresh the ad.");
	                }
	                v0_7 = 0;
	            }
	        }
	        return v0_7;
	    }
	
	
	    static synthetic void f(com.admob.android.ads.AdView p2)
	    {
	        if (p2.k != null) {
	            com.admob.android.ads.AdView.s.post(new com.admob.android.ads.AdView$c(p2));
	        }
	        return;
	    }
	
	
	    static synthetic long g(com.admob.android.ads.AdView p2)
	    {
	        return p2.o;
	    }
	
	
	    static synthetic int h(com.admob.android.ads.AdView p1)
	    {
	        return p1.c;
	    }
	
	
	    static synthetic void i(com.admob.android.ads.AdView p0)
	    {
	        p0.c();
	        return;
	    }
	
	
	    final com.admob.android.ads.j$b a()
	    {
	        return this.q;
	    }
	
	
	    final void a(com.admob.android.ads.j p8, com.admob.android.ads.k p9)
	    {
	        int v0 = super.getVisibility();
	        boolean v1_0 = p8.b();
	        if (v1_0 < 0) {
	            this.d = 0;
	        } else {
	            this.d = 1;
	            this.setRequestInterval(((int) v1_0));
	            this.a(1);
	        }
	        boolean v1_2 = this.m;
	        if (v1_2) {
	            this.m = 0;
	        }
	        p9.a(p8);
	        p9.setVisibility(v0);
	        p9.setGravity(17);
	        p8.a(p9);
	        p9.setLayoutParams(new android.widget.RelativeLayout$LayoutParams(p8.a(p8.f()), p8.a(p8.g())));
	        com.admob.android.ads.AdView.s.post(new com.admob.android.ads.AdView$e(this, p9, v0, v1_2));
	        return;
	    }
	
	
	    final com.admob.android.ads.AdView$f b()
	    {
	        return this.r;
	    }
	
	
	    public void cleanup()
	    {
	        if (this.b != null) {
	            this.b.e();
	            this.b = 0;
	        }
	        return;
	    }
	
	
	    public com.admob.android.ads.AdListener getAdListener()
	    {
	        return this.k;
	    }
	
	
	    public int getBackgroundColor()
	    {
	        return this.f;
	    }
	
	
	    public String getKeywords()
	    {
	        return this.i;
	    }
	
	
	    public int getPrimaryTextColor()
	    {
	        return this.g;
	    }
	
	
	    public int getRequestInterval()
	    {
	        return (this.c / 1000);
	    }
	
	
	    public String getSearchQuery()
	    {
	        return this.j;
	    }
	
	
	    public int getSecondaryTextColor()
	    {
	        return this.h;
	    }
	
	
	    public int getTextColor()
	    {
	        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 5)) {
	            android.util.Log.w("AdMobSDK", "Calling the deprecated method getTextColor!  Please use getPrimaryTextColor and getSecondaryTextColor instead.");
	        }
	        return this.getPrimaryTextColor();
	    }
	
	
	    public boolean hasAd()
	    {
	        if ((this.b == null) || (this.b.c() == null)) {
	            int v0_3 = 0;
	        } else {
	            v0_3 = 1;
	        }
	        return v0_3;
	    }
	
	
	    public boolean isGoneWithoutAd()
	    {
	        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 5)) {
	            android.util.Log.w("AdMobSDK", "Deprecated method isGoneWithoutAd was called.  See JavaDoc for instructions to remove.");
	        }
	        return 0;
	    }
	
	
	    protected void onAttachedToWindow()
	    {
	        this.l = 1;
	        this.a(1);
	        super.onAttachedToWindow();
	        return;
	    }
	
	
	    protected void onDetachedFromWindow()
	    {
	        this.l = 0;
	        this.a(0);
	        super.onDetachedFromWindow();
	        return;
	    }
	
	
	    protected void onMeasure(int p7, int p8)
	    {
	        super.onMeasure(p7, p8);
	        com.admob.android.ads.k v0_0 = this.getMeasuredWidth();
	        int v1_0 = this.getMeasuredHeight();
	        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	            android.util.Log.d("AdMobSDK", new StringBuilder().append("AdView size is ").append(v0_0).append(" by ").append(v1_0).toString());
	        }
	        if (!com.admob.android.ads.AdView.a.booleanValue()) {
	            if (((float) ((int) (((float) v0_0) / com.admob.android.ads.k.d()))) > 1134231552) {
	                try {
	                    com.admob.android.ads.k v0_7 = this.b.getVisibility();
	                    this.b.setVisibility(super.getVisibility());
	                } catch (com.admob.android.ads.k v0) {
	                }
	                if ((v0_7 != null) && (this.b.getVisibility() == 0)) {
	                    this.a(this.b);
	                }
	            } else {
	                if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                    android.util.Log.d("AdMobSDK", "We need to have a minimum width of 320 device independent pixels to show an ad.");
	                }
	                try {
	                    this.b.setVisibility(8);
	                } catch (com.admob.android.ads.k v0) {
	                }
	            }
	        }
	        return;
	    }
	
	
	    public void onWindowFocusChanged(boolean p1)
	    {
	        this.a(p1);
	        return;
	    }
	
	
	    protected void onWindowVisibilityChanged(int p2)
	    {
	        int v0;
	        if (p2 != 0) {
	            v0 = 0;
	        } else {
	            v0 = 1;
	        }
	        this.a(v0);
	        return;
	    }
	
	
	    public void requestFreshAd()
	    {
	        if (!this.d) {
	            String v0_3 = ((android.os.SystemClock.uptimeMillis() - this.o) / 1000);
	            if ((v0_3 <= 0) || (v0_3 >= 13)) {
	                if (this.e()) {
	                    this.c();
	                }
	            } else {
	                if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                    android.util.Log.d("AdMobSDK", new StringBuilder().append("Ignoring requestFreshAd.  Called ").append(v0_3).append(" seconds since last refresh.  ").append("Refreshes must be at least ").append(13).append(" apart.").toString());
	                }
	            }
	        } else {
	            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                android.util.Log.d("AdMobSDK", "Request interval overridden by the server.  Ignoring requestFreshAd.");
	            }
	        }
	        return;
	    }
	
	
	    public void setAdListener(com.admob.android.ads.AdListener p2)
	    {
	        try {
	            this.k = p2;
	            return;
	        } catch (Throwable v0) {
	            throw v0;
	        }
	    }
	
	
	    public void setBackgroundColor(int p2)
	    {
	        this.f = (-16777216 | p2);
	        this.invalidate();
	        return;
	    }
	
	
	    public void setEnabled(boolean p2)
	    {
	        super.setEnabled(p2);
	        if (!p2) {
	            this.setVisibility(8);
	        } else {
	            this.setVisibility(0);
	        }
	        return;
	    }
	
	
	    public void setGoneWithoutAd(boolean p3)
	    {
	        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 5)) {
	            android.util.Log.w("AdMobSDK", "Deprecated method setGoneWithoutAd was called.  See JavaDoc for instructions to remove.");
	        }
	        return;
	    }
	
	
	    public void setKeywords(String p1)
	    {
	        this.i = p1;
	        return;
	    }
	
	
	    public void setPrimaryTextColor(int p2)
	    {
	        this.g = (-16777216 | p2);
	        return;
	    }
	
	
	    public void setRequestInterval(int p8)
	    {
	        int v0_0 = (p8 * 1000);
	        if (this.c != v0_0) {
	            if (p8 > 0) {
	                if (p8 >= 13) {
	                    if (p8 > 600) {
	                        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 5)) {
	                            android.util.Log.w("AdMobSDK", new StringBuilder().append("AdView.setRequestInterval(").append(p8).append(") seconds must be <= ").append(600).toString());
	                        }
	                        v0_0 = 600000;
	                    }
	                } else {
	                    if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 5)) {
	                        android.util.Log.w("AdMobSDK", new StringBuilder().append("AdView.setRequestInterval(").append(p8).append(") seconds must be >= ").append(13).toString());
	                    }
	                    v0_0 = 13000;
	                }
	            }
	            this.c = v0_0;
	            if (p8 <= 0) {
	                this.d();
	            }
	            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 4)) {
	                android.util.Log.i("AdMobSDK", new StringBuilder().append("Requesting fresh ads every ").append(p8).append(" seconds.").toString());
	            }
	        }
	        return;
	    }
	
	
	    public void setSearchQuery(String p1)
	    {
	        this.j = p1;
	        return;
	    }
	
	
	    public void setSecondaryTextColor(int p2)
	    {
	        this.h = (-16777216 | p2);
	        return;
	    }
	
	
	    public void setTextColor(int p3)
	    {
	        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 5)) {
	            android.util.Log.w("AdMobSDK", "Calling the deprecated method setTextColor!  Please use setPrimaryTextColor and setSecondaryTextColor instead.");
	        }
	        this.setPrimaryTextColor(p3);
	        this.setSecondaryTextColor(p3);
	        return;
	    }
	
	
	    public void setVisibility(int p5)
	    {
	        if (super.getVisibility() != p5) {
	            try {
	                Throwable v0_1 = this.getChildCount();
	                int v1 = 0;
	            } catch (Throwable v0_3) {
	                throw v0_3;
	            }
	            while (v1 < v0_1) {
	                this.getChildAt(v1).setVisibility(p5);
	                v1++;
	            }
	            super.setVisibility(p5);
	            this.invalidate();
	        }
	        Throwable v0_2;
	        if (p5 != 0) {
	            v0_2 = 0;
	        } else {
	            v0_2 = 1;
	        }
	        this.a(v0_2);
	        return;
	    }
	
