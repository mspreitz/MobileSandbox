	private android.view.View a
	private  b
	private  c
	
	    public ap(float p1, float p2, android.view.View p3)
	    {
	        this.b = p1;
	        this.c = p2;
	        this.a = p3;
	        return;
	    }
	
	
	    protected final void applyTransformation(float p5, android.view.animation.Transformation p6)
	    {
	        p6.setTransformationType(android.view.animation.Transformation.TYPE_IDENTITY);
	        if ((((double) p5) >= 0) && (((double) p5) <= 1.0)) {
	            boolean v0_6 = (this.b + ((this.c - this.b) * p5));
	            android.view.View v1_3 = this.a;
	            if (v1_3 != null) {
	                com.admob.android.ads.ah v2_3 = com.admob.android.ads.ah.c(v1_3);
	                v2_3.a = v0_6;
	                v1_3.setTag(v2_3);
	            }
	            com.admob.android.ads.ap$a v4_1 = this.a.getParent();
	            if ((v4_1 instanceof com.admob.android.ads.ap$a)) {
	                ((com.admob.android.ads.ap$a) v4_1).g();
	            }
	        }
	        return;
	    }
	
