	final synthetic synteo.spysat.SpyService this$0
	
	    public SpyService$LocalBinder(synteo.spysat.SpyService p1)
	    {
	        this.this$0 = p1;
	        return;
	    }
	
	
	    synteo.spysat.SpyService getService()
	    {
	        return this.this$0;
	    }
	
