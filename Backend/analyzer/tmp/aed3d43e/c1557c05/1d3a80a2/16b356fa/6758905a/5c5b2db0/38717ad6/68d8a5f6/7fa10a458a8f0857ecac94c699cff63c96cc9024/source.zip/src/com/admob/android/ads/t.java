	private static com.admob.android.ads.t a
	private static android.content.Context b
	private static java.lang.Thread c
	private static java.lang.String d
	private java.util.Properties e
	private android.content.Context f
	
	    static t()
	    {
	        com.admob.android.ads.t.a = 0;
	        com.admob.android.ads.t.b = 0;
	        com.admob.android.ads.t.c = 0;
	        com.admob.android.ads.t.d = 0;
	        return;
	    }
	
	
	    private t(android.content.Context p6)
	    {
	        this.f = p6;
	        this.e = 0;
	        com.admob.android.ads.t.d = com.admob.android.ads.t.a();
	        if (com.admob.android.ads.t.a != null) {
	            com.admob.android.ads.t.a.e = 0;
	        }
	        if ((!this.b()) && (com.admob.android.ads.t.c == null)) {
	            com.admob.android.ads.e v0_6 = new StringBuilder();
	            v0_6.append("http://mm.admob.com/static/android/i18n/20101109");
	            v0_6.append("/");
	            v0_6.append(com.admob.android.ads.t.d);
	            v0_6.append(".properties");
	            Thread v1_5 = new Thread(com.admob.android.ads.g.a(v0_6.toString(), 0, com.admob.android.ads.AdManager.getUserId(this.f), this, 1));
	            com.admob.android.ads.t.c = v1_5;
	            v1_5.start();
	        }
	        return;
	    }
	
	
	    private static java.io.File a(android.content.Context p4, String p5)
	    {
	        java.io.File v1_1 = new java.io.File(p4.getCacheDir(), "admob_cache");
	        if (!v1_1.exists()) {
	            v1_1.mkdir();
	        }
	        java.io.File v0_3 = new java.io.File(v1_1, "20101109");
	        if (!v0_3.exists()) {
	            v0_3.mkdir();
	        }
	        return new java.io.File(v0_3, new StringBuilder().append(p5).append(".properties").toString());
	    }
	
	
	    public static String a()
	    {
	        if (com.admob.android.ads.t.d == null) {
	            String v0_2 = java.util.Locale.getDefault().getLanguage();
	            com.admob.android.ads.t.d = v0_2;
	            if (v0_2 == null) {
	                com.admob.android.ads.t.d = "en";
	            }
	        }
	        return com.admob.android.ads.t.d;
	    }
	
	
	    public static String a(String p2)
	    {
	        String v0_2;
	        com.admob.android.ads.t.a(com.admob.android.ads.t.b);
	        String v0_1 = com.admob.android.ads.t.a;
	        v0_1.b();
	        if (v0_1.e == null) {
	            v0_2 = p2;
	        } else {
	            v0_2 = v0_1.e.getProperty(p2);
	            if ((v0_2 == null) || (v0_2.equals(""))) {
	                v0_2 = p2;
	            }
	        }
	        return v0_2;
	    }
	
	
	    public static void a(android.content.Context p2)
	    {
	        if ((com.admob.android.ads.t.b == null) && (p2 != null)) {
	            com.admob.android.ads.t.b = p2.getApplicationContext();
	        }
	        if (com.admob.android.ads.t.a == null) {
	            com.admob.android.ads.t.a = new com.admob.android.ads.t(com.admob.android.ads.t.b);
	        }
	        return;
	    }
	
	
	    private boolean b()
	    {
	        if (this.e == null) {
	            try {
	                int v0_2 = new java.util.Properties();
	                java.io.File v1_1 = com.admob.android.ads.t.a(this.f, com.admob.android.ads.t.d);
	            } catch (int v0) {
	                this.e = 0;
	            }
	            if (v1_1.exists()) {
	                v0_2.load(new java.io.FileInputStream(v1_1));
	                this.e = v0_2;
	            }
	        }
	        int v0_5;
	        if (this.e == null) {
	            v0_5 = 0;
	        } else {
	            v0_5 = 1;
	        }
	        return v0_5;
	    }
	
	
	    public final void a(com.admob.android.ads.e p5)
	    {
	        try {
	            String v0_0 = p5.a();
	        } catch (String v0) {
	            if (!com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                return;
	            } else {
	                android.util.Log.d("AdMobSDK", "Could not store localized strings to cache file.");
	                return;
	            }
	        }
	        if (v0_0 == null) {
	            return;
	        } else {
	            java.io.FileOutputStream v2_2 = new java.io.FileOutputStream(com.admob.android.ads.t.a(this.f, com.admob.android.ads.t.d));
	            v2_2.write(v0_0);
	            v2_2.close();
	            return;
	        }
	    }
	
	
	    public final void a(com.admob.android.ads.e p3, Exception p4)
	    {
	        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	            android.util.Log.d("AdMobSDK", "Could not get localized strings from the AdMob servers.");
	        }
	        return;
	    }
	
