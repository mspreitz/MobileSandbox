	public static final  app_name
	public static final  app_restart
	public static final  cancel
	public static final  device_pin
	public static final  empty_cords
	public static final  empty_login
	public static final  footer
	public static final  help
	public static final  new_account
	public static final  quit
	public static final  save
	public static final  settings
	public static final  settings_delta
	public static final  settings_interval
	public static final  settings_welcome
	public static final  url
	public static final  url_help
	public static final  user_login
	public static final  video_tut
	public static final  welcome
	
	    public R$string()
	    {
	        return;
	    }
	
