	
	    public SimpleAdListener()
	    {
	        return;
	    }
	
	
	    public void onFailedToReceiveAd(com.admob.android.ads.AdView p1)
	    {
	        return;
	    }
	
	
	    public void onFailedToReceiveRefreshedAd(com.admob.android.ads.AdView p1)
	    {
	        return;
	    }
	
	
	    public void onReceiveAd(com.admob.android.ads.AdView p1)
	    {
	        return;
	    }
	
	
	    public void onReceiveRefreshedAd(com.admob.android.ads.AdView p1)
	    {
	        return;
	    }
	
