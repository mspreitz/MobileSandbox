	private I a
	private I b
	private android.view.View c
	
	    public aj(int p7, int p8, android.view.View p9)
	    {
	        this.c = p9;
	        int[] v0_0 = new int[4];
	        this.a = v0_0;
	        int[] v0_1 = new int[4];
	        this.b = v0_1;
	        this.a[0] = android.graphics.Color.alpha(p7);
	        this.a[1] = android.graphics.Color.red(p7);
	        this.a[2] = android.graphics.Color.green(p7);
	        this.a[3] = android.graphics.Color.blue(p7);
	        this.b[0] = android.graphics.Color.alpha(p8);
	        this.b[1] = android.graphics.Color.red(p8);
	        this.b[2] = android.graphics.Color.green(p8);
	        this.b[3] = android.graphics.Color.blue(p8);
	        return;
	    }
	
	
	    protected final void applyTransformation(float p8, android.view.animation.Transformation p9)
	    {
	        p9.setTransformationType(android.view.animation.Transformation.TYPE_IDENTITY);
	        if ((((double) p8) >= 0) && (((double) p8) <= 1.0)) {
	            int v0_5 = new int[4];
	            android.view.View v1_0 = 0;
	            while (v1_0 < 4) {
	                v0_5[v1_0] = ((int) (((float) this.a[v1_0]) + (((float) (this.b[v1_0] - this.a[v1_0])) * p8)));
	                v1_0++;
	            }
	            this.c.setBackgroundColor(android.graphics.Color.argb(v0_5[0], v0_5[1], v0_5[2], v0_5[3]));
	        }
	        return;
	    }
	
