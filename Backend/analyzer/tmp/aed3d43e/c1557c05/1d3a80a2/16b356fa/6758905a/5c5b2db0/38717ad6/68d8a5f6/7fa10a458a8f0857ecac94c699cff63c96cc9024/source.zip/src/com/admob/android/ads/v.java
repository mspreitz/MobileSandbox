	public android.media.AudioManager a
	
	    public v(android.content.Context p2)
	    {
	        this.a = ((android.media.AudioManager) p2.getSystemService("audio"));
	        return;
	    }
	
	
	    public int a()
	    {
	        return this.a.getMode();
	    }
	
	
	    public boolean b()
	    {
	        return this.a.isMusicActive();
	    }
	
	
	    public boolean c()
	    {
	        return this.a.isSpeakerphoneOn();
	    }
	
	
	    public int d()
	    {
	        return this.a.getRingerMode();
	    }
	
