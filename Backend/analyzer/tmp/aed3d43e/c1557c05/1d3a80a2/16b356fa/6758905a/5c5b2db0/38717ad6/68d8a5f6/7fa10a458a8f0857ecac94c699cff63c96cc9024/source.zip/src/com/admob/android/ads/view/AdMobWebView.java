	private  a
	private java.lang.ref.WeakReference b
	public java.lang.String c
	protected com.admob.android.ads.ad d
	
	    public AdMobWebView(android.content.Context p4, boolean p5, ref.WeakReference p6)
	    {
	        this(p4);
	        this.a = p5;
	        this.b = p6;
	        com.admob.android.ads.ad v0_0 = this.getSettings();
	        v0_0.setLoadsImagesAutomatically(1);
	        v0_0.setPluginsEnabled(1);
	        v0_0.setJavaScriptEnabled(1);
	        v0_0.setJavaScriptCanOpenWindowsAutomatically(1);
	        v0_0.setSaveFormData(0);
	        v0_0.setSavePassword(0);
	        v0_0.setUserAgentString(com.admob.android.ads.f.h());
	        this.d = this.a(p6);
	        this.setWebViewClient(this.d);
	        return;
	    }
	
	
	    public static android.view.View a(android.content.Context p9, String p10, boolean p11, boolean p12, android.graphics.Point p13, float p14, ref.WeakReference p15)
	    {
	        android.widget.RelativeLayout v0_1 = new android.widget.RelativeLayout(p9);
	        v0_1.setGravity(17);
	        com.admob.android.ads.view.AdMobWebView v1_2 = new com.admob.android.ads.view.AdMobWebView(p9, p12, p15);
	        v1_2.setBackgroundColor(0);
	        v0_1.addView(v1_2, new android.widget.RelativeLayout$LayoutParams(-1, -1));
	        if (p12) {
	            android.widget.ImageButton v2_3 = new android.widget.ImageButton(p9);
	            v2_3.setImageResource(17301527);
	            v2_3.setBackgroundDrawable(0);
	            v2_3.setPadding(0, 0, 0, 0);
	            v2_3.setOnClickListener(v1_2);
	            android.widget.RelativeLayout$LayoutParams v3_4 = new android.widget.RelativeLayout$LayoutParams(-2, -2);
	            v3_4.setMargins(com.admob.android.ads.j.a(p13.x, ((double) p14)), com.admob.android.ads.j.a(p13.y, ((double) p14)), 0, 0);
	            v0_1.addView(v2_3, v3_4);
	        }
	        v1_2.c = p10;
	        v1_2.loadUrl(p10);
	        return v0_1;
	    }
	
	
	    private String a(Object p6)
	    {
	        String v0_12;
	        if (p6 != null) {
	            if ((!(p6 instanceof Integer)) && (!(p6 instanceof Double))) {
	                if (!(p6 instanceof String)) {
	                    if (!(p6 instanceof java.util.Map)) {
	                        if (!(p6 instanceof org.json.JSONObject)) {
	                            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 5)) {
	                                android.util.Log.w("AdMobSDK", new StringBuilder().append("Unable to create JSON from object: ").append(p6).toString());
	                            }
	                            v0_12 = "";
	                        } else {
	                            v0_12 = ((org.json.JSONObject) p6).toString();
	                        }
	                    } else {
	                        String v1_2 = ((java.util.Map) p6).entrySet().iterator();
	                        String v2_1 = "{";
	                        while (v1_2.hasNext()) {
	                            String v0_17 = ((java.util.Map$Entry) v1_2.next());
	                            String v0_22 = v2_1.concat(new StringBuilder().append(this.a(v0_17.getKey())).append(":").append(this.a(v0_17.getValue())).toString());
	                            if (v1_2.hasNext()) {
	                                v0_22 = v0_22.concat(",");
	                            }
	                            v2_1 = v0_22;
	                        }
	                        v0_12 = v2_1.concat("}");
	                    }
	                } else {
	                    v0_12 = new StringBuilder().append("\'").append(((String) p6)).append("\'").toString();
	                }
	            } else {
	                v0_12 = p6.toString();
	            }
	        } else {
	            v0_12 = "{}";
	        }
	        return v0_12;
	    }
	
	
	    protected com.admob.android.ads.ad a(ref.WeakReference p2)
	    {
	        return new com.admob.android.ads.ad(this, p2);
	    }
	
	
	    public void a()
	    {
	        if (this.b != null) {
	            android.app.Activity v1_2 = ((android.app.Activity) this.b.get());
	            if (v1_2 != null) {
	                v1_2.finish();
	            }
	        }
	        return;
	    }
	
	
	    public final varargs void a(String p5, Object[] p6)
	    {
	        StringBuilder v1_0 = "";
	        String v0_1 = java.util.Arrays.asList(p6).iterator();
	        while (v0_1.hasNext()) {
	            v1_0 = v1_0.concat(this.a(v0_1.next()));
	            if (v0_1.hasNext()) {
	                v1_0 = v1_0.concat(",");
	            }
	        }
	        String v0_8 = new StringBuilder().append("javascript:admob.".concat(p5)).append("(").append(v1_0).append(");").toString();
	        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	            android.util.Log.w("AdMobSDK", new StringBuilder().append("Sending url to webView: ").append(v0_8).toString());
	        }
	        return;
	    }
	
	
	    public final void b(String p1)
	    {
	        this.c = p1;
	        return;
	    }
	
	
	    public void loadUrl(String p3)
	    {
	        String v0_1;
	        if (!this.a) {
	            v0_1 = p3;
	        } else {
	            v0_1 = new StringBuilder().append(p3).append("#sdk_close").toString();
	        }
	        super.loadUrl(v0_1);
	        return;
	    }
	
	
	    public void onClick(android.view.View p1)
	    {
	        this.a();
	        return;
	    }
	
