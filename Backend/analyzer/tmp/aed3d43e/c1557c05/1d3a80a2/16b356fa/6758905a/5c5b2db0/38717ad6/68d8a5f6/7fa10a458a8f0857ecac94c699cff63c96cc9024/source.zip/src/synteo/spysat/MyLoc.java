	public  alt
	public  hasData
	public  lat
	public  lon
	public  size
	public  spd
	
	    public MyLoc()
	    {
	        this.lat = 0;
	        this.lon = 0;
	        this.alt = 0;
	        this.spd = 0;
	        this.hasData = 0;
	        this.size = 0;
	        return;
	    }
	
