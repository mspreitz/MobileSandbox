	private static final  a
	private static final android.graphics.Rect b
	private static final android.graphics.PointF c
	private static final android.graphics.PointF d
	private static final android.graphics.PointF e
	private static final android.graphics.Matrix f
	private static final android.graphics.RectF g
	private static  h
	private static android.os.Handler i
	private com.admob.android.ads.j$c A
	private  B
	private  C
	private com.admob.android.ads.q D
	private com.admob.android.ads.j$b E
	private  F
	private com.admob.android.ads.s G
	private java.lang.String j
	private  k
	private  l
	private java.util.Vector m
	private android.graphics.Rect n
	private  o
	private  p
	private  q
	private java.lang.ref.WeakReference r
	private com.admob.android.ads.k s
	private  t
	private  u
	private  v
	private org.json.JSONObject w
	private com.admob.android.ads.u x
	private  y
	private java.util.Vector z
	
	    static j()
	    {
	        com.admob.android.ads.j.a = android.graphics.Color.rgb(102, 102, 102);
	        com.admob.android.ads.j.b = new android.graphics.Rect(0, 0, 0, 0);
	        int v0_5 = new android.graphics.PointF(0, 0);
	        com.admob.android.ads.j.c = v0_5;
	        com.admob.android.ads.j.d = v0_5;
	        com.admob.android.ads.j.e = new android.graphics.PointF(1056964608, 1056964608);
	        com.admob.android.ads.j.f = new android.graphics.Matrix();
	        com.admob.android.ads.j.g = new android.graphics.RectF(0, 0, 0, 0);
	        com.admob.android.ads.j.h = -1082130432;
	        com.admob.android.ads.j.i = 0;
	        return;
	    }
	
	
	    protected j()
	    {
	        this.m = new java.util.Vector();
	        this.o = 0;
	        this.a(0);
	        this.j = 0;
	        this.n = 0;
	        this.p = -1;
	        this.q = -1;
	        this.A = 0;
	        this.u = -1;
	        this.t = -1;
	        this.v = -16777216;
	        this.x = new com.admob.android.ads.u(this);
	        this.y = 0;
	        this.z = new java.util.Vector();
	        this.B = -1.0;
	        this.C = -1.0;
	        this.D = new com.admob.android.ads.q();
	        this.E = com.admob.android.ads.j$b.c;
	        com.admob.android.ads.j.h = 1084227584;
	        this.F = 0;
	        this.G = 0;
	        return;
	    }
	
	
	    public static float a(android.content.Context p3)
	    {
	        if (com.admob.android.ads.j.h < 0) {
	            com.admob.android.ads.j.h = p3.getSharedPreferences("admob_prefs", 2).getFloat("timeout", 1084227584);
	        }
	        return com.admob.android.ads.j.h;
	    }
	
	
	    private static float a(org.json.JSONObject p2, String p3, float p4)
	    {
	        return ((float) p2.optDouble(p3, ((double) p4)));
	    }
	
	
	    public static int a(int p4, double p5)
	    {
	        int v0_0 = ((double) p4);
	        if (p5 > 0) {
	            v0_0 = (((double) p4) * p5);
	        }
	        return ((int) v0_0);
	    }
	
	
	    private static int a(org.json.JSONObject p8, String p9, int p10)
	    {
	        if ((p8 == null) || (!p8.has(p9))) {
	            int v0_1 = p10;
	        } else {
	            try {
	                int v0_2 = p8.getJSONArray(p9);
	                v0_1 = android.graphics.Color.argb(((int) (v0_2.getDouble(3) * 255.0)), ((int) (v0_2.getDouble(0) * 255.0)), ((int) (v0_2.getDouble(1) * 255.0)), ((int) (v0_2.getDouble(2) * 255.0)));
	            } catch (int v0) {
	                v0_1 = p10;
	            }
	        }
	        return v0_1;
	    }
	
	
	    private static android.graphics.Matrix a(org.json.JSONArray p4)
	    {
	        android.graphics.Matrix v0_0 = 0;
	        float[] v1 = com.admob.android.ads.j.b(p4);
	        if ((v1 != null) && (v1.length == 9)) {
	            v0_0 = new android.graphics.Matrix();
	            v0_0.setValues(v1);
	        }
	        return v0_0;
	    }
	
	
	    private static android.graphics.Matrix a(org.json.JSONObject p3, String p4, android.graphics.Matrix p5)
	    {
	        android.graphics.Matrix v0_1;
	        android.graphics.Matrix v0_0 = com.admob.android.ads.j.b(p3, p4);
	        if ((v0_0 == null) || (v0_0.length != 9)) {
	            v0_1 = p5;
	        } else {
	            android.graphics.Matrix v1_2 = new android.graphics.Matrix();
	            v1_2.setValues(v0_0);
	            v0_1 = v1_2;
	        }
	        return v0_1;
	    }
	
	
	    private static android.graphics.PointF a(android.graphics.RectF p5, android.graphics.PointF p6)
	    {
	        return new android.graphics.PointF(((p5.width() * p6.x) + p5.left), ((p5.height() * p6.y) + p5.top));
	    }
	
	
	    private static android.graphics.PointF a(org.json.JSONObject p1, String p2, android.graphics.PointF p3)
	    {
	        if ((p1 == null) || (!p1.has(p2))) {
	            android.graphics.PointF v0_1 = p3;
	        } else {
	            try {
	                v0_1 = com.admob.android.ads.j.e(p1.getJSONArray(p2));
	            } catch (android.graphics.PointF v0) {
	                v0_1 = p3;
	            }
	        }
	        return v0_1;
	    }
	
	
	    private static android.graphics.Rect a(org.json.JSONObject p6, String p7, android.graphics.Rect p8)
	    {
	        if ((p6 == null) || (!p6.has(p7))) {
	            android.graphics.Rect v0_1 = p8;
	        } else {
	            try {
	                android.graphics.Rect v0_2 = p6.getJSONArray(p7);
	                int v1_2 = ((int) v0_2.getDouble(0));
	                int v2_2 = ((int) v0_2.getDouble(1));
	                v0_1 = new android.graphics.Rect(v1_2, v2_2, (((int) v0_2.getDouble(2)) + v1_2), (((int) v0_2.getDouble(3)) + v2_2));
	            } catch (android.graphics.Rect v0) {
	                v0_1 = p8;
	            }
	        }
	        return v0_1;
	    }
	
	
	    private static android.graphics.RectF a(org.json.JSONObject p1, String p2, android.graphics.RectF p3)
	    {
	        if ((p1 == null) || (!p1.has(p2))) {
	            android.graphics.RectF v0_1 = p3;
	        } else {
	            try {
	                v0_1 = com.admob.android.ads.j.d(p1.getJSONArray(p2));
	            } catch (android.graphics.RectF v0) {
	                v0_1 = p3;
	            }
	        }
	        return v0_1;
	    }
	
	
	    private android.view.View a(org.json.JSONObject p9, android.graphics.Rect p10)
	    {
	        try {
	            android.view.View v0_1;
	            if (this.s == null) {
	                v0_1 = 0;
	            } else {
	                android.graphics.drawable.BitmapDrawable v1_1 = com.admob.android.ads.j.a(p9, "ia", 1056964608);
	                float v5 = com.admob.android.ads.j.a(p9, "epy", 1054867456);
	                int v2_2 = com.admob.android.ads.j.a(p9, "bc", this.v);
	                android.graphics.Bitmap v6 = android.graphics.Bitmap.createBitmap(p10.width(), p10.height(), android.graphics.Bitmap$Config.ARGB_8888);
	                if (v6 != null) {
	                    this.z.add(v6);
	                    com.admob.android.ads.j.a(new android.graphics.Canvas(v6), p10, v2_2, -1, ((int) (v1_1 * 1132396544)), v5);
	                    v0_1 = new android.view.View(this.s.getContext());
	                    v0_1.setBackgroundDrawable(new android.graphics.drawable.BitmapDrawable(v6));
	                } else {
	                    v0_1 = 0;
	                }
	            }
	        } catch (android.view.View v0) {
	            v0_1 = 0;
	        }
	        return v0_1;
	    }
	
	
	    private static android.view.animation.Animation a(int p12, String p13, String p14, float[] p15, org.json.JSONArray p16, String[] p17, long p18, android.view.View p20, android.graphics.Rect p21, org.json.JSONObject p22, org.json.JSONArray p23)
	    {
	        android.view.animation.Animation v13_6;
	        long v6_0 = (p12 + 1);
	        float v7 = p15[p12];
	        int v15_1 = p15[v6_0];
	        if ((p13 != null) && (p14 != null)) {
	            try {
	                if ((!"position".equals(p13)) || (!"P".equals(p14))) {
	                    if ((!"opacity".equals(p13)) || (!"F".equals(p14))) {
	                        if ((!"bounds".equals(p13)) || (!"R".equals(p14))) {
	                            if ((!"zPosition".equals(p13)) || (!"F".equals(p14))) {
	                                if ((!"backgroundColor".equals(p13)) || (!"C".equals(p14))) {
	                                    if ((!"transform".equals(p13)) || (!"AT".equals(p14))) {
	                                        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                                            android.util.Log.e("AdMobSDK", new StringBuilder().append("Could not read keyframe animation: could not interpret keyPath(").append(p13).append(") and valueType(").append(p14).append(") combination.").toString());
	                                        }
	                                    } else {
	                                        if (p23 != null) {
	                                            com.admob.android.ads.j.a(p16.getJSONArray(p12));
	                                            com.admob.android.ads.j.a(p16.getJSONArray(v6_0));
	                                            v13_6 = com.admob.android.ads.j.a(p20, p21, p22, p23.getJSONArray(p12), p23.getJSONArray(v6_0));
	                                        }
	                                    }
	                                    v13_6 = 0;
	                                } else {
	                                    v13_6 = com.admob.android.ads.j.a(com.admob.android.ads.j.c(p16.getJSONArray(p12)), com.admob.android.ads.j.c(p16.getJSONArray(v6_0)), p20);
	                                }
	                            } else {
	                                v13_6 = com.admob.android.ads.j.a(((float) p16.getDouble(p12)), ((float) p16.getDouble(v6_0)), p20);
	                            }
	                        } else {
	                            v13_6 = com.admob.android.ads.j.a(com.admob.android.ads.j.d(p16.getJSONArray(p12)), com.admob.android.ads.j.d(p16.getJSONArray(v6_0)), p20, p21);
	                        }
	                    } else {
	                        v13_6 = com.admob.android.ads.j.a(((float) p16.getDouble(p12)), ((float) p16.getDouble(v6_0)));
	                    }
	                } else {
	                    v13_6 = com.admob.android.ads.j.a(com.admob.android.ads.j.e(p16.getJSONArray(p12)), com.admob.android.ads.j.e(p16.getJSONArray(v6_0)), p20, p21);
	                }
	            } catch (android.view.animation.Animation v13) {
	                v13_6 = 0;
	            }
	        } else {
	            if (!com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	            } else {
	                android.util.Log.e("AdMobSDK", new StringBuilder().append("Could not read keyframe animation: keyPath(").append(p13).append(") or valueType(").append(p14).append(") is null.").toString());
	                v13_6 = 0;
	            }
	        }
	        if (v13_6 != null) {
	            org.json.JSONArray v14_14 = ((int) (((float) p18) * v7));
	            boolean v8_24 = ((long) ((int) ((v15_1 - v7) * ((float) p18))));
	            v13_6.setDuration(p18);
	            android.view.animation.Interpolator v12_1 = com.admob.android.ads.j.a(p17[p12], ((long) v14_14), v8_24, p18);
	            if (v12_1 != null) {
	                v13_6.setInterpolator(v12_1);
	            }
	        }
	        return v13_6;
	    }
	
	
	    private static android.view.animation.Animation a(android.view.View p9, android.graphics.Rect p10, org.json.JSONObject p11, org.json.JSONArray p12, org.json.JSONArray p13)
	    {
	        com.admob.android.ads.ao v0_2;
	        com.admob.android.ads.ao v0_1 = p11.optString("tt", 0);
	        if (v0_1 == null) {
	            v0_2 = 0;
	        } else {
	            if (!"t".equals(v0_1)) {
	                if (!"r".equals(v0_1)) {
	                    if (!"sc".equals(v0_1)) {
	                        if (!"sk".equals(v0_1)) {
	                            "p".equals(v0_1);
	                        } else {
	                            com.admob.android.ads.ao v0_3 = com.admob.android.ads.j.b(p12);
	                            String v1_9 = com.admob.android.ads.j.b(p13);
	                            if ((v0_3 == null) || ((v1_9 == null) || (java.util.Arrays.equals(v0_3, v1_9)))) {
	                                v0_2 = 0;
	                            } else {
	                                v0_2 = new com.admob.android.ads.ao(v0_3, v1_9, com.admob.android.ads.j.a(new android.graphics.RectF(p10), com.admob.android.ads.ah.b(p9)));
	                            }
	                        }
	                    } else {
	                        com.admob.android.ads.ao v3_5 = com.admob.android.ads.j.b(p12);
	                        float v4_0 = com.admob.android.ads.j.b(p13);
	                        int v7_0 = com.admob.android.ads.ah.b(p9);
	                        v0_2 = new android.view.animation.ScaleAnimation(v3_5[0], v4_0[0], v3_5[1], v4_0[1], 1, v7_0.x, 1, v7_0.y);
	                    }
	                } else {
	                    String v1_11 = com.admob.android.ads.j.b(p12);
	                    android.graphics.PointF v2_4 = com.admob.android.ads.j.b(p13);
	                    if ((v1_11 == null) || ((v2_4 == null) || (java.util.Arrays.equals(v1_11, v2_4)))) {
	                        v0_2 = 0;
	                    } else {
	                        float v4_2 = com.admob.android.ads.j.a(new android.graphics.RectF(p10), com.admob.android.ads.ah.b(p9));
	                        v0_2 = new com.admob.android.ads.an(v1_11, v2_4, v4_2.x, v4_2.y, 0, 0);
	                    }
	                }
	            } else {
	                v0_2 = com.admob.android.ads.j.a(com.admob.android.ads.j.e(p12), com.admob.android.ads.j.e(p13), p9, p10);
	            }
	        }
	        return v0_2;
	    }
	
	
	    private android.view.animation.AnimationSet a(org.json.JSONArray p18, org.json.JSONObject p19, android.view.View p20, android.graphics.Rect p21)
	    {
	        android.view.animation.AnimationSet v12_1 = new android.view.animation.AnimationSet(0);
	        int v13 = 0;
	        while (v13 < p18.length()) {
	            org.json.JSONObject v14 = p18.getJSONObject(v13);
	            com.admob.android.ads.aj v5_4 = 0;
	            String v6_1 = v14.optString("t", 0);
	            int v15 = ((int) (((double) com.admob.android.ads.j.a(v14, "d", 1048576000)) * 1000.0));
	            if (!"B".equals(v6_1)) {
	                if ("K".equals(v6_1)) {
	                    v5_4 = this.a(v14, p20, p21, ((long) v15));
	                }
	            } else {
	                com.admob.android.ads.aj v16;
	                String v6_5 = v14.optString("kp", 0);
	                String v7_11 = v14.optString("vt", 0);
	                if ((v6_5 != null) && (v7_11 != null)) {
	                    if ((!"position".equals(v6_5)) || (!"P".equals(v7_11))) {
	                        if ((!"opacity".equals(v6_5)) || (!"F".equals(v7_11))) {
	                            if ((!"transform".equals(v6_5)) || (!"AT".equals(v7_11))) {
	                                if ((!"bounds".equals(v6_5)) || (!"R".equals(v7_11))) {
	                                    if ((!"zPosition".equals(v6_5)) || (!"F".equals(v7_11))) {
	                                        if ((!"backgroundColor".equals(v6_5)) || (!"C".equals(v7_11))) {
	                                            if (!com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                                                v16 = 0;
	                                            } else {
	                                                android.util.Log.e("AdMobSDK", new StringBuilder().append("Could not read basic animation: could not interpret keyPath(").append(v6_5).append(") and valueType(").append(v7_11).append(") combination.").toString());
	                                            }
	                                        } else {
	                                            v16 = com.admob.android.ads.j.a(com.admob.android.ads.j.a(v14, "fv", 0), com.admob.android.ads.j.a(v14, "tv", 0), p20);
	                                        }
	                                    } else {
	                                        v16 = com.admob.android.ads.j.a(com.admob.android.ads.j.a(v14, "fv", 0), com.admob.android.ads.j.a(v14, "tv", 0), p20);
	                                    }
	                                } else {
	                                    v16 = com.admob.android.ads.j.a(com.admob.android.ads.j.a(v14, "fv", com.admob.android.ads.j.g), com.admob.android.ads.j.a(v14, "tv", com.admob.android.ads.j.g), 0, p21);
	                                }
	                            } else {
	                                com.admob.android.ads.j.a(v14, "fv", com.admob.android.ads.j.f);
	                                com.admob.android.ads.j.a(v14, "fv", com.admob.android.ads.j.f);
	                                v16 = com.admob.android.ads.j.a(p20, p21, v14, v14.getJSONArray("tfv"), v14.getJSONArray("ttv"));
	                            }
	                        } else {
	                            v16 = com.admob.android.ads.j.a(com.admob.android.ads.j.a(v14, "fv", 0), com.admob.android.ads.j.a(v14, "tv", 0));
	                        }
	                    } else {
	                        v16 = com.admob.android.ads.j.a(com.admob.android.ads.j.a(v14, "fv", com.admob.android.ads.j.c), com.admob.android.ads.j.a(v14, "tv", com.admob.android.ads.j.d), p20, p21);
	                    }
	                } else {
	                    if (!com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                    } else {
	                        android.util.Log.e("AdMobSDK", new StringBuilder().append("Could not read basic animation: keyPath(").append(v6_5).append(") or valueType(").append(v7_11).append(") is null.").toString());
	                        v16 = 0;
	                    }
	                }
	                if (v16 != null) {
	                    com.admob.android.ads.aj v5_29 = com.admob.android.ads.j.a(v14.optString("tf", 0), -1, -1, -1);
	                    if (v5_29 == null) {
	                        v5_29 = 0;
	                    }
	                    if (v5_29 != null) {
	                        v16.setInterpolator(v5_29);
	                    }
	                }
	                v5_4 = v16;
	            }
	            if (v5_4 != null) {
	                v5_4.setDuration(((long) v15));
	                this.a(v14, v5_4, v12_1);
	                v12_1.addAnimation(v5_4);
	                v5_4.getDuration();
	            }
	            v13++;
	        }
	        if (p19 != null) {
	            this.a(p19, v12_1, 0);
	        }
	        return v12_1;
	    }
	
	
	    private android.view.animation.AnimationSet a(org.json.JSONObject p19, android.view.View p20, android.graphics.Rect p21, long p22)
	    {
	        int v3_11;
	        String v5_0 = p19.getString("vt");
	        float[] v6 = com.admob.android.ads.j.b(p19, "kt");
	        String v7_0 = p19.getJSONArray("vs");
	        String v8_0 = com.admob.android.ads.j.a(p19, "tfs");
	        org.json.JSONArray v14 = p19.optJSONArray("ttvs");
	        int v15 = v6.length;
	        int v3_5 = v7_0.length();
	        float v4_0 = v8_0.length;
	        if (((v15 == v3_5) && (v3_5 == (v4_0 + 1))) || ((((double) v6[0]) != 0) || (((double) v6[(v15 - 1)]) != 1.0))) {
	            android.view.animation.AnimationSet v16 = new android.view.animation.AnimationSet;
	            v16(0);
	            float v4_1 = p19.getString("kp");
	            int v17 = com.admob.android.ads.j.c(p19);
	            int v3_8 = 0;
	            while (v3_8 < (v15 - 1)) {
	                android.view.animation.Animation v9_13 = com.admob.android.ads.j.a(v3_8, v4_1, v5_0, v6, v7_0, v8_0, p22, p20, p21, p19, v14);
	                if (v9_13 != null) {
	                    v9_13.setRepeatCount(v17);
	                    v16.addAnimation(v9_13);
	                }
	                v3_8++;
	            }
	            com.admob.android.ads.j.a(p19.optString("fm", "r"), v16);
	            v3_11 = v16;
	        } else {
	            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                android.util.Log.e("AdMobSDK", new StringBuilder().append("keyframe animations were invalid: numKeyTimes=").append(v15).append(" numKeyValues=").append(v3_5).append(" numKeyFunctions=").append(v4_0).append(" keyTimes[0]=").append(v6[0]).append(" keyTimes[").append((v15 - 1)).append("]=").append(v6[(v15 - 1)]).toString());
	            }
	            v3_11 = 0;
	        }
	        return v3_11;
	    }
	
	
	    private static android.view.animation.Interpolator a(String p8, long p9, long p11, long p13)
	    {
	        android.view.animation.LinearInterpolator v1_8;
	        if (!"i".equals(p8)) {
	            if (!"o".equals(p8)) {
	                if (!"io".equals(p8)) {
	                    if (!"l".equals(p8)) {
	                        v1_8 = 0;
	                    } else {
	                        v1_8 = new android.view.animation.LinearInterpolator();
	                    }
	                } else {
	                    v1_8 = new android.view.animation.AccelerateDecelerateInterpolator();
	                }
	            } else {
	                v1_8 = new android.view.animation.DecelerateInterpolator();
	            }
	        } else {
	            v1_8 = new android.view.animation.AccelerateInterpolator();
	        }
	        if ((v1_8 == null) || ((p9 == -1) || ((p11 == -1) || (p13 == -1)))) {
	            com.admob.android.ads.ai v0_12 = v1_8;
	        } else {
	            v0_12 = new com.admob.android.ads.ai(v1_8, p9, p11, p13);
	        }
	        return v0_12;
	    }
	
	
	    private static com.admob.android.ads.aj a(int p1, int p2, android.view.View p3)
	    {
	        com.admob.android.ads.aj v0_0 = 0;
	        if (p1 != p2) {
	            v0_0 = new com.admob.android.ads.aj(p1, p2, p3);
	        }
	        return v0_0;
	    }
	
	
	    private static com.admob.android.ads.ak a(float p2, float p3)
	    {
	        com.admob.android.ads.ak v0_0 = 0;
	        if (p2 != p3) {
	            v0_0 = new com.admob.android.ads.ak(p2, p3);
	        }
	        return v0_0;
	    }
	
	
	    private static com.admob.android.ads.al a(android.graphics.RectF p7, android.graphics.RectF p8, android.view.View p9, android.graphics.Rect p10)
	    {
	        com.admob.android.ads.al v0_0 = 0;
	        if (!p7.equals(p8)) {
	            float v6_0 = com.admob.android.ads.j.a(p7, com.admob.android.ads.ah.b(p9));
	            com.admob.android.ads.al v0_3 = ((float) p10.width());
	            float v4_0 = ((float) p10.height());
	            v0_0 = new com.admob.android.ads.al((p7.width() / v0_3), (p8.width() / v0_3), (p7.height() / v4_0), (p8.height() / v4_0), v6_0.x, v6_0.y);
	        }
	        return v0_0;
	    }
	
	
	    private static com.admob.android.ads.am a(android.graphics.PointF p9, android.graphics.PointF p10, android.view.View p11, android.graphics.Rect p12)
	    {
	        com.admob.android.ads.am v0_0 = 0;
	        if (!p9.equals(p10)) {
	            com.admob.android.ads.am v0_1 = com.admob.android.ads.ah.b(p11);
	            float v2_4 = ((((float) p12.width()) * v0_1.x) + ((float) p12.left));
	            com.admob.android.ads.am v0_4 = ((v0_1.y * ((float) p12.height())) + ((float) p12.top));
	            p9.x = (p9.x - v2_4);
	            p9.y = (p9.y - v0_4);
	            p10.x = (p10.x - v2_4);
	            p10.y = (p10.y - v0_4);
	            v0_0 = new com.admob.android.ads.am(0, p9.x, 0, p10.x, 0, p9.y, 0, p10.y);
	        }
	        return v0_0;
	    }
	
	
	    private static com.admob.android.ads.ap a(float p2, float p3, android.view.View p4)
	    {
	        com.admob.android.ads.ap v0_0 = 0;
	        if (p2 != p3) {
	            v0_0 = new com.admob.android.ads.ap(p2, p3, p4);
	        }
	        return v0_0;
	    }
	
	
	    public static com.admob.android.ads.j a(com.admob.android.ads.m p7, android.content.Context p8, org.json.JSONObject p9, int p10, int p11, int p12, com.admob.android.ads.k p13, com.admob.android.ads.j$b p14)
	    {
	        if ((p9 != null) && (p9.length() != 0)) {
	            int v1_3;
	            int v0_2 = new com.admob.android.ads.j();
	            v0_2.E = p14;
	            int v0_3 = v0_2.a(p7);
	            v0_3.t = p10;
	            v0_3.u = p11;
	            v0_3.v = p12;
	            v0_3.s = p13;
	            v0_3.G = com.admob.android.ads.s.a(p8);
	            v0_3.x.c = v0_3.G;
	            if (v0_3.E != com.admob.android.ads.j$b.b) {
	                v1_3 = v0_3.a(p8, p9);
	            } else {
	                int v1_4 = com.admob.android.ads.j.a(p9, "timeout", 0);
	                if (v1_4 > 0) {
	                    com.admob.android.ads.j.h = v1_4;
	                    int v1_7 = p8.getSharedPreferences("admob_prefs", 2).edit();
	                    v1_7.putFloat("timeout", com.admob.android.ads.j.h);
	                    v1_7.commit();
	                }
	                v0_3.D.a(p8, p9, v0_3.x);
	                v0_3.D.a.l = 1;
	                int v1_13 = v0_3.D.a.a;
	                if ((v1_13 == com.admob.android.ads.j$a.d) || (v1_13 == com.admob.android.ads.j$a.c)) {
	                    v0_3.x.b();
	                    if (v0_3.x.a()) {
	                        v0_3.k();
	                    }
	                    v1_3 = 1;
	                } else {
	                    v1_3 = 0;
	                }
	            }
	            if (v1_3 == 0) {
	                v0_3 = 0;
	            }
	        } else {
	            v0_3 = 0;
	        }
	        return v0_3;
	    }
	
	
	    public static void a(android.graphics.Canvas p5, android.graphics.Rect p6, int p7, int p8, int p9, float p10)
	    {
	        android.graphics.Paint v0_4 = (((int) (((float) p6.height()) * p10)) + p6.top);
	        android.graphics.Rect v1_2 = new android.graphics.Rect(p6.left, p6.top, p6.right, v0_4);
	        android.graphics.Paint$Style v2_2 = new android.graphics.Paint();
	        v2_2.setColor(-1);
	        v2_2.setStyle(android.graphics.Paint$Style.FILL);
	        p5.drawRect(v1_2, v2_2);
	        int v3_5 = new int[2];
	        v3_5[0] = android.graphics.Color.argb(p9, android.graphics.Color.red(p7), android.graphics.Color.green(p7), android.graphics.Color.blue(p7));
	        v3_5[1] = p7;
	        android.graphics.Paint$Style v2_7 = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable$Orientation.TOP_BOTTOM, v3_5);
	        v2_7.setBounds(v1_2);
	        v2_7.draw(p5);
	        android.graphics.Rect v1_4 = new android.graphics.Rect(p6.left, v0_4, p6.right, p6.bottom);
	        android.graphics.Paint v0_6 = new android.graphics.Paint();
	        v0_6.setColor(p7);
	        v0_6.setStyle(android.graphics.Paint$Style.FILL);
	        p5.drawRect(v1_4, v0_6);
	        return;
	    }
	
	
	    public static void a(android.os.Handler p0)
	    {
	        com.admob.android.ads.j.i = p0;
	        return;
	    }
	
	
	    private static void a(android.view.animation.Animation p2, int p3, int p4, float p5, String p6, boolean p7)
	    {
	        if (p7) {
	            p2.setRepeatMode(2);
	        }
	        p2.setRepeatCount(p3);
	        p2.setStartOffset(((long) p4));
	        p2.startNow();
	        p2.scaleCurrentDuration(p5);
	        com.admob.android.ads.j.a(p6, p2);
	        return;
	    }
	
	
	    private void a(android.widget.ImageView p20, android.graphics.Bitmap p21, org.json.JSONObject p22)
	    {
	        android.graphics.Bitmap v5_1 = com.admob.android.ads.j.a(p22, "bw", 1056964608);
	        java.util.Vector v6_2 = com.admob.android.ads.j.a(p22, "bdc", com.admob.android.ads.j.a);
	        float v7_2 = com.admob.android.ads.j.a(p22, "br", 1087373312);
	        if (v5_1 < 1065353216) {
	            v5_1 = 1065353216;
	        }
	        float v8_3 = p21.getWidth();
	        float v9_0 = p21.getHeight();
	        try {
	            android.graphics.Bitmap v10_1 = android.graphics.Bitmap.createBitmap(v8_3, v9_0, android.graphics.Bitmap$Config.ARGB_8888);
	        } catch (android.graphics.Bitmap v5) {
	            android.graphics.Bitmap v5_4 = p21;
	            this.z.add(v5_4);
	            p20.setImageBitmap(v5_4);
	            return;
	        }
	        if (v10_1 != null) {
	            v10_1.eraseColor(0);
	            android.graphics.Canvas v11_2 = new android.graphics.Canvas(v10_1);
	            v11_2.setDrawFilter(new android.graphics.PaintFlagsDrawFilter(0, 1));
	            android.graphics.Paint v12_2 = (v7_2 + v5_1);
	            android.graphics.RectF v13_2 = new android.graphics.Path();
	            android.graphics.RectF v14_2 = new android.graphics.RectF(0, 0, ((float) v8_3), ((float) v9_0));
	            v13_2.addRoundRect(v14_2, v12_2, v12_2, android.graphics.Path$Direction.CCW);
	            v11_2.clipPath(v13_2, android.graphics.Region$Op.REPLACE);
	            v11_2.drawBitmap(p21, 0, 0, new android.graphics.Paint(3));
	            v11_2.clipRect(v14_2, android.graphics.Region$Op.REPLACE);
	            android.graphics.Paint v12_7 = new android.graphics.Paint(1);
	            v12_7.setStrokeWidth(v5_1);
	            v12_7.setColor(v6_2);
	            v12_7.setStyle(android.graphics.Paint$Style.STROKE);
	            java.util.Vector v6_5 = new android.graphics.Path();
	            android.graphics.Bitmap v5_2 = (v5_1 / 1073741824);
	            v6_5.addRoundRect(new android.graphics.RectF(v5_2, v5_2, (((float) v8_3) - v5_2), (((float) v9_0) - v5_2)), v7_2, v7_2, android.graphics.Path$Direction.CCW);
	            v11_2.drawPath(v6_5, v12_7);
	            if (p21 != null) {
	                p21.recycle();
	            }
	            v5_4 = v10_1;
	        } else {
	            return;
	        }
	    }
	
	
	    static synthetic void a(com.admob.android.ads.j p0)
	    {
	        p0.r();
	        return;
	    }
	
	
	    static synthetic void a(com.admob.android.ads.j p6, org.json.JSONArray p7)
	    {
	        try {
	            if (p6.s != null) {
	                p6.s.setPadding(0, 0, 0, 0);
	                java.util.ArrayList v1_2 = new java.util.ArrayList();
	                boolean v0_2 = 0;
	                while (v0_2 < p7.length()) {
	                    long v2_4 = p6.b(p7.getJSONObject(v0_2));
	                    if (v2_4 != 0) {
	                        v1_2.add(v2_4);
	                        v0_2++;
	                    } else {
	                        p6 = p6.r();
	                    }
	                }
	                long v2_2 = android.view.animation.AnimationUtils.currentAnimationTimeMillis();
	                int v4_1 = 0;
	                while (v4_1 < v1_2.size()) {
	                    boolean v0_11 = ((android.view.View) v1_2.get(v4_1));
	                    com.admob.android.ads.k v5_1 = v0_11.getAnimation();
	                    if (v5_1 != null) {
	                        v5_1.setStartTime(v2_2);
	                    }
	                    p6.s.addView(v0_11);
	                    v4_1++;
	                }
	                p6.s.invalidate();
	                p6.s.requestLayout();
	                if (!p6.F) {
	                    p6.s.b();
	                }
	                p6.x.d();
	                if (p6.o()) {
	                    p6 = p6.q();
	                }
	            }
	        } catch (boolean v0) {
	            p6 = p6.r();
	        }
	        return;
	    }
	
	
	    private void a(com.admob.android.ads.m p2)
	    {
	        this.r = new ref.WeakReference(p2);
	        return;
	    }
	
	
	    private void a(String p2)
	    {
	        if ((p2 != null) && (!"".equals(p2))) {
	            this.m.add(p2);
	        }
	        return;
	    }
	
	
	    private static void a(String p8, android.view.animation.Animation p9)
	    {
	        if ((p8 != null) && (p9 != null)) {
	            boolean v0_0 = p9.getClass();
	            try {
	                int v2_1 = new Class[1];
	                v2_1[0] = Boolean.TYPE;
	                boolean v0_1 = v0_0.getMethod("setFillEnabled", v2_1);
	            } catch (boolean v0) {
	                if (!"b".equals(p8)) {
	                    if ((!"fb".equals(p8)) && (!"r".equals(p8))) {
	                        if (!"f".equals(p8)) {
	                            if ("r".equals(p8)) {
	                                p9.setFillBefore(0);
	                                p9.setFillAfter(0);
	                            }
	                        } else {
	                            p9.setFillBefore(0);
	                            p9.setFillAfter(1);
	                        }
	                    } else {
	                        p9.setFillBefore(1);
	                        p9.setFillAfter(1);
	                    }
	                } else {
	                    p9.setFillBefore(1);
	                    p9.setFillAfter(0);
	                }
	            }
	            if (!v0_1) {
	            } else {
	                Object[] v1_2 = new Object[1];
	                v1_2[0] = Boolean.valueOf(1);
	                v0_1.invoke(p9, v1_2);
	            }
	        }
	        return;
	    }
	
	
	    private void a(org.json.JSONObject p12, android.view.animation.Animation p13, android.view.animation.AnimationSet p14)
	    {
	        android.view.animation.AnimationSet v0_1 = com.admob.android.ads.j.a(p12, "bt", 0);
	        int v2_0 = com.admob.android.ads.j.a(p12, "to", 0);
	        int v1_1 = com.admob.android.ads.j.c(p12);
	        boolean v5 = p12.optBoolean("ar", 0);
	        String v4_2 = p12.optString("fm", "r");
	        int v2_1 = ((int) (((double) ((v0_1 + 0) + v2_0)) * 1000.0));
	        float v3_4 = (1065353216 / com.admob.android.ads.j.a(p12, "s", 1065353216));
	        com.admob.android.ads.j.a(p13, v1_1, v2_1, v3_4, v4_2, v5);
	        if (p14 != null) {
	            com.admob.android.ads.j.a(p14, v1_1, v2_1, v3_4, v4_2, v5);
	        }
	        return;
	    }
	
	
	    private boolean a(android.content.Context p9, org.json.JSONObject p10)
	    {
	        long v0_1 = p10.optJSONObject("o");
	        if (v0_1 == 0) {
	            this.j = p10.optString("text", 0);
	            long v0_5 = p10.optString("6", 0);
	            this.D.a.b = p10.optString("8", 0);
	            this.D.a.a = com.admob.android.ads.j$a.a(v0_5);
	            long v0_8 = p10.optJSONArray("ac");
	            if (v0_8 != 0) {
	                this.D.a(p9, v0_8);
	            }
	            long v0_10 = p10.optJSONObject("ac");
	            if (v0_10 != 0) {
	                this.D.a(p9, v0_10);
	            }
	        } else {
	            this.D.a(p9, v0_1, 0);
	        }
	        long v0_12 = p10.optString("jsonp_url", 0);
	        String v1_8 = p10.optString("tracking_url", 0);
	        this.D.a.a(v0_12, 1);
	        this.D.a.a(v1_8, 0);
	        if (p10.has("refreshInterval")) {
	            this.B = p10.optDouble("refreshInterval");
	        }
	        if (!p10.has("density")) {
	            this.C = ((double) com.admob.android.ads.k.d());
	        } else {
	            this.C = p10.optDouble("density");
	        }
	        long v0_26 = com.admob.android.ads.j.a(p10, "d", 0);
	        if (v0_26 == 0) {
	            v0_26 = new android.graphics.PointF(1134559232, 1111490560);
	        }
	        if ((v0_26.x >= 0) && (v0_26.y >= 0)) {
	            long v0_29 = ((int) v0_26.y);
	            this.p = ((int) v0_26.x);
	            this.q = v0_29;
	            long v0_31 = p10.optString("cpm_url", 0);
	            if (v0_31 != 0) {
	                this.k = 1;
	                this.a(v0_31);
	            }
	            long v0_33 = p10.optString("tracking_pixel", 0);
	            if (v0_33 != 0) {
	                try {
	                    new java.net.URL(v0_33);
	                } catch (String v1) {
	                    try {
	                        v0_33 = java.net.URLEncoder.encode(v0_33, "UTF-8");
	                    } catch (String v1) {
	                    }
	                }
	            }
	            if (v0_33 != 0) {
	                this.a(v0_33);
	            }
	            long v0_35 = p10.optJSONObject("markup");
	            if ((this.D.a.a != com.admob.android.ads.j$a.b) || ((this.s.getContext() instanceof android.app.Activity))) {
	                if (v0_35 != 0) {
	                    String v1_28;
	                    String v1_24 = this.D;
	                    if ((v1_24.a.c == null) || (v1_24.a.c.size() <= 0)) {
	                        v1_28 = 0;
	                    } else {
	                        v1_28 = 1;
	                    }
	                    if (v1_28 != null) {
	                        this.w = v0_35;
	                        try {
	                            String v1_31;
	                            long v0_37 = this.w.optJSONObject("$");
	                        } catch (long v0_42) {
	                            if (!com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                                this.x.b();
	                                if (this.x.a()) {
	                                    this.k();
	                                }
	                                long v0_46 = 1;
	                            } else {
	                                android.util.Log.e("AdMobSDK", "Could not read in the flex ad.", v0_42);
	                            }
	                        }
	                        if (this.s == null) {
	                            v1_31 = 0;
	                        } else {
	                            v1_31 = com.admob.android.ads.AdManager.getUserId(this.s.getContext());
	                        }
	                        this.x.a(v0_37, v1_31);
	                        this.p();
	                        long v0_39 = this.w.optDouble("itid");
	                        if (v0_39 <= 0) {
	                        } else {
	                            this.o = ((long) (v0_39 * 1000.0));
	                        }
	                    } else {
	                        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                            android.util.Log.e("AdMobSDK", "Bad response:  didn\'t get clickURLString.  erroring out.");
	                        }
	                        v0_46 = 0;
	                    }
	                } else {
	                    v0_46 = 0;
	                }
	            } else {
	                this.r();
	                v0_46 = 0;
	            }
	        } else {
	            v0_46 = 0;
	        }
	        return v0_46;
	    }
	
	
	    private static String[] a(org.json.JSONObject p6, String p7)
	    {
	        String[] v0_1;
	        String[] v0_0 = p6.optJSONArray(p7);
	        if (v0_0 != null) {
	            int v1 = v0_0.length();
	            try {
	                String[] v2 = new String[v1];
	                int v3 = 0;
	            } catch (String[] v0) {
	                v0_1 = 0;
	            }
	            while (v3 < v1) {
	                v2[v3] = v0_0.getString(v3);
	                v3++;
	            }
	            v0_1 = v2;
	        } else {
	            v0_1 = 0;
	        }
	        return v0_1;
	    }
	
	
	    private android.view.View b(org.json.JSONObject p15)
	    {
	        com.admob.android.ads.k v0_0 = 0;
	        try {
	            if ((this.s != null) && (p15 != null)) {
	                com.admob.android.ads.k v0_4;
	                String v2_2;
	                int v3_1;
	                com.admob.android.ads.k v0_2 = p15.getString("t");
	                int v1_3 = this.a(com.admob.android.ads.j.a(p15, "f", com.admob.android.ads.j.b));
	                if (!"l".equals(v0_2)) {
	                    if (!"bg".equals(v0_2)) {
	                        if (!"i".equals(v0_2)) {
	                            if (!"P".equals(v0_2)) {
	                                if (!"wv".equals(v0_2)) {
	                                    v0_4 = 1;
	                                    v3_1 = 0;
	                                    v2_2 = 1;
	                                } else {
	                                    v2_2 = 1;
	                                    v3_1 = this.d(p15);
	                                    v0_4 = 1;
	                                }
	                            } else {
	                                com.admob.android.ads.k v0_7;
	                                if (this.s == null) {
	                                    v0_7 = 0;
	                                } else {
	                                    v0_7 = new android.view.View(this.s.getContext());
	                                }
	                                v2_2 = 1;
	                                v3_1 = v0_7;
	                                v0_4 = 1;
	                            }
	                        } else {
	                            com.admob.android.ads.k v0_9 = 0;
	                            if (this.s != null) {
	                                v0_9 = 0;
	                                String v2_7 = p15.getString("$");
	                                if (v2_7 == null) {
	                                    if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                                        android.util.Log.d("AdMobSDK", new StringBuilder().append("Could not find asset name ").append(p15).toString());
	                                    }
	                                } else {
	                                    com.admob.android.ads.k v0_11;
	                                    com.admob.android.ads.k v0_10 = this.x;
	                                    if (v0_10.a == null) {
	                                        v0_11 = 0;
	                                    } else {
	                                        v0_11 = ((android.graphics.Bitmap) v0_10.a.get(v2_7));
	                                    }
	                                    if (v0_11 == null) {
	                                        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                                            android.util.Log.e("AdMobSDK", new StringBuilder().append("couldn\'t find Bitmap ").append(v2_7).toString());
	                                        }
	                                        v0_9 = 0;
	                                    } else {
	                                        String v2_14 = new android.widget.ImageView(this.s.getContext());
	                                        v2_14.setScaleType(android.widget.ImageView$ScaleType.FIT_XY);
	                                        if (!p15.optBoolean("b", 0)) {
	                                            this.z.add(v0_11);
	                                            v2_14.setImageBitmap(v0_11);
	                                            v0_9 = v2_14;
	                                        } else {
	                                            this.a(v2_14, v0_11, p15);
	                                            v0_9 = v2_14;
	                                        }
	                                    }
	                                }
	                            }
	                            v2_2 = 1;
	                            v3_1 = v0_9;
	                            v0_4 = 1;
	                        }
	                    } else {
	                        v2_2 = 0;
	                        v3_1 = this.a(p15, v1_3);
	                        v0_4 = 0;
	                    }
	                } else {
	                    com.admob.android.ads.k v0_19;
	                    if (this.s == null) {
	                        v0_19 = 0;
	                    } else {
	                        StringBuilder v5_29;
	                        com.admob.android.ads.k v0_21 = p15.getString("x");
	                        String v2_16 = com.admob.android.ads.j.a(p15, "fs", 1095761920);
	                        StringBuilder v5_28 = p15.optJSONArray("fa");
	                        android.graphics.Typeface v7_0 = android.graphics.Typeface.DEFAULT;
	                        if (v5_28 == null) {
	                            v5_29 = v7_0;
	                        } else {
	                            int v8_1 = 0;
	                            String v6_4 = 0;
	                            while (v6_4 < v5_28.length()) {
	                                boolean v9_4 = v5_28.getString(v6_4);
	                                if (!"b".equals(v9_4)) {
	                                    if (!"i".equals(v9_4)) {
	                                        if (!"m".equals(v9_4)) {
	                                            if (!"s".equals(v9_4)) {
	                                                if ("ss".equals(v9_4)) {
	                                                    v7_0 = android.graphics.Typeface.SANS_SERIF;
	                                                }
	                                            } else {
	                                                v7_0 = android.graphics.Typeface.SERIF;
	                                            }
	                                        } else {
	                                            v7_0 = android.graphics.Typeface.MONOSPACE;
	                                        }
	                                    } else {
	                                        v8_1 |= 2;
	                                    }
	                                } else {
	                                    v8_1 |= 1;
	                                }
	                                v6_4++;
	                            }
	                            v5_29 = android.graphics.Typeface.create(v7_0, v8_1);
	                        }
	                        String v6_5 = this.t;
	                        if (!p15.has("fco")) {
	                            if (p15.optInt("fc", 0) != 1) {
	                                v6_5 = this.t;
	                            } else {
	                                v6_5 = this.u;
	                            }
	                        } else {
	                            android.graphics.Typeface v7_6 = com.admob.android.ads.j.a(p15, "fco", v6_5);
	                            if (v7_6 != v6_5) {
	                                v6_5 = v7_6;
	                            }
	                        }
	                        android.graphics.Typeface v7_8 = p15.optBoolean("afstfw", 1);
	                        int v8_4 = com.admob.android.ads.j.a(p15, "mfs", 1090519040);
	                        boolean v9_3 = p15.optInt("nol", 1);
	                        String v10_2 = new com.admob.android.ads.af(this.s.getContext(), com.admob.android.ads.k.d());
	                        v10_2.b = v7_8;
	                        v10_2.a = (v10_2.c * v8_4);
	                        v10_2.setBackgroundColor(0);
	                        v10_2.setText(v0_21);
	                        v10_2.setTextColor(v6_5);
	                        v10_2.setTextSize(v2_16);
	                        v10_2.setTypeface(v5_29);
	                        v10_2.setLines(v9_3);
	                        v0_19 = v10_2;
	                    }
	                    v2_2 = 1;
	                    v3_1 = v0_19;
	                    v0_4 = 1;
	                }
	                if (v3_1 == 0) {
	                    if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                        android.util.Log.e("AdMobSDK", "created a null view.");
	                    }
	                    v0_0 = 0;
	                } else {
	                    if (v2_2 == null) {
	                        if (v0_4 != null) {
	                            v3_1.setBackgroundDrawable(0);
	                        }
	                    } else {
	                        v3_1.setBackgroundColor(com.admob.android.ads.j.a(p15, "bgc", 0));
	                    }
	                    com.admob.android.ads.k v0_29 = com.admob.android.ads.j.a(p15, "ap", com.admob.android.ads.j.e);
	                    String v2_19 = com.admob.android.ads.ah.c(v3_1);
	                    v2_19.b = v0_29;
	                    v3_1.setTag(v2_19);
	                    com.admob.android.ads.k v0_30 = 0;
	                    String v2_21 = p15.optJSONArray("a");
	                    int v4_2 = p15.optJSONObject("ag");
	                    if (v2_21 != null) {
	                        v0_30 = this.a(v2_21, v4_2, v3_1, v1_3);
	                    }
	                    String v2_23 = p15.optString("ut", 0);
	                    if ((v3_1 != 0) && (v2_23 != null)) {
	                        v3_1.setTag(com.admob.android.ads.ah.c(v3_1));
	                    }
	                    String v2_26 = new android.widget.RelativeLayout$LayoutParams(v1_3.width(), v1_3.height());
	                    v2_26.addRule(9);
	                    v2_26.addRule(10);
	                    v2_26.setMargins(v1_3.left, v1_3.top, 0, 0);
	                    v3_1.setLayoutParams(v2_26);
	                    if (v0_30 != null) {
	                        v3_1.setAnimation(v0_30);
	                    }
	                    if ((p15.optBoolean("cav")) && (this.s != null)) {
	                        this.s.a(v3_1, v2_26);
	                    }
	                    v0_0 = v3_1;
	                }
	            }
	        } catch (com.admob.android.ads.k v0_35) {
	            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                android.util.Log.e("AdMobSDK", "exception while trying to create a flex view.", v0_35);
	            }
	            v0_0 = 0;
	        }
	        return v0_0;
	    }
	
	
	    private static org.json.JSONArray b(int p2)
	    {
	        org.json.JSONArray v0_1 = new org.json.JSONArray();
	        v0_1.put(android.graphics.Color.red(p2));
	        v0_1.put(android.graphics.Color.green(p2));
	        v0_1.put(android.graphics.Color.blue(p2));
	        v0_1.put(android.graphics.Color.alpha(p2));
	        return v0_1;
	    }
	
	
	    private static float[] b(org.json.JSONArray p5)
	    {
	        float[] v0_0 = p5.length();
	        try {
	            float[] v1 = new float[v0_0];
	            int v2 = 0;
	        } catch (float[] v0) {
	            float[] v0_1 = 0;
	            return v0_1;
	        }
	        while (v2 < v0_0) {
	            v1[v2] = ((float) p5.getDouble(v2));
	            v2++;
	        }
	        v0_1 = v1;
	        return v0_1;
	    }
	
	
	    private static float[] b(org.json.JSONObject p1, String p2)
	    {
	        float[] v0_1;
	        float[] v0_0 = p1.optJSONArray(p2);
	        if (v0_0 != null) {
	            v0_1 = com.admob.android.ads.j.b(v0_0);
	        } else {
	            v0_1 = 0;
	        }
	        return v0_1;
	    }
	
	
	    private static int c(org.json.JSONArray p7)
	    {
	        return android.graphics.Color.argb(((int) (p7.getDouble(3) * 255.0)), ((int) (p7.getDouble(0) * 255.0)), ((int) (p7.getDouble(1) * 255.0)), ((int) (p7.getDouble(2) * 255.0)));
	    }
	
	
	    private static int c(org.json.JSONObject p2)
	    {
	        int v0_2 = ((int) com.admob.android.ads.j.a(p2, "rc", 1065353216));
	        if (v0_2 > 0) {
	            v0_2--;
	        }
	        return v0_2;
	    }
	
	
	    private static android.graphics.RectF d(org.json.JSONArray p5)
	    {
	        float v0_2 = ((float) p5.getDouble(0));
	        float v1_2 = ((float) p5.getDouble(1));
	        return new android.graphics.RectF(v0_2, v1_2, (((float) p5.getDouble(2)) + v0_2), (((float) p5.getDouble(3)) + v1_2));
	    }
	
	
	    private android.view.View d(org.json.JSONObject p8)
	    {
	        int v0_1;
	        if (this.s == null) {
	            v0_1 = 0;
	        } else {
	            String v4_0 = p8.optString("u");
	            org.json.JSONObject v2_0 = p8.optString("html");
	            int v1_0 = p8.optString("base");
	            this.y = (this.y + 1);
	            v0_1 = new com.admob.android.ads.z(this.s.getContext(), this);
	            if ((v4_0 == null) || (v4_0.equals(""))) {
	                if ((v2_0 == null) || ((v2_0.equals("")) || ((v1_0 == 0) || (v1_0.equals(""))))) {
	                    this.a(0);
	                    v0_1 = 0;
	                    return v0_1;
	                } else {
	                    v0_1.loadDataWithBaseURL(v1_0, v2_0, 0, 0, 0);
	                }
	            } else {
	                v0_1.b(v4_0);
	                v0_1.loadUrl(v4_0);
	            }
	            int v1_2 = p8.optJSONObject("d");
	            if (v1_2 != 0) {
	                v0_1.a = v1_2;
	            }
	            int v1_4 = this.s.b;
	            org.json.JSONObject v2_2 = new org.json.JSONObject();
	            try {
	                v2_2.put("ptc", com.admob.android.ads.j.b(v1_4.getPrimaryTextColor()));
	                v2_2.put("stc", com.admob.android.ads.j.b(v1_4.getSecondaryTextColor()));
	                v2_2.put("bgc", com.admob.android.ads.j.b(v1_4.getBackgroundColor()));
	            } catch (int v1) {
	            }
	            v0_1.b = v2_2;
	            v0_1.b();
	            this.F = 1;
	        }
	        return v0_1;
	    }
	
	
	    private static android.graphics.PointF e(org.json.JSONArray p3)
	    {
	        return new android.graphics.PointF(((float) p3.getDouble(0)), ((float) p3.getDouble(1)));
	    }
	
	
	    public static float n()
	    {
	        return com.admob.android.ads.j.h;
	    }
	
	
	    private boolean o()
	    {
	        int v0_1;
	        if (this.y > 0) {
	            v0_1 = 0;
	        } else {
	            v0_1 = 1;
	        }
	        return v0_1;
	    }
	
	
	    private void p()
	    {
	        android.graphics.Rect v0_1 = new android.graphics.Rect(0, 0, this.p, this.q);
	        if (this.w.has("ta")) {
	            try {
	                String v1_4 = this.w.getJSONArray("ta");
	                int v2_3 = v1_4.getInt(0);
	                int v3_2 = v1_4.getInt(1);
	                android.graphics.Rect v5_2 = new android.graphics.Rect(v2_3, v3_2, (v1_4.getInt(2) + v2_3), (v1_4.getInt(3) + v3_2));
	            } catch (String v1) {
	                if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                    android.util.Log.d("AdMobSDK", "could not read in the touchable area for the ad.");
	                }
	            }
	            if ((Math.abs(v5_2.width()) >= 44) && (Math.abs(v5_2.height()) >= 44)) {
	                v0_1 = v5_2;
	            }
	        }
	        this.n = v0_1;
	        return;
	    }
	
	
	    private void q()
	    {
	        com.admob.android.ads.s v0_2 = ((com.admob.android.ads.m) this.r.get());
	        if (v0_2 != null) {
	            v0_2.a(this);
	        }
	        if (this.G != null) {
	            com.admob.android.ads.s.a();
	        }
	        return;
	    }
	
	
	    private void r()
	    {
	        com.admob.android.ads.s v0_2 = ((com.admob.android.ads.m) this.r.get());
	        if (v0_2 != null) {
	            v0_2.a();
	        }
	        if (this.G != null) {
	            com.admob.android.ads.s.a();
	        }
	        return;
	    }
	
	
	    public final int a(int p7)
	    {
	        int v0_0 = ((double) p7);
	        if (this.C > 0) {
	            v0_0 = (((double) p7) * this.C);
	        }
	        return ((int) v0_0);
	    }
	
	
	    final android.graphics.Rect a(android.graphics.Rect p6)
	    {
	        android.graphics.Rect v0_1 = new android.graphics.Rect(p6);
	        if (this.C > 0) {
	            v0_1.left = this.a(p6.left);
	            v0_1.top = this.a(p6.top);
	            v0_1.right = this.a(p6.right);
	            v0_1.bottom = this.a(p6.bottom);
	        }
	        return v0_1;
	    }
	
	
	    public final com.admob.android.ads.q a()
	    {
	        return this.D;
	    }
	
	
	    public final void a(com.admob.android.ads.j$c p1)
	    {
	        this.A = p1;
	        return;
	    }
	
	
	    public final void a(com.admob.android.ads.k p1)
	    {
	        this.s = p1;
	        return;
	    }
	
	
	    public final void a(org.json.JSONObject p5)
	    {
	        if (!this.l) {
	            this.l = 1;
	            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 4)) {
	                android.util.Log.i("AdMobSDK", "Ad clicked.");
	            }
	            if (this.s != null) {
	                com.admob.android.ads.q.a(this.D.a.c, p5, com.admob.android.ads.AdManager.getUserId(this.s.getContext()));
	            }
	        } else {
	            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 4)) {
	                android.util.Log.i("AdMobSDK", "Ad clicked again.  Stats on admob.com will only reflect the first click.");
	            }
	        }
	        com.admob.android.ads.j$c v0_13;
	        if (this.s == null) {
	            v0_13 = 0;
	        } else {
	            com.admob.android.ads.j$c v0_12 = this.s.getContext();
	            if (!(v0_12 instanceof android.app.Activity)) {
	            } else {
	                v0_13 = ((android.app.Activity) v0_12);
	            }
	        }
	        if (v0_13 == null) {
	            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                android.util.Log.d("AdMobSDK", "Context null, not able to finish click.");
	            }
	        } else {
	            this.D.a(v0_13, this.s);
	        }
	        if (this.A != null) {
	            this.A.a();
	        }
	        return;
	    }
	
	
	    public final void a(boolean p3)
	    {
	        this.y = (this.y - 1);
	        if (!p3) {
	            this.x.c();
	        } else {
	            if (this.o()) {
	                this.q();
	            }
	        }
	        return;
	    }
	
	
	    public final double b()
	    {
	        return this.B;
	    }
	
	
	    public final com.admob.android.ads.k c()
	    {
	        return this.s;
	    }
	
	
	    public final long d()
	    {
	        return this.o;
	    }
	
	
	    public final boolean e()
	    {
	        return this.k;
	    }
	
	
	    public final boolean equals(Object p3)
	    {
	        int v0_1;
	        if (!(p3 instanceof com.admob.android.ads.j)) {
	            v0_1 = 0;
	        } else {
	            v0_1 = this.toString().equals(((com.admob.android.ads.j) p3).toString());
	        }
	        return v0_1;
	    }
	
	
	    public final int f()
	    {
	        return this.p;
	    }
	
	
	    public final int g()
	    {
	        return this.q;
	    }
	
	
	    public final android.graphics.Rect h()
	    {
	        if (this.n == null) {
	            this.n = new android.graphics.Rect(0, 0, this.p, this.q);
	        }
	        return this.n;
	    }
	
	
	    public final int hashCode()
	    {
	        return this.toString().hashCode();
	    }
	
	
	    final void i()
	    {
	        java.util.Iterator v1 = this.z.iterator();
	        while (v1.hasNext()) {
	            com.admob.android.ads.q v0_6 = ((android.graphics.Bitmap) v1.next());
	            if (v0_6 != null) {
	                v0_6.recycle();
	            }
	        }
	        this.z.clear();
	        if (this.D != null) {
	            this.D.a();
	        }
	        return;
	    }
	
	
	    final void j()
	    {
	        if (this.s != null) {
	            android.content.Context v0_2 = this.s.getContext();
	            java.util.Iterator v1_1 = this.m.iterator();
	            while (v1_1.hasNext()) {
	                com.admob.android.ads.g.a(((String) v1_1.next()), "impression_request", com.admob.android.ads.AdManager.getUserId(v0_2)).f();
	            }
	        }
	        return;
	    }
	
	
	    public final void k()
	    {
	        if (this.D != null) {
	            if (this.D.c()) {
	                this.D.a(this.x.a);
	            }
	            this.D.b();
	        }
	        if (this.w == null) {
	            if (this.o()) {
	                this.q();
	            }
	        } else {
	            Throwable v0_7 = this.w;
	            this.w = 0;
	            try {
	                Throwable v0_8 = v0_7.optJSONArray("v");
	            } catch (Throwable v0_11) {
	                if (!com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                    Throwable v0_12 = this.x;
	                    if (v0_12.b != null) {
	                        try {
	                            v0_12.b.clear();
	                            v0_12.b = 0;
	                        } catch (Throwable v0_13) {
	                            throw v0_13;
	                        }
	                    }
	                } else {
	                    android.util.Log.d("AdMobSDK", "couldn\'t construct the views.", v0_11);
	                }
	            }
	            if (v0_8 == null) {
	                this.r();
	            } else {
	                java.util.HashSet v1_4 = new com.admob.android.ads.j$d(this, v0_8);
	                if (com.admob.android.ads.j.i == null) {
	                } else {
	                    com.admob.android.ads.j.i.post(v1_4);
	                }
	            }
	        }
	        return;
	    }
	
	
	    public final void l()
	    {
	        this.w = 0;
	        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 4)) {
	            android.util.Log.i("AdMobSDK", "assetsDidFailToLoad()");
	        }
	        this.r();
	        return;
	    }
	
	
	    public final boolean m()
	    {
	        return this.F;
	    }
	
	
	    public final String toString()
	    {
	        String v0 = this.j;
	        if (v0 == null) {
	            v0 = "";
	        }
	        return v0;
	    }
	
