	
	    InstallReceiver$1(com.admob.android.ads.analytics.InstallReceiver p1)
	    {
	        return;
	    }
	
	
	    public final void a(com.admob.android.ads.e p3)
	    {
	        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	            android.util.Log.d("AdMobSDK", "Recorded install from an AdMob ad.");
	        }
	        return;
	    }
	
	
	    public final void a(com.admob.android.ads.e p3, Exception p4)
	    {
	        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	            android.util.Log.d("AdMobSDK", "Failed to record install from an AdMob ad.", p4);
	        }
	        return;
	    }
	
