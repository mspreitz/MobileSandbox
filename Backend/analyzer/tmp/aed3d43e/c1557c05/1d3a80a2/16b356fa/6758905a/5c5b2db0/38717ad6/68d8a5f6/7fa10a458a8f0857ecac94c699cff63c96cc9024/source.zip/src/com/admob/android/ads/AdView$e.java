	private java.lang.ref.WeakReference a
	private java.lang.ref.WeakReference b
	private  c
	private  d
	
	    public AdView$e(com.admob.android.ads.AdView p2, com.admob.android.ads.k p3, int p4, boolean p5)
	    {
	        this.a = new ref.WeakReference(p2);
	        this.b = new ref.WeakReference(p3);
	        this.c = p4;
	        this.d = p5;
	        return;
	    }
	
	
	    public final void run()
	    {
	        try {
	            Exception v0_2 = ((com.admob.android.ads.AdView) this.a.get());
	            String v1_2 = ((com.admob.android.ads.k) this.b.get());
	        } catch (Exception v0_3) {
	            if (!com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                return;
	            } else {
	                android.util.Log.e("AdMobSDK", "Unhandled exception placing AdContainer into AdView.", v0_3);
	                return;
	            }
	        }
	        if ((v0_2 == null) || (v1_2 == null)) {
	            return;
	        } else {
	            v0_2.addView(v1_2);
	            com.admob.android.ads.AdView.a(v0_2, v1_2.c());
	            if (this.c != 0) {
	                com.admob.android.ads.AdView.c(v0_2, v1_2);
	                return;
	            } else {
	                if (!this.d) {
	                    com.admob.android.ads.AdView.b(v0_2, v1_2);
	                    return;
	                } else {
	                    com.admob.android.ads.AdView.a(v0_2, v1_2);
	                    return;
	                }
	            }
	        }
	    }
	
