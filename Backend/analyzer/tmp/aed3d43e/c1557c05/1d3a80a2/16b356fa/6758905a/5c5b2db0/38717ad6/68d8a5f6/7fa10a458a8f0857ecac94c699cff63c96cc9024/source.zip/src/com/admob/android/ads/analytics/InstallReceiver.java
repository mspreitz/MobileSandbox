	
	    public InstallReceiver()
	    {
	        return;
	    }
	
	
	    private static String a(String p7, String p8, String p9)
	    {
	        String v0_10;
	        String v1_0 = 0;
	        if (p7 == null) {
	            v0_10 = 0;
	        } else {
	            try {
	                String v0_1 = p7.split("&");
	                StringBuilder v2_0 = 0;
	            } catch (String v0_11) {
	                if (!com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                } else {
	                    android.util.Log.e("AdMobSDK", "Could not create install URL.  Install not tracked.", v0_11);
	                }
	            }
	            while (v1_0 < v0_1.length) {
	                String v3_5 = v0_1[v1_0];
	                if (v3_5.startsWith("admob_")) {
	                    String v3_7 = v3_5.substring("admob_".length()).split("=");
	                    StringBuilder v4_7 = java.net.URLEncoder.encode(v3_7[0], "UTF-8");
	                    String v3_9 = java.net.URLEncoder.encode(v3_7[1], "UTF-8");
	                    if (v2_0 != null) {
	                        v2_0.append("&");
	                    } else {
	                        v2_0 = new StringBuilder(128);
	                    }
	                    v2_0.append(v4_7).append("=").append(v3_9);
	                }
	                v1_0++;
	            }
	            if (v2_0 == null) {
	            } else {
	                v2_0.append("&").append("isu").append("=").append(java.net.URLEncoder.encode(p8, "UTF-8"));
	                v2_0.append("&").append("app_id").append("=").append(java.net.URLEncoder.encode(p9, "UTF-8"));
	                v0_10 = new StringBuilder().append("http://a.admob.com/f0?").append(v2_0.toString()).toString();
	            }
	        }
	        return v0_10;
	    }
	
	
	    private static void a(android.content.Context p9, android.content.Intent p10)
	    {
	        try {
	            String v0_0 = p9.getPackageManager();
	        } catch (String v0_26) {
	            if (!com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 5)) {
	                return;
	            } else {
	                android.util.Log.w("AdMobSDK", "Unhandled exception while forwarding install intents.  Possibly lost some install information.", v0_26);
	                return;
	            }
	        }
	        if (v0_0 != null) {
	            String v1_2 = v0_0.getReceiverInfo(new android.content.ComponentName(p9, com.admob.android.ads.analytics.InstallReceiver), 128);
	            if ((v1_2 != null) && (v1_2.metaData != null)) {
	                String v0_3 = v1_2.metaData.keySet();
	                if (v0_3 != null) {
	                    java.util.Iterator v2_2 = v0_3.iterator();
	                    while (v2_2.hasNext()) {
	                        try {
	                            String v3_0 = v1_2.metaData.getString(((String) v2_2.next()));
	                        } catch (String v0_25) {
	                            android.util.Log.w("AdMobSDK", new StringBuilder().append("Could not forward Market\'s INSTALL_REFERRER intent to ").append(v3_0).toString(), v0_25);
	                        }
	                        if (!v3_0.equals("com.google.android.apps.analytics.AnalyticsReceiver")) {
	                            ((android.content.BroadcastReceiver) Class.forName(v3_0).newInstance()).onReceive(p9, p10);
	                            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                                android.util.Log.d("AdMobSDK", new StringBuilder().append("Successfully forwarded install notification to ").append(v3_0).toString());
	                            }
	                        }
	                    }
	                }
	            }
	        }
	        try {
	            ((android.content.BroadcastReceiver) Class.forName("com.google.android.apps.analytics.AnalyticsReceiver").newInstance()).onReceive(p9, p10);
	        } catch (String v0) {
	            if (!com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 2)) {
	                return;
	            } else {
	                android.util.Log.v("AdMobSDK", "Google Analytics not installed.");
	                return;
	            }
	        }
	        if (!com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	            return;
	        } else {
	            android.util.Log.d("AdMobSDK", "Successfully forwarded install notification to com.google.android.apps.analytics.AnalyticsReceiver");
	            return;
	        }
	    }
	
	
	    public void onReceive(android.content.Context p7, android.content.Intent p8)
	    {
	        try {
	            com.admob.android.ads.e v0_1 = p8.getStringExtra("referrer");
	            com.admob.android.ads.analytics.InstallReceiver$1 v1_0 = com.admob.android.ads.AdManager.getUserId(p7);
	            com.admob.android.ads.e v0_2 = com.admob.android.ads.analytics.InstallReceiver.a(v0_1, v1_0, com.admob.android.ads.AdManager.getApplicationPackageName(p7));
	        } catch (com.admob.android.ads.e v0_4) {
	            if (!com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	                return;
	            } else {
	                android.util.Log.e("AdMobSDK", "Unhandled exception processing Market install.", v0_4);
	                return;
	            }
	        }
	        if (v0_2 != null) {
	            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 2)) {
	                android.util.Log.v("AdMobSDK", new StringBuilder().append("Processing install from an AdMob ad (").append(v0_2).append(").").toString());
	            }
	            com.admob.android.ads.e v0_3 = com.admob.android.ads.g.a(v0_2, "Conversion", v1_0);
	            v0_3.a(new com.admob.android.ads.analytics.InstallReceiver$1(this));
	            v0_3.d();
	        }
	        com.admob.android.ads.analytics.InstallReceiver.a(p7, p8);
	        return;
	    }
	
