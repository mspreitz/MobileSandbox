	public static final enum com.admob.android.ads.a a
	public static final enum com.admob.android.ads.a b
	public static final enum com.admob.android.ads.a c
	public static final enum com.admob.android.ads.a d
	private static enum com.admob.android.ads.a e
	private static final synthetic Lcom.admob.android.ads.a f
	
	    static a()
	    {
	        com.admob.android.ads.a.a = new com.admob.android.ads.a("SPEAKER", 0);
	        com.admob.android.ads.a.e = new com.admob.android.ads.a("HEADPHONES", 1);
	        com.admob.android.ads.a.b = new com.admob.android.ads.a("VIBRATE", 2);
	        com.admob.android.ads.a.c = new com.admob.android.ads.a("EMULATOR", 3);
	        com.admob.android.ads.a.d = new com.admob.android.ads.a("OTHER", 4);
	        com.admob.android.ads.a[] v0_11 = new com.admob.android.ads.a[5];
	        v0_11[0] = com.admob.android.ads.a.a;
	        v0_11[1] = com.admob.android.ads.a.e;
	        v0_11[2] = com.admob.android.ads.a.b;
	        v0_11[3] = com.admob.android.ads.a.c;
	        v0_11[4] = com.admob.android.ads.a.d;
	        com.admob.android.ads.a.f = v0_11;
	        return;
	    }
	
	
	    private a(String p1, int p2)
	    {
	        this(p1, p2);
	        return;
	    }
	
	
	    public static com.admob.android.ads.a valueOf(String p1)
	    {
	        return ((com.admob.android.ads.a) Enum.valueOf(com.admob.android.ads.a, p1));
	    }
	
	
	    public static com.admob.android.ads.a[] values()
	    {
	        return ((com.admob.android.ads.a[]) com.admob.android.ads.a.f.clone());
	    }
	
