	
	    k$d()
	    {
	        return;
	    }
	
	
	    public final bridge synthetic int compare(Object p4, Object p5)
	    {
	        int v0_2;
	        int v0_0 = com.admob.android.ads.ah.a(((android.view.View) p4));
	        float v1 = com.admob.android.ads.ah.a(((android.view.View) p5));
	        if (v0_0 >= v1) {
	            if (v0_0 <= v1) {
	                v0_2 = 0;
	            } else {
	                v0_2 = 1;
	            }
	        } else {
	            v0_2 = -1;
	        }
	        return v0_2;
	    }
	
