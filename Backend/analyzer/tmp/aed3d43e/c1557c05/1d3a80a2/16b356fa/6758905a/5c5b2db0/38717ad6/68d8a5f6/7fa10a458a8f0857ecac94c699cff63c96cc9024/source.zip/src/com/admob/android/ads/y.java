	 java.lang.String a
	  b
	private com.admob.android.ads.q e
	
	    public y(android.app.Activity p3, String p4, com.admob.android.ads.q p5)
	    {
	        this(p3, 0, new ref.WeakReference(p3));
	        this.b = 1;
	        this.a = p4;
	        this.e = p5;
	        return;
	    }
	
	
	    protected final com.admob.android.ads.ad a(ref.WeakReference p2)
	    {
	        return new com.admob.android.ads.y$a(this, this, p2);
	    }
	
	
	    public final void a()
	    {
	        if (this.e != null) {
	            this.e.a();
	        }
	        return;
	    }
	
	
	    public final void a(String p3)
	    {
	        this.c = new StringBuilder().append(p3).append("#sdk").toString();
	        return;
	    }
	
	
	    public final boolean onKeyDown(int p2, android.view.KeyEvent p3)
	    {
	        boolean v0_1;
	        if (p2 != 4) {
	            v0_1 = super.onKeyDown(p2, p3);
	        } else {
	            this.a();
	            v0_1 = 1;
	        }
	        return v0_1;
	    }
	
