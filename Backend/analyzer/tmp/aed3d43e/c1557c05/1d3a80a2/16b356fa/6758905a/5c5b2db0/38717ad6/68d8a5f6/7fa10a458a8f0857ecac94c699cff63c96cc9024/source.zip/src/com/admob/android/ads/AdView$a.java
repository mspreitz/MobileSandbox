	private java.lang.ref.WeakReference a
	
	    public AdView$a()
	    {
	        return;
	    }
	
	
	    public AdView$a(com.admob.android.ads.AdView p2)
	    {
	        this.a = new ref.WeakReference(p2);
	        return;
	    }
	
	
	    public static android.os.Bundle a(com.admob.android.ads.n p1)
	    {
	        android.os.Bundle v0;
	        if (p1 != null) {
	            v0 = p1.a();
	        } else {
	            v0 = 0;
	        }
	        return v0;
	    }
	
	
	    public static java.util.ArrayList a(java.util.Vector p4)
	    {
	        java.util.ArrayList v0_1;
	        if (p4 != null) {
	            v0_1 = new java.util.ArrayList();
	            java.util.Iterator v1 = p4.iterator();
	            while (v1.hasNext()) {
	                com.admob.android.ads.n v4_2 = ((com.admob.android.ads.n) v1.next());
	                if (v4_2 != null) {
	                    v0_1.add(v4_2.a());
	                } else {
	                    v0_1.add(0);
	                }
	            }
	        } else {
	            v0_1 = 0;
	        }
	        return v0_1;
	    }
	
	
	    public final void a()
	    {
	        com.admob.android.ads.AdView v1_2 = ((com.admob.android.ads.AdView) this.a.get());
	        if (v1_2 != null) {
	            com.admob.android.ads.AdView.f(v1_2);
	        }
	        return;
	    }
	
	
	    public final void a(com.admob.android.ads.j p7)
	    {
	        com.admob.android.ads.AdView v6_2 = ((com.admob.android.ads.AdView) this.a.get());
	        try {
	            if (v6_2 != null) {
	                if ((com.admob.android.ads.AdView.a(v6_2) == null) || (!p7.equals(com.admob.android.ads.AdView.a(v6_2).c()))) {
	                    if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 4)) {
	                        android.util.Log.i("AdMobSDK", new StringBuilder().append("Ad returned (").append((android.os.SystemClock.uptimeMillis() - com.admob.android.ads.AdView.g(v6_2))).append(" ms):  ").append(p7).toString());
	                    }
	                    v6_2.getContext();
	                    v6_2.a(p7, p7.c());
	                } else {
	                    if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                        android.util.Log.d("AdMobSDK", "Received the same ad we already had.  Discarding it.");
	                    }
	                }
	            }
	        } catch (String v0_12) {
	            throw v0_12;
	        }
	        return;
	    }
	
