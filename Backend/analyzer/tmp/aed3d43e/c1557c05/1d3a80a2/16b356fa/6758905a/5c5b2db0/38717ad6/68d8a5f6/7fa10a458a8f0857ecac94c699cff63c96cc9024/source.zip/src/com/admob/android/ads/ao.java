	private F a
	private F b
	
	    public ao(float[] p1, float[] p2, android.graphics.PointF p3)
	    {
	        this.a = p1;
	        this.b = p2;
	        return;
	    }
	
	
	    protected final void applyTransformation(float p8, android.view.animation.Transformation p9)
	    {
	        if ((((double) p8) >= 0) && (((double) p8) <= 1.0)) {
	            int v0_4 = p9.getMatrix();
	            float v1_2 = new float[this.a.length];
	            float v2_2 = 0;
	            while (v2_2 < this.a.length) {
	                v1_2[v2_2] = (this.a[v2_2] + ((this.b[v2_2] - this.a[v2_2]) * p8));
	                v2_2++;
	            }
	            v0_4.setSkew(this.a[0], this.a[1]);
	            p9.setTransformationType(android.view.animation.Transformation.TYPE_MATRIX);
	        } else {
	            p9.setTransformationType(android.view.animation.Transformation.TYPE_IDENTITY);
	        }
	        return;
	    }
	
