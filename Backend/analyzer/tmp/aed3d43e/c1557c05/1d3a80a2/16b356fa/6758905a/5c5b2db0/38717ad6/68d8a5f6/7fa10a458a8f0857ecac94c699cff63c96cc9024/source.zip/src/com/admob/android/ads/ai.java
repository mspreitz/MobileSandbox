	private android.view.animation.Interpolator a
	private  b
	private  c
	
	    public ai(android.view.animation.Interpolator p3, long p4, long p6, long p8)
	    {
	        this.a = p3;
	        this.b = (((float) p4) / ((float) p8));
	        this.c = (((float) p6) / ((float) p8));
	        return;
	    }
	
	
	    public final float getInterpolation(float p4)
	    {
	        int v0_5;
	        if (p4 > this.b) {
	            if (p4 > (this.b + this.c)) {
	                v0_5 = 1073741824;
	            } else {
	                v0_5 = this.a.getInterpolation(((p4 - this.b) / this.c));
	            }
	        } else {
	            v0_5 = -1082130432;
	        }
	        return v0_5;
	    }
	
