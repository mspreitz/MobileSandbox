	private com.admob.android.ads.s a
	
	    synthetic s$a(com.admob.android.ads.s p2)
	    {
	        this(p2, 0);
	        return;
	    }
	
	
	    private s$a(com.admob.android.ads.s p1, byte p2)
	    {
	        this.a = p1;
	        return;
	    }
	
	
	    public final void run()
	    {
	        if (this.a != null) {
	            com.admob.android.ads.s.a(this.a);
	        }
	        return;
	    }
	
