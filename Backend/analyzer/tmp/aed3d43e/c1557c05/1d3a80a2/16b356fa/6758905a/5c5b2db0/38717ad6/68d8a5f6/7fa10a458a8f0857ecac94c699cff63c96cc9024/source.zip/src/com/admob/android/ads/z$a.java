	  a
	  b
	 com.admob.android.ads.j c
	private java.util.Timer e
	private java.util.TimerTask f
	
	    public z$a(com.admob.android.ads.z p2, com.admob.android.ads.view.AdMobWebView p3, com.admob.android.ads.j p4)
	    {
	        this(p3);
	        this.c = p4;
	        this.a = 0;
	        this.b = 0;
	        return;
	    }
	
	
	    public final void onPageFinished(android.webkit.WebView p5, String p6)
	    {
	        java.util.Timer v0_2 = ((com.admob.android.ads.view.AdMobWebView) this.d.get());
	        if (v0_2 != null) {
	            if ((p6 != null) && (p6.equals(v0_2.c))) {
	                this.b = 1;
	                super.onPageFinished(p5, p6);
	                if ((v0_2 instanceof com.admob.android.ads.z)) {
	                    ((com.admob.android.ads.z) v0_2).b();
	                }
	                if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                    android.util.Log.d("AdMobSDK", "startResponseTimer()");
	                }
	                this.f = new com.admob.android.ads.z$a$1(this);
	                this.e = new java.util.Timer();
	                this.e.schedule(this.f, 10000);
	            } else {
	                if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 4)) {
	                    android.util.Log.i("AdMobSDK", new StringBuilder().append("Unexpected page loaded, urlThatFinished: ").append(p6).toString());
	                }
	            }
	        }
	        return;
	    }
	
	
	    public final boolean shouldOverrideUrlLoading(android.webkit.WebView p7, String p8)
	    {
	        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 2)) {
	            android.util.Log.v("AdMobSDK", new StringBuilder().append("shouldOverrideUrlLoading, url: ").append(p8).toString());
	        }
	        try {
	            String v0_15;
	            String v0_8 = new java.net.URI(p8);
	        } catch (String v0_25) {
	            android.util.Log.w("AdMobSDK", "Bad link URL in AdMob web view.", v0_25);
	            v0_15 = super.shouldOverrideUrlLoading(p7, p8);
	            return v0_15;
	        }
	        if (!"admob".equals(v0_8.getScheme())) {
	        } else {
	            String v1_3 = v0_8.getHost();
	            if (!"ready".equals(v1_3)) {
	                if (!"movie".equals(v1_3)) {
	                } else {
	                    String v0_9 = v0_8.getQuery();
	                    if (v0_9 != null) {
	                        String v0_10 = com.admob.android.ads.z$a.a(v0_9);
	                        if (v0_10 != null) {
	                            String v0_12 = ((String) v0_10.get("action"));
	                            if ((v0_12 != null) && ((!"play".equalsIgnoreCase(v0_12)) && ((!"pause".equalsIgnoreCase(v0_12)) && ((!"stop".equalsIgnoreCase(v0_12)) && ((!"remove".equalsIgnoreCase(v0_12)) && ((!"replay".equalsIgnoreCase(v0_12)) && (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 5)))))))) {
	                                android.util.Log.w("AdMobSDK", new StringBuilder().append("Unknown actionString, admob://movie?action=").append(v0_12).toString());
	                            }
	                        }
	                    }
	                    v0_15 = 1;
	                    return v0_15;
	                }
	            } else {
	                if (!this.a) {
	                    this.a = 1;
	                    if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                        android.util.Log.d("AdMobSDK", "cancelResponseTimer()");
	                    }
	                    if (this.e != null) {
	                        this.e.cancel();
	                    }
	                    String v0_16 = v0_8.getQuery();
	                    if (v0_16 != null) {
	                        String v0_17 = com.admob.android.ads.z$a.a(v0_16);
	                        if (v0_17 != null) {
	                            String v0_19 = ((String) v0_17.get("success"));
	                            if ((v0_19 != null) && ("true".equalsIgnoreCase(v0_19))) {
	                                if (this.c != null) {
	                                    this.c.a(1);
	                                }
	                                v0_15 = 1;
	                                return v0_15;
	                            }
	                        }
	                    }
	                    if (this.c != null) {
	                        this.c.a(0);
	                    }
	                    v0_15 = 1;
	                    return v0_15;
	                } else {
	                    v0_15 = 1;
	                    return v0_15;
	                }
	            }
	        }
	    }
	
