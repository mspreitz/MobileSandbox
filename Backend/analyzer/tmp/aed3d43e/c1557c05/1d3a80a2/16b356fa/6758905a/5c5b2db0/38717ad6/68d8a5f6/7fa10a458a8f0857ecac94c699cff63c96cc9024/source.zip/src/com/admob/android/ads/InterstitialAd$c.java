	 com.admob.android.ads.InterstitialAd a
	
	    public InterstitialAd$c()
	    {
	        return;
	    }
	
	
	    public InterstitialAd$c(com.admob.android.ads.InterstitialAd p1)
	    {
	        this.a = p1;
	        return;
	    }
	
	
	    public static boolean a(String p3, int p4)
	    {
	        int v0_1;
	        if (p4 < 5) {
	            v0_1 = 0;
	        } else {
	            v0_1 = 1;
	        }
	        if ((v0_1 == 0) && (!android.util.Log.isLoggable(p3, p4))) {
	            int v0_3 = 0;
	        } else {
	            v0_3 = 1;
	        }
	        return v0_3;
	    }
	
	
	    public final void a()
	    {
	        if (this.a != null) {
	            this.a.c();
	        }
	        return;
	    }
	
	
	    public final void a(com.admob.android.ads.j p2)
	    {
	        if (this.a != null) {
	            com.admob.android.ads.InterstitialAd.a(this.a, p2);
	            this.a.a();
	        }
	        return;
	    }
	
