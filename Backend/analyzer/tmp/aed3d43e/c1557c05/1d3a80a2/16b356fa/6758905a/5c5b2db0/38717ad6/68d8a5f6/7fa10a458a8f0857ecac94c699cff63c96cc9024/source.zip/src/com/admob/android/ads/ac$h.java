	private java.lang.ref.WeakReference a
	
	    public ac$h(com.admob.android.ads.ac p2)
	    {
	        this.a = new ref.WeakReference(p2);
	        return;
	    }
	
	
	    public final void onClick(android.view.View p4)
	    {
	        com.admob.android.ads.ac v3_2 = ((com.admob.android.ads.ac) this.a.get());
	        if (v3_2 != null) {
	            v3_2.f.a("replay", 0);
	            if (v3_2.d != null) {
	                com.admob.android.ads.ac.b(v3_2.d);
	            }
	            com.admob.android.ads.ac.a(v3_2, 0);
	            v3_2.h = 1;
	            com.admob.android.ads.ac.a(v3_2, v3_2.getContext());
	        }
	        return;
	    }
	
