	private synteo.spysat.Application mActivity
	private android.widget.TextView text
	
	    public SpyMainView(synteo.spysat.Application p9)
	    {
	        this(p9);
	        this.mActivity = p9;
	        this.setBackgroundColor(android.graphics.Color.rgb(62, 62, 62));
	        this.setOrientation(1);
	        this.setGravity(1);
	        this.setLayoutParams(new android.widget.Gallery$LayoutParams(-1, -1));
	        android.widget.ImageView v2_1 = new android.widget.ImageView(this.mActivity);
	        v2_1.setImageResource(2130837505);
	        v2_1.setPadding(0, 0, 0, 20);
	        v2_1.setLayoutParams(new android.widget.Gallery$LayoutParams(-2, -2));
	        this.addView(v2_1);
	        v2_1.setOnClickListener(this.mActivity.mButtonAccListener);
	        this.addView(new com.admob.android.ads.AdView(this.mActivity));
	        this.text = new android.widget.TextView(this.mActivity);
	        this.text.setHeight(120);
	        this.text.setGravity(48);
	        this.text.setText(synteo.spysat.Application.strStatus);
	        this.addView(this.text);
	        this.text.setOnClickListener(this.mActivity.mButtonAccListener);
	        android.widget.TextView v1_1 = new android.widget.TextView(this.mActivity);
	        v1_1.setTextColor(android.graphics.Color.rgb(255, 196, 56));
	        v1_1.setText(2130968589);
	        this.addView(v1_1);
	        com.admob.android.ads.AdManager.setPublisherId("a14c517269c490f");
	        this.addView(new com.admob.android.ads.AdView(this.mActivity));
	        return;
	    }
	
	
	    public void update()
	    {
	        this.text.setText(synteo.spysat.Application.strStatus);
	        return;
	    }
	
