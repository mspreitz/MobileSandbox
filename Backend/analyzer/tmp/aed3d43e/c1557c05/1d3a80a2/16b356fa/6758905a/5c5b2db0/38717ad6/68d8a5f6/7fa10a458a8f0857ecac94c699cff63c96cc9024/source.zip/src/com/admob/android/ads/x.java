	private  a
	private  b
	private android.widget.ImageView c
	private  d
	
	    static x()
	    {
	        return;
	    }
	
	
	    public x(android.content.Context p6, android.view.View p7, int p8, int p9, android.graphics.Bitmap p10)
	    {
	        this(p6);
	        this.b = p8;
	        this.a = p9;
	        this.setClickable(1);
	        this.setFocusable(1);
	        this.d = this.getResources().getDisplayMetrics().density;
	        this.c = new android.widget.ImageView(p6);
	        android.widget.RelativeLayout$LayoutParams v0_7 = new android.graphics.drawable.BitmapDrawable(p10);
	        v0_7.setBounds(0, 0, ((int) (((float) p8) * this.d)), ((int) (((float) p9) * this.d)));
	        this.c.setImageDrawable(v0_7);
	        this.c.setVisibility(4);
	        android.widget.RelativeLayout$LayoutParams v0_10 = new android.widget.RelativeLayout$LayoutParams(((int) (((float) p8) * this.d)), ((int) (((float) p9) * this.d)));
	        v0_10.addRule(13);
	        this.addView(p7, v0_10);
	        this.addView(this.c, v0_10);
	        return;
	    }
	
	
	    private void a(boolean p3)
	    {
	        if (p3 != 1) {
	            this.c.setVisibility(4);
	        } else {
	            this.c.setVisibility(0);
	        }
	        return;
	    }
	
	
	    public final boolean dispatchTouchEvent(android.view.MotionEvent p8)
	    {
	        boolean v0_0 = p8.getAction();
	        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 2)) {
	            android.util.Log.v("AdMobSDK", new StringBuilder().append("dispatchTouchEvent: action=").append(v0_0).append(" x=").append(p8.getX()).append(" y=").append(p8.getY()).toString());
	        }
	        if (v0_0) {
	            if (v0_0 != 2) {
	                if (v0_0 != 1) {
	                    if (v0_0 == 3) {
	                        this.a(0);
	                    }
	                } else {
	                    this.a(0);
	                }
	            } else {
	                this.a(new android.graphics.Rect(0, 0, ((int) (((float) this.b) * this.d)), ((int) (((float) this.a) * this.d))).contains(((int) p8.getX()), ((int) p8.getY())));
	            }
	        } else {
	            this.a(1);
	        }
	        return super.dispatchTouchEvent(p8);
	    }
	
