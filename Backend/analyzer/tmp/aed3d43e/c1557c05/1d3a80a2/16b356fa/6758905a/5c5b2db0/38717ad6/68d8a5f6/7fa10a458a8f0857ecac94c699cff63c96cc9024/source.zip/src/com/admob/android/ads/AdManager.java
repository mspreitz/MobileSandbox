	public static final java.lang.String LOG
	public static final java.lang.String SDK_VERSION
	public static final java.lang.String SDK_VERSION_DATE
	public static final java.lang.String TEST_EMULATOR
	private static java.lang.String a
	private static  b
	private static java.lang.String c
	private static java.lang.String d
	private static java.lang.String e
	private static Ljava.lang.String f
	private static java.lang.String g
	private static android.location.Location h
	private static  i
	private static  j
	private static  k
	private static java.lang.String l
	private static java.util.GregorianCalendar m
	private static com.admob.android.ads.AdManager$Gender n
	private static  o
	private static java.lang.Boolean p
	
	    static AdManager()
	    {
	        com.admob.android.ads.AdManager.e = com.admob.android.ads.j$a.a.toString();
	        com.admob.android.ads.AdManager.f = 0;
	        com.admob.android.ads.AdManager.i = 0;
	        com.admob.android.ads.AdManager.j = 0;
	        com.admob.android.ads.AdManager.o = 0;
	        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 4)) {
	            android.util.Log.i("AdMobSDK", "AdMob SDK version is 20101109-ANDROID-3312276cc1406347");
	        }
	        com.admob.android.ads.AdManager.p = 0;
	        return;
	    }
	
	
	    private AdManager()
	    {
	        return;
	    }
	
	
	    static synthetic long a(long p0)
	    {
	        com.admob.android.ads.AdManager.k = p0;
	        return p0;
	    }
	
	
	    static synthetic android.location.Location a(android.location.Location p0)
	    {
	        com.admob.android.ads.AdManager.h = p0;
	        return p0;
	    }
	
	
	    static com.admob.android.ads.a a(com.admob.android.ads.v p3)
	    {
	        com.admob.android.ads.a v0_2;
	        com.admob.android.ads.a v0_0 = p3.a();
	        if (!com.admob.android.ads.AdManager.isEmulator()) {
	            if ((!p3.b()) && ((!p3.c()) && ((v0_0 != 2) && (v0_0 != 1)))) {
	                com.admob.android.ads.a v0_1 = p3.d();
	                if ((v0_1 != null) && (v0_1 != 1)) {
	                    v0_2 = com.admob.android.ads.a.a;
	                } else {
	                    v0_2 = com.admob.android.ads.a.b;
	                }
	            } else {
	                v0_2 = com.admob.android.ads.a.b;
	            }
	        } else {
	            v0_2 = com.admob.android.ads.a.c;
	        }
	        return v0_2;
	    }
	
	
	    static String a()
	    {
	        return String.valueOf((com.admob.android.ads.AdManager.k / 1000));
	    }
	
	
	    private static String a(android.os.Bundle p5, String p6, String p7)
	    {
	        String v0 = 0;
	        String v1 = p5.getString(p6);
	        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	            android.util.Log.d("AdMobSDK", new StringBuilder().append("Publisher ID read from AndroidManifest.xml is ").append(v1).toString());
	        }
	        if ((p7 == null) && (v1 != null)) {
	            v0 = v1;
	        }
	        return v0;
	    }
	
	
	    static void a(android.content.Context p6)
	    {
	        if (!com.admob.android.ads.AdManager.o) {
	            com.admob.android.ads.AdManager.o = 1;
	            try {
	                String v0_2 = p6.getPackageManager();
	                String v1_0 = p6.getPackageName();
	                String v2_1 = v0_2.getApplicationInfo(v1_0, 128);
	            } catch (String v0) {
	            }
	            if (v2_1 != null) {
	                if (v2_1.metaData != null) {
	                    String v3_2 = com.admob.android.ads.AdManager.a(v2_1.metaData, "ADMOB_PUBLISHER_ID", com.admob.android.ads.AdManager.c);
	                    if (v3_2 != null) {
	                        com.admob.android.ads.AdManager.setPublisherId(v3_2);
	                    }
	                    String v3_4 = com.admob.android.ads.AdManager.a(v2_1.metaData, "ADMOB_INTERSTITIAL_PUBLISHER_ID", com.admob.android.ads.AdManager.d);
	                    if (v3_4 != null) {
	                        com.admob.android.ads.AdManager.setInterstitialPublisherId(v3_4);
	                    }
	                    if (!com.admob.android.ads.AdManager.j) {
	                        com.admob.android.ads.AdManager.i = v2_1.metaData.getBoolean("ADMOB_ALLOW_LOCATION_FOR_ADS", 0);
	                    }
	                }
	                com.admob.android.ads.AdManager.a = v2_1.packageName;
	                if (com.admob.android.ads.AdManager.c != null) {
	                    com.admob.android.ads.AdManager.a(com.admob.android.ads.AdManager.c);
	                }
	                if (com.admob.android.ads.AdManager.d != null) {
	                    com.admob.android.ads.AdManager.a(com.admob.android.ads.AdManager.d);
	                }
	                if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 2)) {
	                    android.util.Log.v("AdMobSDK", new StringBuilder().append("Application\'s package name is ").append(com.admob.android.ads.AdManager.a).toString());
	                }
	            }
	            String v0_3 = v0_2.getPackageInfo(v1_0, 0);
	            if (v0_3 != null) {
	                com.admob.android.ads.AdManager.b = v0_3.versionCode;
	                if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 2)) {
	                    android.util.Log.v("AdMobSDK", new StringBuilder().append("Application\'s version number is ").append(com.admob.android.ads.AdManager.b).toString());
	                }
	            }
	        }
	        return;
	    }
	
	
	    private static void a(String p2)
	    {
	        if ((p2 == null) || (p2.length() != 15)) {
	            com.admob.android.ads.AdManager.clientError(new StringBuilder().append("SETUP ERROR:  Incorrect AdMob publisher ID.  Should 15 [a-f,0-9] characters:  ").append(com.admob.android.ads.AdManager.c).toString());
	        }
	        if ((com.admob.android.ads.AdManager.a != null) && ((p2.equalsIgnoreCase("a1496ced2842262")) && ((!"com.admob.android.ads".equals(com.admob.android.ads.AdManager.a)) && (!"com.example.admob.lunarlander".equals(com.admob.android.ads.AdManager.a))))) {
	            com.admob.android.ads.AdManager.clientError("SETUP ERROR:  Cannot use the sample publisher ID (a1496ced2842262).  Yours is available on www.admob.com.");
	        }
	        return;
	    }
	
	
	    static String b()
	    {
	        String v0_0 = 0;
	        Integer v1_0 = com.admob.android.ads.AdManager.getBirthday();
	        if (v1_0 != null) {
	            Object[] v2_1 = new Object[3];
	            v2_1[0] = Integer.valueOf(v1_0.get(1));
	            v2_1[1] = Integer.valueOf((v1_0.get(2) + 1));
	            v2_1[2] = Integer.valueOf(v1_0.get(5));
	            v0_0 = String.format("%04d%02d%02d", v2_1);
	        }
	        return v0_0;
	    }
	
	
	    static String b(android.content.Context p5)
	    {
	        String v0_0 = 0;
	        String v1_0 = com.admob.android.ads.AdManager.getCoordinates(p5);
	        if (v1_0 != null) {
	            v0_0 = new StringBuilder().append(v1_0.getLatitude()).append(",").append(v1_0.getLongitude()).toString();
	        }
	        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	            android.util.Log.d("AdMobSDK", new StringBuilder().append("User coordinates are ").append(v0_0).toString());
	        }
	        return v0_0;
	    }
	
	
	    static String c()
	    {
	        int v0_2;
	        if (com.admob.android.ads.AdManager.n != com.admob.android.ads.AdManager$Gender.MALE) {
	            if (com.admob.android.ads.AdManager.n != com.admob.android.ads.AdManager$Gender.FEMALE) {
	                v0_2 = 0;
	            } else {
	                v0_2 = "f";
	            }
	        } else {
	            v0_2 = "m";
	        }
	        return v0_2;
	    }
	
	
	    protected static void clientError(String p2)
	    {
	        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6)) {
	            android.util.Log.e("AdMobSDK", p2);
	        }
	        throw new IllegalArgumentException(p2);
	    }
	
	
	    static synthetic android.location.Location d()
	    {
	        return com.admob.android.ads.AdManager.h;
	    }
	
	
	    static synthetic long e()
	    {
	        return com.admob.android.ads.AdManager.k;
	    }
	
	
	    public static String getApplicationPackageName(android.content.Context p1)
	    {
	        if (com.admob.android.ads.AdManager.a == null) {
	            com.admob.android.ads.AdManager.a(p1);
	        }
	        return com.admob.android.ads.AdManager.a;
	    }
	
	
	    protected static int getApplicationVersion(android.content.Context p1)
	    {
	        if (com.admob.android.ads.AdManager.a == null) {
	            com.admob.android.ads.AdManager.a(p1);
	        }
	        return com.admob.android.ads.AdManager.b;
	    }
	
	
	    public static java.util.GregorianCalendar getBirthday()
	    {
	        return com.admob.android.ads.AdManager.m;
	    }
	
	
	    public static android.location.Location getCoordinates(android.content.Context p9)
	    {
	        if ((com.admob.android.ads.AdManager.isEmulator()) && ((!com.admob.android.ads.AdManager.i) && (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 4)))) {
	            android.util.Log.i("AdMobSDK", "Location information is not being used for ad requests. Enable location");
	            android.util.Log.i("AdMobSDK", "based ads with AdManager.setAllowUseOfLocation(true) or by setting ");
	            android.util.Log.i("AdMobSDK", "meta-data ADMOB_ALLOW_LOCATION_FOR_ADS to true in AndroidManifest.xml");
	        }
	        if ((com.admob.android.ads.AdManager.i) && ((p9 != null) && ((com.admob.android.ads.AdManager.h == null) || (System.currentTimeMillis() > (com.admob.android.ads.AdManager.k + 900000))))) {
	            try {
	                if ((com.admob.android.ads.AdManager.h == null) || (System.currentTimeMillis() > (com.admob.android.ads.AdManager.k + 900000))) {
	                    String v0_17;
	                    String v1_1;
	                    long v2_4;
	                    com.admob.android.ads.AdManager.k = System.currentTimeMillis();
	                    if (p9.checkCallingOrSelfPermission("android.permission.ACCESS_COARSE_LOCATION") != 0) {
	                        v1_1 = 0;
	                        v0_17 = 0;
	                        v2_4 = 0;
	                    } else {
	                        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                            android.util.Log.d("AdMobSDK", "Trying to get locations from the network.");
	                        }
	                        v0_17 = ((android.location.LocationManager) p9.getSystemService("location"));
	                        if (v0_17 == null) {
	                            v1_1 = 0;
	                            v2_4 = 1;
	                        } else {
	                            String v1_5 = new android.location.Criteria();
	                            v1_5.setAccuracy(2);
	                            v1_5.setCostAllowed(0);
	                            v1_1 = v0_17.getBestProvider(v1_5, 1);
	                            v2_4 = 1;
	                        }
	                    }
	                    if ((v1_1 == null) && (p9.checkCallingOrSelfPermission("android.permission.ACCESS_FINE_LOCATION") == 0)) {
	                        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                            android.util.Log.d("AdMobSDK", "Trying to get locations from GPS.");
	                        }
	                        v0_17 = ((android.location.LocationManager) p9.getSystemService("location"));
	                        if (v0_17 == null) {
	                            v2_4 = 1;
	                        } else {
	                            String v1_7 = new android.location.Criteria();
	                            v1_7.setAccuracy(1);
	                            v1_7.setCostAllowed(0);
	                            v1_1 = v0_17.getBestProvider(v1_7, 1);
	                            v2_4 = 1;
	                        }
	                    }
	                    if (v2_4 != 0) {
	                        if (v1_1 != null) {
	                            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                                android.util.Log.d("AdMobSDK", "Location provider setup successfully.");
	                            }
	                            v0_17.requestLocationUpdates(v1_1, 0, 0, new com.admob.android.ads.AdManager$1(v0_17), p9.getMainLooper());
	                        } else {
	                            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                                android.util.Log.d("AdMobSDK", "No location providers are available.  Ads will not be geotargeted.");
	                            }
	                        }
	                    } else {
	                        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                            android.util.Log.d("AdMobSDK", "Cannot access user\'s location.  Permissions are not set.");
	                        }
	                    }
	                }
	            } catch (String v0_34) {
	                throw v0_34;
	            }
	        }
	        return com.admob.android.ads.AdManager.h;
	    }
	
	
	    static String getEndpoint()
	    {
	        return com.admob.android.ads.b.a();
	    }
	
	
	    public static com.admob.android.ads.AdManager$Gender getGender()
	    {
	        return com.admob.android.ads.AdManager.n;
	    }
	
	
	    public static String getInterstitialPublisherId(android.content.Context p2)
	    {
	        if (com.admob.android.ads.AdManager.d == null) {
	            com.admob.android.ads.AdManager.a(p2);
	        }
	        if ((com.admob.android.ads.AdManager.d == null) && (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6))) {
	            android.util.Log.e("AdMobSDK", "getInterstitialPublisherId returning null publisher id.  Please set the publisher id in AndroidManifest.xml or using AdManager.setPublisherId(String)");
	        }
	        return com.admob.android.ads.AdManager.d;
	    }
	
	
	    public static String getOrientation(android.content.Context p3)
	    {
	        String v0 = "p";
	        if (((android.view.WindowManager) p3.getSystemService("window")).getDefaultDisplay().getOrientation() == 1) {
	            v0 = "l";
	        }
	        return v0;
	    }
	
	
	    public static String getPostalCode()
	    {
	        return com.admob.android.ads.AdManager.l;
	    }
	
	
	    public static String getPublisherId(android.content.Context p2)
	    {
	        if (com.admob.android.ads.AdManager.c == null) {
	            com.admob.android.ads.AdManager.a(p2);
	        }
	        if ((com.admob.android.ads.AdManager.c == null) && (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 6))) {
	            android.util.Log.e("AdMobSDK", "getPublisherId returning null publisher id.  Please set the publisher id in AndroidManifest.xml or using AdManager.setPublisherId(String)");
	        }
	        return com.admob.android.ads.AdManager.c;
	    }
	
	
	    protected static int getScreenWidth(android.content.Context p2)
	    {
	        int v0_2;
	        int v0_1 = ((android.view.WindowManager) p2.getSystemService("window")).getDefaultDisplay();
	        if (v0_1 == 0) {
	            v0_2 = 0;
	        } else {
	            v0_2 = v0_1.getWidth();
	        }
	        return v0_2;
	    }
	
	
	    public static String getTestAction()
	    {
	        return com.admob.android.ads.AdManager.e;
	    }
	
	
	    static String[] getTestDevices()
	    {
	        return com.admob.android.ads.AdManager.f;
	    }
	
	
	    public static String getUserId(android.content.Context p4)
	    {
	        if (com.admob.android.ads.AdManager.g == null) {
	            String v0_2 = android.provider.Settings$Secure.getString(p4.getContentResolver(), "android_id");
	            if ((v0_2 != null) && (!com.admob.android.ads.AdManager.isEmulator())) {
	                com.admob.android.ads.AdManager.g = com.admob.android.ads.AdManager.md5(v0_2);
	                android.util.Log.i("AdMobSDK", new StringBuilder().append("To get test ads on this device use AdManager.setTestDevices( new String[] { \"").append(com.admob.android.ads.AdManager.g).append("\" } )").toString());
	            } else {
	                com.admob.android.ads.AdManager.g = "emulator";
	                android.util.Log.i("AdMobSDK", "To get test ads on the emulator use AdManager.setTestDevices( new String[] { AdManager.TEST_EMULATOR } )");
	            }
	            if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                android.util.Log.d("AdMobSDK", new StringBuilder().append("The user ID is ").append(com.admob.android.ads.AdManager.g).toString());
	            }
	        }
	        String v0_19;
	        if (com.admob.android.ads.AdManager.g != "emulator") {
	            v0_19 = com.admob.android.ads.AdManager.g;
	        } else {
	            v0_19 = 0;
	        }
	        return v0_19;
	    }
	
	
	    public static boolean isEmulator()
	    {
	        if ((!"unknown".equals(android.os.Build.BOARD)) || ((!"generic".equals(android.os.Build.DEVICE)) || (!"generic".equals(android.os.Build.BRAND)))) {
	            int v0_6 = 0;
	        } else {
	            v0_6 = 1;
	        }
	        return v0_6;
	    }
	
	
	    public static boolean isTestDevice(android.content.Context p3)
	    {
	        int v0_1;
	        if (com.admob.android.ads.AdManager.f == null) {
	            v0_1 = 0;
	        } else {
	            int v0_2 = com.admob.android.ads.AdManager.getUserId(p3);
	            if (v0_2 == 0) {
	                v0_2 = "emulator";
	            }
	            if (java.util.Arrays.binarySearch(com.admob.android.ads.AdManager.f, v0_2) < 0) {
	                v0_1 = 0;
	            } else {
	                v0_1 = 1;
	            }
	        }
	        return v0_1;
	    }
	
	
	    protected static String md5(String p8)
	    {
	        String v0_0 = 0;
	        if ((p8 != null) && (p8.length() > 0)) {
	            try {
	                String v0_2 = java.security.MessageDigest.getInstance("MD5");
	                v0_2.update(p8.getBytes(), 0, p8.length());
	                String v2_2 = new Object[1];
	                v2_2[0] = new java.math.BigInteger(1, v0_2.digest());
	                v0_0 = String.format("%032X", v2_2);
	            } catch (String v0_4) {
	                if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 3)) {
	                    android.util.Log.d("AdMobSDK", new StringBuilder().append("Could not generate hash of ").append(p8).toString(), v0_4);
	                }
	                v0_0 = p8.substring(0, 32);
	            }
	        }
	        return v0_0;
	    }
	
	
	    public static void setAllowUseOfLocation(boolean p1)
	    {
	        com.admob.android.ads.AdManager.j = 1;
	        com.admob.android.ads.AdManager.i = p1;
	        return;
	    }
	
	
	    public static void setBirthday(int p2, int p3, int p4)
	    {
	        java.util.GregorianCalendar v0_1 = new java.util.GregorianCalendar();
	        v0_1.set(p2, (p3 - 1), p4);
	        com.admob.android.ads.AdManager.setBirthday(v0_1);
	        return;
	    }
	
	
	    public static void setBirthday(java.util.GregorianCalendar p0)
	    {
	        com.admob.android.ads.AdManager.m = p0;
	        return;
	    }
	
	
	    static void setEndpoint(String p0)
	    {
	        com.admob.android.ads.b.a(p0);
	        return;
	    }
	
	
	    public static void setGender(com.admob.android.ads.AdManager$Gender p0)
	    {
	        com.admob.android.ads.AdManager.n = p0;
	        return;
	    }
	
	
	    public static void setInterstitialPublisherId(String p3)
	    {
	        com.admob.android.ads.AdManager.a(p3);
	        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 4)) {
	            android.util.Log.i("AdMobSDK", new StringBuilder().append("Interstitial Publisher ID set to ").append(p3).toString());
	        }
	        com.admob.android.ads.AdManager.d = p3;
	        return;
	    }
	
	
	    public static void setPostalCode(String p0)
	    {
	        com.admob.android.ads.AdManager.l = p0;
	        return;
	    }
	
	
	    public static void setPublisherId(String p3)
	    {
	        com.admob.android.ads.AdManager.a(p3);
	        if (com.admob.android.ads.InterstitialAd$c.a("AdMobSDK", 4)) {
	            android.util.Log.i("AdMobSDK", new StringBuilder().append("Publisher ID set to ").append(p3).toString());
	        }
	        com.admob.android.ads.AdManager.c = p3;
	        return;
	    }
	
	
	    public static void setTestAction(String p0)
	    {
	        com.admob.android.ads.AdManager.e = p0;
	        return;
	    }
	
	
	    public static void setTestDevices(String[] p1)
	    {
	        if (p1 != null) {
	            String[] v1_2 = ((String[]) p1.clone());
	            com.admob.android.ads.AdManager.f = v1_2;
	            java.util.Arrays.sort(v1_2);
	        } else {
	            com.admob.android.ads.AdManager.f = 0;
	        }
	        return;
	    }
	
