	final synthetic synteo.spysat.Application this$0
	
	    Application$3(synteo.spysat.Application p1)
	    {
	        this.this$0 = p1;
	        return;
	    }
	
	
	    public void onClick(android.view.View p2)
	    {
	        this.this$0.openHomePage();
	        return;
	    }
	
