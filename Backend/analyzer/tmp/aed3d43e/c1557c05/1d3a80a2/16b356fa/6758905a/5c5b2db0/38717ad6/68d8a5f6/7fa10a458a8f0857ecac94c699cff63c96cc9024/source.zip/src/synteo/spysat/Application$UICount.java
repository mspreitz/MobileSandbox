	final synthetic synteo.spysat.Application this$0
	
	    public Application$UICount(synteo.spysat.Application p5)
	    {
	        this.this$0 = p5;
	        this(((long) (synteo.spysat.Application.m_nInverval * 1000)), ((long) (synteo.spysat.Application.m_nInverval * 200)));
	        return;
	    }
	
	
	    public void onFinish()
	    {
	        this.start();
	        return;
	    }
	
	
	    public void onTick(long p2)
	    {
	        synteo.spysat.Application.access$5(this.this$0).update();
	        return;
	    }
	
