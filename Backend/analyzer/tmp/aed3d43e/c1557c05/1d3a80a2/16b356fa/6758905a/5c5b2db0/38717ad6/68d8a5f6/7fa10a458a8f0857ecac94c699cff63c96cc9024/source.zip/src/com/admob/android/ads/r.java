	public com.admob.android.ads.j$a a
	public java.lang.String b
	public java.util.Vector c
	public java.lang.String d
	public com.admob.android.ads.q$a e
	public  f
	public android.graphics.Point g
	public com.admob.android.ads.p h
	public java.lang.String i
	public java.lang.String j
	public android.os.Bundle k
	public  l
	private  m
	private android.graphics.Point n
	private java.lang.String o
	
	    public r()
	    {
	        this.a = com.admob.android.ads.j$a.a;
	        this.b = "";
	        this.c = new java.util.Vector();
	        this.d = 0;
	        this.e = com.admob.android.ads.q$a.c;
	        this.m = 0;
	        this.g = new android.graphics.Point(4, 4);
	        this.f = 0;
	        this.n = new android.graphics.Point(0, 0);
	        this.h = 0;
	        this.i = 0;
	        this.j = 0;
	        this.o = 0;
	        this.k = new android.os.Bundle();
	        this.l = 0;
	        return;
	    }
	
	
	    public static byte a(boolean p1)
	    {
	        int v0;
	        if (!p1) {
	            v0 = 0;
	        } else {
	            v0 = 1;
	        }
	        return v0;
	    }
	
	
	    private static android.graphics.Point a(int[] p3)
	    {
	        if ((p3 != null) && (p3.length != 2)) {
	            android.graphics.Point v0_2 = new android.graphics.Point(p3[0], p3[1]);
	        } else {
	            v0_2 = 0;
	        }
	        return v0_2;
	    }
	
	
	    public static boolean a(byte p1)
	    {
	        int v0 = 1;
	        if (p1 != 1) {
	            v0 = 0;
	        }
	        return v0;
	    }
	
	
	    private static int[] a(android.graphics.Point p3)
	    {
	        int[] v0_1;
	        if (p3 != null) {
	            v0_1 = new int[2];
	            v0_1[0] = p3.x;
	            v0_1[1] = p3.y;
	        } else {
	            v0_1 = 0;
	        }
	        return v0_1;
	    }
	
	
	    public final android.os.Bundle a()
	    {
	        android.os.Bundle v0_1 = new android.os.Bundle();
	        v0_1.putString("a", this.a.toString());
	        v0_1.putString("t", this.b);
	        v0_1.putParcelableArrayList("c", com.admob.android.ads.AdView$a.a(this.c));
	        v0_1.putString("u", this.d);
	        v0_1.putInt("or", this.e.ordinal());
	        v0_1.putByte("tr", com.admob.android.ads.r.a(this.m));
	        v0_1.putByte("sc", com.admob.android.ads.r.a(this.f));
	        v0_1.putIntArray("cbo", com.admob.android.ads.r.a(this.g));
	        v0_1.putIntArray("cs", com.admob.android.ads.r.a(this.n));
	        v0_1.putBundle("mi", com.admob.android.ads.AdView$a.a(this.h));
	        v0_1.putString("su", this.i);
	        v0_1.putString("si", this.j);
	        v0_1.putString("json", this.o);
	        v0_1.putBundle("$", this.k);
	        v0_1.putByte("int", com.admob.android.ads.r.a(this.l));
	        return v0_1;
	    }
	
	
	    public final void a(String p3, boolean p4)
	    {
	        if ((p3 != null) && (!"".equals(p3))) {
	            this.c.add(new com.admob.android.ads.w(p3, p4));
	        }
	        return;
	    }
	
	
	    public final void a(org.json.JSONObject p13, com.admob.android.ads.u p14, String p15)
	    {
	        this.a = com.admob.android.ads.j$a.a(p13.optString("a"));
	        this.a(p13.optString("au"), 1);
	        this.a(p13.optString("tu"), 0);
	        int v0_8 = p13.optJSONObject("stats");
	        if (v0_8 != 0) {
	            this.i = v0_8.optString("url");
	            this.j = v0_8.optString("id");
	        }
	        int v0_11 = p13.optString("or");
	        if ((v0_11 != 0) && (!v0_11.equals(""))) {
	            if (!"l".equals(v0_11)) {
	                this.e = com.admob.android.ads.q$a.a;
	            } else {
	                this.e = com.admob.android.ads.q$a.b;
	            }
	        }
	        int v0_17;
	        if (p13.opt("t") == null) {
	            v0_17 = 0;
	        } else {
	            v0_17 = 1;
	        }
	        this.m = v0_17;
	        this.b = p13.optString("title");
	        if (this.a == com.admob.android.ads.j$a.c) {
	            this.h = new com.admob.android.ads.p();
	            int v0_23 = p13.optJSONObject("$");
	            if (p14 != null) {
	                try {
	                    p14.a(v0_23, p15);
	                } catch (int v0) {
	                }
	            }
	            this.h.a = p13.optString("u");
	            this.h.b = p13.optString("title");
	            this.h.c = p13.optInt("mc", 2);
	            this.h.d = p13.optInt("msm", 0);
	            this.h.e = p13.optString("stats");
	            this.h.f = p13.optString("splash");
	            this.h.g = p13.optDouble("splash_duration", 1.5);
	            this.h.h = p13.optString("skip_down");
	            this.h.i = p13.optString("skip_up");
	            this.h.j = p13.optBoolean("no_splash_skip");
	            this.h.k = p13.optString("replay_down");
	            this.h.l = p13.optString("replay_up");
	            int v0_37 = p13.optJSONArray("buttons");
	            if (v0_37 != 0) {
	                android.graphics.Point v1_31 = v0_37.length();
	                int v2_1 = 0;
	                while (v2_1 < v1_31) {
	                    java.util.Vector v3_0 = v0_37.optJSONObject(v2_1);
	                    com.admob.android.ads.o v4_1 = new com.admob.android.ads.o();
	                    v4_1.a = v3_0.optString("$");
	                    v4_1.b = v3_0.optString("h");
	                    v4_1.c = v3_0.optString("x");
	                    v4_1.e = v3_0.optString("analytics_page_name");
	                    v4_1.d.a(v3_0.optJSONObject("o"), p14, p15);
	                    v4_1.f = v3_0.optJSONObject("o").toString();
	                    this.h.m.add(v4_1);
	                    v2_1++;
	                }
	            }
	        }
	        int v0_40;
	        if (p13.optInt("sc", 0) == 0) {
	            v0_40 = 0;
	        } else {
	            v0_40 = 1;
	        }
	        this.f = v0_40;
	        int v0_42 = p13.optJSONArray("co");
	        if ((v0_42 != 0) && (v0_42.length() >= 2)) {
	            this.g = new android.graphics.Point(v0_42.optInt(0), v0_42.optInt(1));
	        }
	        this.o = p13.toString();
	        return;
	    }
	
	
	    public final boolean a(android.os.Bundle p8)
	    {
	        int v0_43;
	        if (p8 != null) {
	            this.a = com.admob.android.ads.j$a.a(p8.getString("a"));
	            this.b = p8.getString("t");
	            this.c = new java.util.Vector();
	            int v0_8 = p8.getParcelableArrayList("c");
	            if (v0_8 != 0) {
	                boolean v1_0 = v0_8.iterator();
	                while (v1_0.hasNext()) {
	                    int v0_45 = ((android.os.Bundle) v1_0.next());
	                    if (v0_45 != 0) {
	                        com.admob.android.ads.w v2_1 = new com.admob.android.ads.w();
	                        v2_1.a = v0_45.getString("u");
	                        v2_1.b = v0_45.getBoolean("p", 0);
	                        this.c.add(v2_1);
	                    }
	                }
	            }
	            this.d = p8.getString("u");
	            this.e = com.admob.android.ads.q$a.a(p8.getInt("or"));
	            this.m = com.admob.android.ads.r.a(p8.getByte("tr"));
	            this.f = com.admob.android.ads.r.a(p8.getByte("sc"));
	            this.g = com.admob.android.ads.r.a(p8.getIntArray("cbo"));
	            if (this.g == null) {
	                this.g = new android.graphics.Point(4, 4);
	            }
	            this.n = com.admob.android.ads.r.a(p8.getIntArray("cs"));
	            int v0_30 = new com.admob.android.ads.p();
	            if (!v0_30.a(p8.getBundle("mi"))) {
	                this.h = 0;
	            } else {
	                this.h = v0_30;
	            }
	            this.i = p8.getString("su");
	            this.j = p8.getString("si");
	            this.o = p8.getString("json");
	            this.k = p8.getBundle("$");
	            this.l = com.admob.android.ads.r.a(p8.getByte("int"));
	            v0_43 = 1;
	        } else {
	            v0_43 = 0;
	        }
	        return v0_43;
	    }
	
	
	    public final java.util.Hashtable b()
	    {
	        String v0_1 = this.k.keySet();
	        java.util.Hashtable v2_1 = new java.util.Hashtable();
	        java.util.Iterator v3 = v0_1.iterator();
	        while (v3.hasNext()) {
	            String v0_4 = ((String) v3.next());
	            android.graphics.Bitmap v1_1 = this.k.getParcelable(v0_4);
	            if ((v1_1 instanceof android.graphics.Bitmap)) {
	                v2_1.put(v0_4, ((android.graphics.Bitmap) v1_1));
	            }
	        }
	        return v2_1;
	    }
	
