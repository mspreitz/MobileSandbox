	static final synthetic I a
	
	    static b$1()
	    {
	        NoSuchFieldError v0_2 = new int[com.admob.android.ads.j$b.values().length];
	        com.admob.android.ads.b$1.a = v0_2;
	        try {
	            com.admob.android.ads.b$1.a[com.admob.android.ads.j$b.b.ordinal()] = 1;
	            try {
	                com.admob.android.ads.b$1.a[com.admob.android.ads.j$b.a.ordinal()] = 2;
	            } catch (NoSuchFieldError v0) {
	            }
	            return;
	        } catch (NoSuchFieldError v0) {
	        }
	    }
	
