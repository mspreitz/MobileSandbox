	private java.lang.ref.WeakReference a
	
	    public AdView$c(com.admob.android.ads.AdView p2)
	    {
	        this.a = new ref.WeakReference(p2);
	        return;
	    }
	
	
	    public final void run()
	    {
	        com.admob.android.ads.AdView v3_2 = ((com.admob.android.ads.AdView) this.a.get());
	        if (v3_2 != null) {
	            if (((com.admob.android.ads.AdView.a(v3_2) != null) && (com.admob.android.ads.AdView.a(v3_2).getParent() != null)) || (com.admob.android.ads.AdView.b(v3_2) == null)) {
	                try {
	                    com.admob.android.ads.AdView.b(v3_2).onFailedToReceiveRefreshedAd(v3_2);
	                } catch (Exception v0_6) {
	                    android.util.Log.w("AdMobSDK", "Unhandled exception raised in your AdListener.onFailedToReceiveRefreshedAd.", v0_6);
	                }
	            } else {
	                try {
	                    com.admob.android.ads.AdView.b(v3_2).onFailedToReceiveAd(v3_2);
	                } catch (Exception v0_8) {
	                    android.util.Log.w("AdMobSDK", "Unhandled exception raised in your AdListener.onFailedToReceiveAd.", v0_8);
	                }
	            }
	        }
	        return;
	    }
	
