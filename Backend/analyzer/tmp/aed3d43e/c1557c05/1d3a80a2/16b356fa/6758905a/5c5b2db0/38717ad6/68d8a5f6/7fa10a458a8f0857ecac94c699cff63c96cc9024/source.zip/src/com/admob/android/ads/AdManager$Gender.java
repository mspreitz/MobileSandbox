	public static final enum com.admob.android.ads.AdManager$Gender FEMALE
	public static final enum com.admob.android.ads.AdManager$Gender MALE
	private static final synthetic Lcom.admob.android.ads.AdManager$Gender a
	
	    static AdManager$Gender()
	    {
	        com.admob.android.ads.AdManager$Gender.MALE = new com.admob.android.ads.AdManager$Gender("MALE", 0);
	        com.admob.android.ads.AdManager$Gender.FEMALE = new com.admob.android.ads.AdManager$Gender("FEMALE", 1);
	        com.admob.android.ads.AdManager$Gender[] v0_5 = new com.admob.android.ads.AdManager$Gender[2];
	        v0_5[0] = com.admob.android.ads.AdManager$Gender.MALE;
	        v0_5[1] = com.admob.android.ads.AdManager$Gender.FEMALE;
	        com.admob.android.ads.AdManager$Gender.a = v0_5;
	        return;
	    }
	
	
	    private AdManager$Gender(String p1, int p2)
	    {
	        this(p1, p2);
	        return;
	    }
	
	
	    public static com.admob.android.ads.AdManager$Gender valueOf(String p1)
	    {
	        return ((com.admob.android.ads.AdManager$Gender) Enum.valueOf(com.admob.android.ads.AdManager$Gender, p1));
	    }
	
	
	    public static com.admob.android.ads.AdManager$Gender[] values()
	    {
	        return ((com.admob.android.ads.AdManager$Gender[]) com.admob.android.ads.AdManager$Gender.a.clone());
	    }
	
