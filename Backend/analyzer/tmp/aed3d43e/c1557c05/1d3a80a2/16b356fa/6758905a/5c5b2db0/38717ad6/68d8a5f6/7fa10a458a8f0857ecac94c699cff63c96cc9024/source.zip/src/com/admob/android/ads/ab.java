	protected android.os.Handler a
	protected  b
	protected com.admob.android.ads.r c
	
	    public ab(android.content.Context p2)
	    {
	        this(p2);
	        this.a = new android.os.Handler();
	        this.b = this.getResources().getDisplayMetrics().density;
	        return;
	    }
	
	
	    public final void a(com.admob.android.ads.r p1)
	    {
	        this.c = p1;
	        return;
	    }
	
