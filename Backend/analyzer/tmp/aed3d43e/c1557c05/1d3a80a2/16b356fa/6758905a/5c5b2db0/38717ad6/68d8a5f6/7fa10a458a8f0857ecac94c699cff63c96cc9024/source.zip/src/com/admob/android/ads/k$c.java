	private java.lang.ref.WeakReference a
	
	    public k$c(com.admob.android.ads.k p2)
	    {
	        this.a = new ref.WeakReference(p2);
	        return;
	    }
	
	
	    public final void run()
	    {
	        try {
	            com.admob.android.ads.k v1_2 = ((com.admob.android.ads.k) this.a.get());
	        } catch (Exception v0) {
	            return;
	        }
	        if (v1_2 == null) {
	            return;
	        } else {
	            v1_2.f();
	            return;
	        }
	    }
	
