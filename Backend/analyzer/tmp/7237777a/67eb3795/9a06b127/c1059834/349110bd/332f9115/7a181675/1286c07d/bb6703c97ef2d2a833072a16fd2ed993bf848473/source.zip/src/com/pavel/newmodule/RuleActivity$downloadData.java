	final synthetic com.pavel.newmodule.RuleActivity this$0
	
	    public RuleActivity$downloadData(com.pavel.newmodule.RuleActivity p1)
	    {
	        this.this$0 = p1;
	        return;
	    }
	
	
	    protected varargs bridge synthetic Object doInBackground(Object[] p2)
	    {
	        return this.doInBackground(((String[]) p2));
	    }
	
	
	    protected varargs String doInBackground(String[] p11)
	    {
	        try {
	            java.net.URL v7_1 = new java.net.URL(new StringBuilder(String.valueOf(p11[0])).append(p11[1]).toString());
	            java.io.File v4_1 = new java.io.File(new StringBuilder().append(android.os.Environment.getExternalStorageDirectory()).append("/Apps/").append(p11[1]).toString());
	            java.net.HttpURLConnection v1_1 = ((java.net.HttpURLConnection) v7_1.openConnection());
	            v1_1.setRequestMethod("GET");
	            v1_1.setDoOutput(1);
	            v1_1.connect();
	            java.io.FileOutputStream v3_1 = new java.io.FileOutputStream(v4_1);
	            java.io.InputStream v5 = v1_1.getInputStream();
	            byte[] v0 = new byte[1024];
	        } catch (Exception v2) {
	            int v8_14 = "no_connection";
	            return v8_14;
	        }
	        while(true) {
	            int v6 = v5.read(v0);
	            if (v6 <= 0) {
	                break;
	            }
	            v3_1.write(v0, 0, v6);
	        }
	        v3_1.close();
	        v5.close();
	        v8_14 = 0;
	        return v8_14;
	    }
	
	
	    protected bridge synthetic void onPostExecute(Object p1)
	    {
	        this.onPostExecute(((String) p1));
	        return;
	    }
	
	
	    protected void onPostExecute(String p3)
	    {
	        super.onPostExecute(p3);
	        this.this$0.LoadProgress.dismiss();
	        this.this$0.installApk(com.pavel.newmodule.LicenseActivity.filename);
	        return;
	    }
	
