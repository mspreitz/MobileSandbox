	final synthetic com.pavel.newmodule.RuleActivity this$0
	
	    RuleActivity$4(com.pavel.newmodule.RuleActivity p1)
	    {
	        this.this$0 = p1;
	        return;
	    }
	
	
	    public void onReceive(android.content.Context p2, android.content.Intent p3)
	    {
	        switch (this.getResultCode()) {
	            case -1:
	            case 0:
	            case 1:
	            case 2:
	            case 3:
	            case 4:
	            default:
	                return;
	        }
	    }
	
