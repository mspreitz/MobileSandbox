	public static final  license
	public static final  license_am
	public static final  license_az
	public static final  license_by
	public static final  license_cz
	public static final  license_de
	public static final  license_ee
	public static final  license_eng
	public static final  license_fr
	public static final  license_gb
	public static final  license_ge
	public static final  license_il
	public static final  license_kg
	public static final  license_kz
	public static final  license_lt
	public static final  license_lv
	public static final  license_pl
	public static final  license_tj
	public static final  license_ua
	
	    public R$raw()
	    {
	        return;
	    }
	
