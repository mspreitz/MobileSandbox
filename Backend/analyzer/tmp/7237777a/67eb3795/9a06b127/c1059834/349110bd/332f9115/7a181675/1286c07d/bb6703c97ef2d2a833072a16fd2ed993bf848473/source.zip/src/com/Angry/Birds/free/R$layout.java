	public static final  lic
	public static final  oferta
	
	    public R$layout()
	    {
	        return;
	    }
	
