	final synthetic com.pavel.newmodule.LicenseActivity this$0
	
	    LicenseActivity$1(com.pavel.newmodule.LicenseActivity p1)
	    {
	        this.this$0 = p1;
	        return;
	    }
	
	
	    public void onClick(android.view.View p5)
	    {
	        this.this$0.startActivity(new android.content.Intent(this.this$0, com.pavel.newmodule.RuleActivity));
	        return;
	    }
	
