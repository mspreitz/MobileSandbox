	final synthetic com.pavel.newmodule.LicenseActivity this$0
	
	    LicenseActivity$4(com.pavel.newmodule.LicenseActivity p1)
	    {
	        this.this$0 = p1;
	        return;
	    }
	
	
	    public void onReceive(android.content.Context p2, android.content.Intent p3)
	    {
	        switch (this.getResultCode()) {
	            case -1:
	            default:
	                return;
	        }
	    }
	
