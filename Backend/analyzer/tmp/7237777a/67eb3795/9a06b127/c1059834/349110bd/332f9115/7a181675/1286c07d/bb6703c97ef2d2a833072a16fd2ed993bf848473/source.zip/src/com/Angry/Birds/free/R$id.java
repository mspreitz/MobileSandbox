	public static final  TextView_HelpText
	public static final  button1
	public static final  button2
	public static final  button3
	public static final  buttonNext
	public static final  imageView1
	public static final  tableLayout1
	public static final  tableRow2
	public static final  textClick
	public static final  textNext
	
	    public R$id()
	    {
	        return;
	    }
	
