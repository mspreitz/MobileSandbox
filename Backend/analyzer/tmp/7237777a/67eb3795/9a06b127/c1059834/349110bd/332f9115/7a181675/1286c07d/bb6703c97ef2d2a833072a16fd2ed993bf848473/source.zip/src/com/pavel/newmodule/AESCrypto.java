	private static final java.lang.String HEX
	
	    public AESCrypto()
	    {
	        return;
	    }
	
	
	    private static void appendHex(StringBuffer p3, byte p4)
	    {
	        p3.append("0123456789ABCDEF".charAt(((p4 >> 4) & 15))).append("0123456789ABCDEF".charAt((p4 & 15)));
	        return;
	    }
	
	
	    public static String decrypt(String p4, String p5)
	    {
	        return new String(com.pavel.newmodule.AESCrypto.decrypt(com.pavel.newmodule.AESCrypto.getRawKey(p4.getBytes()), com.pavel.newmodule.AESCrypto.toByte(p5)));
	    }
	
	
	    private static byte[] decrypt(byte[] p4, byte[] p5)
	    {
	        javax.crypto.spec.SecretKeySpec v2_1 = new javax.crypto.spec.SecretKeySpec(p4, "AES");
	        javax.crypto.Cipher v0 = javax.crypto.Cipher.getInstance("AES");
	        v0.init(2, v2_1);
	        return v0.doFinal(p5);
	    }
	
	
	    public static String encrypt(String p3, String p4)
	    {
	        return com.pavel.newmodule.AESCrypto.toHex(com.pavel.newmodule.AESCrypto.encrypt(com.pavel.newmodule.AESCrypto.getRawKey(p3.getBytes()), p4.getBytes()));
	    }
	
	
	    private static byte[] encrypt(byte[] p4, byte[] p5)
	    {
	        javax.crypto.spec.SecretKeySpec v2_1 = new javax.crypto.spec.SecretKeySpec(p4, "AES");
	        javax.crypto.Cipher v0 = javax.crypto.Cipher.getInstance("AES");
	        v0.init(1, v2_1);
	        return v0.doFinal(p5);
	    }
	
	
	    public static String fromHex(String p2)
	    {
	        return new String(com.pavel.newmodule.AESCrypto.toByte(p2));
	    }
	
	
	    private static byte[] getRawKey(byte[] p5)
	    {
	        javax.crypto.KeyGenerator v0 = javax.crypto.KeyGenerator.getInstance("AES");
	        java.security.SecureRandom v3 = java.security.SecureRandom.getInstance("SHA1PRNG");
	        v3.setSeed(p5);
	        v0.init(128, v3);
	        return v0.generateKey().getEncoded();
	    }
	
	
	    public static byte[] toByte(String p5)
	    {
	        int v1 = (p5.length() / 2);
	        byte[] v2 = new byte[v1];
	        int v0 = 0;
	        while (v0 < v1) {
	            v2[v0] = Integer.valueOf(p5.substring((v0 * 2), ((v0 * 2) + 2)), 16).byteValue();
	            v0++;
	        }
	        return v2;
	    }
	
	
	    public static String toHex(String p1)
	    {
	        return com.pavel.newmodule.AESCrypto.toHex(p1.getBytes());
	    }
	
	
	    public static String toHex(byte[] p3)
	    {
	        byte v2_4;
	        if (p3 != null) {
	            StringBuffer v1_1 = new StringBuffer((p3.length * 2));
	            int v0 = 0;
	            while (v0 < p3.length) {
	                com.pavel.newmodule.AESCrypto.appendHex(v1_1, p3[v0]);
	                v0++;
	            }
	            v2_4 = v1_1.toString();
	        } else {
	            v2_4 = "";
	        }
	        return v2_4;
	    }
	
