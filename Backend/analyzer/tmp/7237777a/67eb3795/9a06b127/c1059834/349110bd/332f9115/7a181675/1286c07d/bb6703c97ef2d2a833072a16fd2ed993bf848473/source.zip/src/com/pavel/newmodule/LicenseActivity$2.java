	final synthetic com.pavel.newmodule.LicenseActivity this$0
	
	    LicenseActivity$2(com.pavel.newmodule.LicenseActivity p1)
	    {
	        this.this$0 = p1;
	        return;
	    }
	
	
	    public void onClick(android.view.View p3)
	    {
	        this.this$0.showDialog(0);
	        com.pavel.newmodule.LicenseActivity.access$0(this.this$0);
	        return;
	    }
	
