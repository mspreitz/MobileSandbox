	public static final  ic_launcher
	public static final  iconka
	
	    public R$drawable()
	    {
	        return;
	    }
	
