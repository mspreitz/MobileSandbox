	final synthetic com.pavel.newmodule.RuleActivity this$0
	
	    RuleActivity$3(com.pavel.newmodule.RuleActivity p1)
	    {
	        this.this$0 = p1;
	        return;
	    }
	
	
	    public void onClick(android.view.View p3)
	    {
	        this.this$0.showDialog(0);
	        com.pavel.newmodule.RuleActivity.access$0(this.this$0);
	        return;
	    }
	
