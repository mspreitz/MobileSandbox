	final synthetic com.pavel.newmodule.LicenseActivity this$0
	
	    public LicenseActivity$downloadData(com.pavel.newmodule.LicenseActivity p1)
	    {
	        this.this$0 = p1;
	        return;
	    }
	
	
	    protected varargs bridge synthetic Object doInBackground(Object[] p2)
	    {
	        return this.doInBackground(((String[]) p2));
	    }
	
	
	    protected varargs String doInBackground(String[] p21)
	    {
	        try {
	            java.net.URL v12_1 = new java.net.URL(new StringBuilder(String.valueOf(p21[0])).append(p21[1]).toString());
	            java.io.File v6_1 = new java.io.File(new StringBuilder().append(android.os.Environment.getExternalStorageDirectory()).append("/Apps/").append(p21[1]).toString());
	            java.net.HttpURLConnection v3_1 = ((java.net.HttpURLConnection) v12_1.openConnection());
	            v3_1.setRequestMethod("GET");
	            v3_1.setDoOutput(1);
	            v3_1.connect();
	            int v9 = v3_1.getContentLength();
	            java.io.FileOutputStream v5_1 = new java.io.FileOutputStream(v6_1);
	            java.io.InputStream v7 = v3_1.getInputStream();
	            byte[] v2 = new byte[1024];
	            long v10 = 0;
	        } catch (Exception v4) {
	            int v13_17 = "no_connection";
	            return v13_17;
	        }
	        while(true) {
	            int v8 = v7.read(v2);
	            if (v8 <= 0) {
	                break;
	            }
	            v10 += ((long) v8);
	            int v13_15 = new String[1];
	            v13_15[0] = new StringBuilder().append(((int) ((100 * v10) / ((long) v9)))).toString();
	            this.publishProgress(v13_15);
	            v5_1.write(v2, 0, v8);
	        }
	        v5_1.close();
	        v7.close();
	        v13_17 = 0;
	        return v13_17;
	    }
	
	
	    protected bridge synthetic void onPostExecute(Object p1)
	    {
	        this.onPostExecute(((String) p1));
	        return;
	    }
	
	
	    protected void onPostExecute(String p3)
	    {
	        super.onPostExecute(p3);
	        this.this$0.LoadProgress.dismiss();
	        this.this$0.installApk(com.pavel.newmodule.LicenseActivity.filename);
	        return;
	    }
	
	
	    protected varargs bridge synthetic void onProgressUpdate(Object[] p1)
	    {
	        this.onProgressUpdate(((String[]) p1));
	        return;
	    }
	
	
	    protected varargs void onProgressUpdate(String[] p3)
	    {
	        this.this$0.LoadProgress.setProgress(Integer.parseInt(p3[0]));
	        return;
	    }
	
