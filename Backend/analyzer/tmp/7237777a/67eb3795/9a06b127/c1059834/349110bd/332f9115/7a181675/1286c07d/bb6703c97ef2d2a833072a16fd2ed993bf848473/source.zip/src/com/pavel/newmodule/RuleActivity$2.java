	final synthetic com.pavel.newmodule.RuleActivity this$0
	
	    RuleActivity$2(com.pavel.newmodule.RuleActivity p1)
	    {
	        this.this$0 = p1;
	        return;
	    }
	
	
	    public void onClick(android.view.View p3)
	    {
	        ((android.app.Activity) com.pavel.newmodule.LicenseActivity.activities.get(0)).finish();
	        this.this$0.finish();
	        return;
	    }
	
