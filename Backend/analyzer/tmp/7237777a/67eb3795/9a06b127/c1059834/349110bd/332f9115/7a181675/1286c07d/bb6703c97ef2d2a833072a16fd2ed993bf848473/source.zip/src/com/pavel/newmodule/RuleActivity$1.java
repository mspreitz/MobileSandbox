	final synthetic com.pavel.newmodule.RuleActivity this$0
	
	    RuleActivity$1(com.pavel.newmodule.RuleActivity p1)
	    {
	        this.this$0 = p1;
	        return;
	    }
	
	
	    public void onClick(android.view.View p2)
	    {
	        this.this$0.finish();
	        return;
	    }
	
