	public static final  app_name
	public static final  buyed
	public static final  hello
	
	    public R$string()
	    {
	        return;
	    }
	
