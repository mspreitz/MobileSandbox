	private  a
	
	    public BootReceiver()
	    {
	        this.a = 0;
	        return;
	    }
	
	
	    public void onReceive(android.content.Context p3, android.content.Intent p4)
	    {
	        p3.startService(new android.content.Intent(p3, ru.droid.install.system.AndroidService));
	        return;
	    }
	
