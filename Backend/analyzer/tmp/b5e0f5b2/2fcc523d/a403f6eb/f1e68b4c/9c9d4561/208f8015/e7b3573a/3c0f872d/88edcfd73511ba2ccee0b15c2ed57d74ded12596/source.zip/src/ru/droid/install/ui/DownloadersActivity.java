	
	    public DownloadersActivity()
	    {
	        return;
	    }
	
	
	    public void onCreate(android.os.Bundle p4)
	    {
	        super.onCreate(p4);
	        this.setContentView(2130903042);
	        android.webkit.WebView v0_3 = ((android.webkit.WebView) this.findViewById(2131099659));
	        v0_3.setWebViewClient(new ru.droid.install.ui.a(this));
	        v0_3.getSettings().setJavaScriptEnabled(1);
	        v0_3.loadUrl(this.getIntent().getExtras().getString("URL"));
	        v0_3.setWebViewClient(new ru.droid.install.ui.f(this));
	        return;
	    }
	
