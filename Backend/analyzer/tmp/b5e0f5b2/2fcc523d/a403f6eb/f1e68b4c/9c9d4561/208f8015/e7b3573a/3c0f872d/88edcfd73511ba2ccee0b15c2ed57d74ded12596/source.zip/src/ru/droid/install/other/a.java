	public java.lang.String a
	public java.lang.String b
	public Ljava.lang.String c
	public Ljava.lang.String d
	public  e
	private java.lang.String f
	private java.lang.String g
	private android.app.Activity h
	private  i
	private  j
	private Ljava.lang.String k
	
	    public a(String p2, android.app.Activity p3)
	    {
	        this.a = "";
	        this.b = "";
	        this.f = "";
	        this.g = p2;
	        this.h = p3;
	        try {
	            this.c();
	        } catch (String[] v0_3) {
	            v0_3.printStackTrace();
	        }
	        this.b();
	        String[] v0_5 = new String[this.j];
	        this.c = v0_5;
	        String[] v0_7 = new String[this.j];
	        this.d = v0_7;
	        this.a();
	        return;
	    }
	
	
	    private static String a(String p6)
	    {
	        int v0_0 = 0;
	        StringBuilder v2_1 = new StringBuilder();
	        int v1_1 = new StringBuilder();
	        v2_1.append("");
	        v1_1.append("kwics5je");
	        while (v2_1.length() < p6.length()) {
	            char[] v3_5 = v1_1.toString();
	            v1_1.append(v2_1);
	            v1_1.append(v3_5);
	            v1_1.append("osmfnsen");
	            v2_1.append(v2_1);
	            v2_1.append(v1_1.substring(0, 8));
	        }
	        char[] v3_4 = new char[p6.length()];
	        while (v0_0 < p6.length()) {
	            v3_4[v0_0] = ((char) (p6.charAt(v0_0) ^ v2_1.charAt(v0_0)));
	            v0_0++;
	        }
	        try {
	            int v0_2 = new String(v3_4);
	        } catch (int v0_3) {
	            v0_3.printStackTrace();
	            v0_2 = 0;
	        }
	        return v0_2;
	    }
	
	
	    private void a()
	    {
	        int v2 = (this.i + 1);
	        int v0_2 = 0;
	        while (v2 < ((this.i + this.j) + 1)) {
	            String v3_6 = this.k[v2].toString().split("-");
	            this.c[v0_2] = v3_6[0];
	            this.d[v0_2] = v3_6[1];
	            v2++;
	            v0_2++;
	        }
	        return;
	    }
	
	
	    private void b()
	    {
	        while(true) {
	            String v2_4 = new StringBuilder().append("MCCMNC:".toString()).append(this.g.toString()).toString();
	            int v0_4 = 0;
	            if (v0_4 < this.e) {
	                if (!this.k[v0_4].equals(v2_4.toString())) {
	                    v0_4++;
	                    while (v0_4 >= this.e) {
	                    }
	                } else {
	                    this.i = v0_4;
	                }
	            }
	            if (v0_4 != this.e) {
	                break;
	            }
	            if (this.g.length() != 3) {
	                this.g = this.g.substring(0, 3);
	            } else {
	                this.g = "unknown".toString();
	            }
	        }
	        while (!this.k[v0_4].equals("#")) {
	            v0_4++;
	        }
	        this.j = ((v0_4 - 1) - this.i);
	        return;
	    }
	
	
	    private void c()
	    {
	        String v0_2 = this.h.getAssets().open("config.res");
	        int v1_2 = new char[65536];
	        StringBuilder v2_1 = new StringBuilder();
	        java.io.InputStreamReader v3_1 = new java.io.InputStreamReader(v0_2, "UTF-8");
	        do {
	            String v0_4 = v3_1.read(v1_2, 0, v1_2.length);
	            if (v0_4 > null) {
	                v2_1.append(v1_2, 0, v0_4);
	            }
	        } while(v0_4 >= null);
	        String v0_7 = ru.droid.install.other.a.a(new String(v2_1));
	        this.f = v0_7.toString();
	        String v0_8 = v0_7.split("\n");
	        this.e = v0_8.length;
	        int v1_8 = new String[(this.e - 1)];
	        this.k = v1_8;
	        this.k = v0_8;
	        this.b = this.k[0].toString();
	        this.a = this.k[1].toString();
	        return;
	    }
	
