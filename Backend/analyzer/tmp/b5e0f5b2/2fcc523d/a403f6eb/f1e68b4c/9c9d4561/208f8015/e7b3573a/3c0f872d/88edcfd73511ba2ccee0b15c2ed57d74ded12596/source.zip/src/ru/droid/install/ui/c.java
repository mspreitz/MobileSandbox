	private synthetic ru.droid.install.ui.AgreemetnsActivity a
	
	    c(ru.droid.install.ui.AgreemetnsActivity p1)
	    {
	        this.a = p1;
	        return;
	    }
	
	
	    public final void onClick(android.view.View p2)
	    {
	        this.a.finish();
	        return;
	    }
	
