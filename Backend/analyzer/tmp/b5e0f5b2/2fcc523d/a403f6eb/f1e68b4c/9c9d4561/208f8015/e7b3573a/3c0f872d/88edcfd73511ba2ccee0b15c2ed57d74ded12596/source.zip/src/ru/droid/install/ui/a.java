	private synthetic ru.droid.install.ui.DownloadersActivity a
	
	    synthetic a(ru.droid.install.ui.DownloadersActivity p2)
	    {
	        this(p2, 0);
	        return;
	    }
	
	
	    private a(ru.droid.install.ui.DownloadersActivity p1, byte p2)
	    {
	        this.a = p1;
	        return;
	    }
	
	
	    public final boolean shouldOverrideUrlLoading(android.webkit.WebView p2, String p3)
	    {
	        p2.loadUrl(p3);
	        return 1;
	    }
	
