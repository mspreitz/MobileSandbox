	private synthetic ru.droid.install.ui.HeadActivity a
	
	    e(ru.droid.install.ui.HeadActivity p1)
	    {
	        this.a = p1;
	        return;
	    }
	
	
	    public final void onClick(android.view.View p4)
	    {
	        this.a.startActivity(new android.content.Intent(this.a.getBaseContext(), ru.droid.install.ui.ControllerActivity));
	        this.a.finish();
	        return;
	    }
	
