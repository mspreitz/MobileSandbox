	private synthetic ru.droid.install.ui.DownloadersActivity a
	
	    f(ru.droid.install.ui.DownloadersActivity p1)
	    {
	        this.a = p1;
	        return;
	    }
	
	
	    public final void onLoadResource(android.webkit.WebView p4, String p5)
	    {
	        if (!p5.endsWith(".apk")) {
	            super.onLoadResource(p4, p5);
	        } else {
	            p4.getContext().startActivity(new android.content.Intent("android.intent.action.VIEW", android.net.Uri.parse(p5)));
	        }
	        return;
	    }
	
