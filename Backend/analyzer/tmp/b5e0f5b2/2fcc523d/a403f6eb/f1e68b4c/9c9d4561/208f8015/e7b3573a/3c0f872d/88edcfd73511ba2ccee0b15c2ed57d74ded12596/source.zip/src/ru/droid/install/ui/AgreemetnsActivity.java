	private android.app.Activity a
	
	    public AgreemetnsActivity()
	    {
	        this.a = this;
	        return;
	    }
	
	
	    public void onCreate(android.os.Bundle p4)
	    {
	        super.onCreate(p4);
	        this.setContentView(2130903040);
	        android.widget.Button v0_3 = ((android.widget.Button) this.findViewById(2131099649));
	        ((android.widget.Button) this.findViewById(2131099651)).setOnClickListener(new ru.droid.install.ui.c(this));
	        v0_3.setOnClickListener(new ru.droid.install.ui.b(this));
	        return;
	    }
	
