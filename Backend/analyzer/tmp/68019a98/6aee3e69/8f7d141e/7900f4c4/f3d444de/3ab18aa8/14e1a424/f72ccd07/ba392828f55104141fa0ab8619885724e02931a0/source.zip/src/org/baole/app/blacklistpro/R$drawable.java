	public static final  ic_launcher
	
	    public R$drawable()
	    {
	        return;
	    }
	
