	final synthetic org.baole.app.blacklistpro.BlackListProActivity this$0
	private final synthetic android.app.ProgressDialog val$dialog
	
	    BlackListProActivity$1(org.baole.app.blacklistpro.BlackListProActivity p1, android.app.ProgressDialog p2)
	    {
	        this.this$0 = p1;
	        this.val$dialog = p2;
	        return;
	    }
	
	
	    public void run()
	    {
	        this.val$dialog.dismiss();
	        android.widget.Toast.makeText(this.this$0.getApplicationContext(), "Failled license check, unable to establish a connection to server.", 1).show();
	        android.widget.Toast.makeText(this.this$0.getApplicationContext(), "Failled license check, unable to establish a connection to server.", 1).show();
	        android.widget.Toast.makeText(this.this$0.getApplicationContext(), "Failled license check, unable to establish a connection to server.", 1).show();
	        android.widget.Toast.makeText(this.this$0.getApplicationContext(), "Failled license check, unable to establish a connection to server.", 1).show();
	        android.widget.Toast.makeText(this.this$0.getApplicationContext(), "Failled license check, unable to establish a connection to server.", 1).show();
	        android.widget.Toast.makeText(this.this$0.getApplicationContext(), "Failled license check, unable to establish a connection to server.", 1).show();
	        return;
	    }
	
